%--------------------------------------------------------------------------%

% This program combines output *.mat files from the EGF codes.

% Output can be used with eqplot.

% By: Gabrielle Tepp, University of Rochester
% Created: 6/26/15
% Last updated: 7/14/15

% --------------------

% Files should have the following column structure:
%
% [longitude latitude depth year month day hour minute second magnitude (extra data)]
% with (extra data) being any number of additional columns

% Note: eqplot treats columns as different stations, but they can be used
% for different value types as well

% MUST have at least 11 columns!

% Can use only 1 file (e.g. to pull out certain columns)

%--------------------------------------------------------------------------%

clear all; % start with clean slate


%% Set-up First File

colgood = 0;

while colgood == 0

% Get file name & read

disp(' ')
evfile = input('What is the name of the first file (including directory)?: ','s');

tempdata = importdata(evfile);

% Make sure there are at least 11 columns available

if size(tempdata,2) < 11
    
    disp(' ')
    disp('Oops! There are fewer than 11 columns.')
    disp('Please try another file.')
    
    clear tempdat;
    
else
    
    colgood = 1;
    
end

end

% Make list of serial dates for all events

serdat = datenum(tempdata(:,4:9));

% Check number of columns & ask which to keep

disp(' ')
disp(['There are ' num2str((size(tempdata,2))) ' columns in the file.'])
disp('Columns 1-10 are automatically kept.')
whichcol = input('Which additional columns would you like to keep? (ex. 11:14 or 14/16/20 or * for all): ','s');

if isempty(whichcol) == 1 || strcmpi(whichcol,'*') == 1
    
    addcol = 11:size(tempdata,2);
    
else
    
    addcol = transpose(makelist(whichcol,'num'));
    
end

% Get column names

disp(' ')
colnamestr = input('Please list the column name(s) in order (all must be same length): ','s');

collist = makelist(colnamestr,'str');

 % Make into structure with column #
 
 for q = 1:size(collist,1)
     
     colname.(collist(q,:)) = q + 10;
     
 end

evdata = tempdata(:,[1:10 addcol]);


%% Add Other Files

% Ask how many files to add

disp(' ')
numfiles = input('How many files do you want to add? (integer): ');

if numfiles ~= 0

for fnum = 1:numfiles
    
    disp(' ')
    disp('--------------------')
    
    colgood = 0;
    
    while colgood == 0
        
        % Get file name & read
        
        disp(' ')
        evfile = input('What is the name of the next file (including directory)?: ','s');
        
        tempdata = importdata(evfile);
        
        % Make sure there are at least 11 columns available
        
        if size(tempdata,2) < 11
            
            disp(' ')
            disp('Oops! There are fewer than 11 columns.')
            disp('Please try another file.')
            
            clear tempdata;
            
        else
            
            colgood = 1;
            
        end
        
    end
    
    % Make vector with serial dates
    
    tempser = datenum(tempdata(:,4:9));
    
    % Check number of columns & ask which to be added
    
    disp(' ')
    disp(['There are ' num2str((size(tempdata,2))) ' columns in the file.'])
    disp('Columns 1-10 are automatically added.')
    whichcol = input('Which additional columns would you like to add? (ex. 11:14 or 14/16/20 or * for all): ','s');
    
    if isempty(whichcol) == 1 || strcmpi(whichcol,'*') == 1
        
        addcol = 11:size(tempdata,2);
        
    else
        
        addcol = transpose(makelist(whichcol,'num'));
        
    end
    
    % Get column names
    
    disp(' ')
    colnamestr = input('Please list the column name(s) in order (all must be same length): ','s');
    
    tempcolname = makelist(colnamestr,'str');
    
    for oncol = 1:length(addcol)
        
        % Check if column exists & add data appropriately
        
        colmatch = isfield(colname,tempcolname(oncol,:));
        
        % Add NaN column to existing matrix for a new column
        
        if colmatch == 0 % if no match, add NaN column
            
            evdata = horzcat(evdata,(ones(size(evdata,1),1)*NaN));
            
        end
        
        % Get current number of columns in evdata
        
        currcolnum = size(evdata,2);
        
        % Go through all events in this file
        
        for onev = 1:length(tempser)
            
            % see if there's a matching event in the main file
            
            rowmatch = find(serdat(:,1) == tempser(onev,1));
            
            if colmatch == 1 % if column already exists, add new data to bottom (if not already in file)
                
                if isempty(rowmatch) == 1 % make sure it's new data
                    
                    serdat = vertcat(serdat,tempser(onev,1)); % add to serial dates list
                    
                    evdata = vertcat(evdata,[tempdata(onev,1:10) (ones(1,(currcolnum-10))*NaN)]); % add to event list
                    
                    evdata(size(evdata,1),colname.(tempcolname(oncol,:))) = tempdata(onev,addcol(oncol)); % update new data from NaN
                    
                else % fill in new info for existing event
                    
                    evdata(rowmatch,colname.(tempcolname(oncol,:))) = tempdata(onev,addcol(oncol));
                    
                end
                
            else % add new column
                
                if isempty(rowmatch) == 0
                    
                    % if matching event found, add new column data
                    
                    evdata(rowmatch,currcolnum) = tempdata(onev,addcol(oncol));
                    
                else % if not add to end of list
                    
                    serdat = vertcat(serdat,tempser(onev,1));
                    
                    evdata = vertcat(evdata,[tempdata(onev,1:10) (ones(1,(currcolnum-10-1))*NaN) tempdata(onev,addcol(oncol))]);
                    
                end
                
            end
            
        end
        
        % Add new column names to list
        
        colmatch = isfield(colname,tempcolname(oncol,:));
        
        if colmatch == 0 % if not in structure, add it
            
            colname.(tempcolname(oncol,:)) = currcolnum;
            
        end
        
    end
    
    % Clear temporary variables
    
    clear tempdata tempser;
    
end

end


%% Write New File

disp(' ')
disp('A new *.mat file will now be written.')

disp(' ')
matfile = input('Name your file (including .mat and directory): ','s');

save(matfile,'evdata');

