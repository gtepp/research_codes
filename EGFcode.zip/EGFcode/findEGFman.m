%--------------------------------------------------------------------------%

% This program is for finding suitable events to use as empirical Green's functions.

% By: Gabrielle Tepp
% Created: 9/16/14
% Last updated: 9/16/14

% --------------------

% Input defaults are listed second

% Event #'s are based on the order that the events are listed in your .mat file

% --------------------

% ** Before use, you will want to check/fix/update the following:

% ~ Create .mat Event File
%
% Your file should have the following column structure:
%
% [longitude latitude depth year month day hour minute second magnitude flag(optional)]
%
% *Notes: 1) Event #'s are based on the order listed in your .mat file
%         2) Magnitude column is optional (not actually used here).
%         3) For files to produce earthquake timetables, long, lat, and 
%             depth are needed. Otherwise, they are unnecessary. However, 
%             the algorithm refers to the column #'s for the time info. If 
%             you leave out the location info, either use empty (or "dummy") 
%             columns or change the column numbers within the algorithm.
%         4) Flag column is optional. Allows for the ability to ignore
%             events that you have flagged. Flagged events should have a
%             '1' in this column with all other events having a '0'.
% Alternately, you could change the read-in file part of the code.

%--------------------------------------------------------------------------%

%% Read in Event Information

disp(' ')
evfile = input('Enter the event list file name (.mat): ','s');
disp(' ')
disp('You may choose one or more events from your file list (default all).')
disp('** Entry format example: 6:10 or 6/7/8/9/10 or 6/7:9/10')
disp('** Use ''*'' for all events within date bounds.')
disp(' ')
numstr = input('List the event #''s you would like to see (* for all): ','s');

disp('--------------------')

evdata = importdata(evfile);

% Optional: allow ability to leave out events flagged in file

if size(evdata,2) == 11

    disp(' ')
    keepflag = input('Keep flagged events? (Y or N): ','s');
    
else
    
    keepflag = 'Y'; % if no flags in file, ignore option

end

% Make list with all events (default)

if strcmpi(numstr,'*') == 1 || isempty(numstr) == 1
        
    % Create list of numbers for all events
    
    numlist = transpose(1:length(evdata));

else 
   
    % Convert event #s to usuable list

    numlist = makelist(numstr,'num');

end

% Remove any events that go beyond the number in evdata

templist = 0;

for n = 1:length(numlist)
    
    if numlist(n) <= size(evdata,1)
       
        if templist == 0
              
            templist = numlist(n);

        else

            templist = vertcat(templist,numlist(n));

        end
       
   end
    
end

% Replace event list with temporary list
    
numlist = templist;

% Remove any flagged events if desired

if strcmpi(keepflag,'Y') == 0
    
    templist = 0;
    
    for p = 1:length(numlist)
        
       if evdata(numlist(p),11) == 0
           
          if templist == 0
              
              templist = numlist(p);
              
          else
              
              templist = vertcat(templist,numlist(p));
              
          end
           
       end
        
    end
    
    % Replace event list with temporary list
    
    numlist = templist;
    
end

numlist = sort(numlist); % make sure final event list is ordered

% Clear temporary variables

clear templist p keepflag n;


%% Compare Event Distances & Magnitudes

disp(' ')
disp('Events will now be compared.')

% Make a matrix to compare event distances (bottom) & magnitudes (top)

distcomp = zeros(size(numlist,1),size(numlist,1));

depcomp = distcomp;

magcomp = distcomp;

for evn = 1:size(numlist,1)
    
    % Compare to every event after current one
    
    for cev = 1:size(numlist,1)

        % Calculate magnitude difference
        
        magcomp(evn,cev) = evdata(evn,10) - evdata(cev,10);
        
        % Calculate distance between events (convert to km - approximately)
        
        distcomp(evn,cev) = sqrt( ( (evdata(evn,1) * cosd(evdata(evn,2)) - evdata(cev,1)  * cosd(evdata(cev,2))) * 111 )^2 +...
            ( (evdata(evn,2) - evdata(cev,2)) * 111)^2);

        % Calculate difference in depth
        
        depcomp(evn,cev) = abs(evdata(evn,3)-evdata(cev,3));

    end
    
end

% Find ideal EGF events

EGFreq = 'Y';

while strcmpi(EGFreq,'Y') == 1

    disp(' ')
    minmagdiff = input('Choose a minimum magnitude difference (double, default 1): ');
    
    if isempty(minmagdiff) == 1
        
        minmagdiff = 1;
        
    end
    
    disp(' ')
    maxdist = input('Choose a maximum distance (double, default 2 km): ');
    
    if isempty(maxdist) == 1
        
        maxdist = 2;
        
    end
    
    disp(' ')
    maxdepdiff = input('Choose a maximum depth difference (double, default 2 km): ');
    
    if isempty(maxdepdiff) == 1
        
        maxdepdiff = 2;
        
    end
    
    EGFop = zeros(size(numlist,1),size(numlist,1));
    
    EGFopdd = EGFop;
    
    % Create use-as-EGF matrix
    % Test row events as "EGF"s for column events
    
    for evn = 1:size(numlist,1)
        
        evnum = strcat('ev',num2str(evn));
        
        % Compare to every event after current one
        
        for cev = 1:size(numlist,1)
            
            cnum = strcat('ev',num2str(cev));
            
            % Check magnitude difference
            
            if magcomp(evn,cev) < 0 && abs(magcomp(evn,cev)) >= minmagdiff
                
                EGFop(evn,cev) = EGFop(evn,cev) + 1;
                
            end
            
            % Check distance
                        
            if abs(distcomp(evn,cev)) <= maxdist
                
                EGFop(evn,cev) = EGFop(evn,cev) + 1;
                
                EGFopdd(evn,cev) = EGFopdd(evn,cev) + 1;
                
            end
            
            % Check depth difference (weight less since not as important)
                        
            if abs(depcomp(evn,cev)) <= maxdepdiff
                
                EGFop(evn,cev) = EGFop(evn,cev) + 0.5;
                     
                EGFopdd(evn,cev) = EGFopdd(evn,cev) + 0.5;
                
            end
            
        end
        
        % Events aren't good EGFs for themselves....
        
        EGFop(evn,evn) = 0;
        
        EGFopdd(evn,evn) = 0;
        
    end
    
    disp(' ')
    plcomp = input('Plot comparison matrix? (Y or N): ','s'); % default N
    
    while strcmpi(plcomp,'Y') == 1
        
        disp(' ')
        disp('Plot options:')
        disp('1) Distance')
        disp('2) Depth difference')
        disp('3) Magnitude difference')
        disp('4) Best EGF options - distance & depth')
        disp('5) Best EGF options - all (default)')
        disp(' ')
        whpl = input('Choose a plot type: ');
        
        figure;
        
        if whpl == 1
                        
            imagesc(distcomp);
            
            colorbar('Location','EastOutside');
            title('Distance Between Events');
            xlabel('Event Number');
            ylabel('Event Number');
            
        elseif whpl == 2
            
            imagesc(depcomp);
            
            colorbar('Location','EastOutside');
            title({'Distance Between Events','With Depth Included in Distance'});
            xlabel('Event Number');
            ylabel('Event Number');
            
        elseif whpl == 3
            
            imagesc(magcomp);
            
            colorbar('Location','EastOutside');
            title('Magnitude Difference Between Events');
            xlabel('Event Number');
            ylabel('Event Number');
            
        elseif whpl == 4
                           
            imagesc(EGFopdd);
            
            colorbar('Location','EastOutside');
            title('Best EGF Options');
            xlabel('Event Number');
            ylabel('Possible EGF');
           
            
        else
            
            imagesc(EGFop);
            
            colorbar('Location','EastOutside');
            title('Best EGF Options');
            xlabel('Event Number');
            ylabel('Possible EGF');
           
        end
        
        disp(' ')
        plcomp = input('Plot another comparison matrix? (Y or N): ','s');
        
    end

    disp(' ')
    EGFreq = input('Pick new EGF requirements? (Y or N): ','s');
    
end


%% Find EGFs for Specific Events

disp(' ')
disp('--------------------')
disp(' ')

spev = input('Examine EGF possibilities for specific events? (N or Y): ','s');

while strcmpi(spev,'N') == 0
    
    % Choose event to find EGFs for
    
    disp(' ')
    disp(['Events: ' num2str(transpose(numlist))])
    disp(' ')
    examev = input('Choose your event: ');

    while isempty(examev) == 1
        
        disp(' ')
        disp('Error: You must choose an event.')
        disp(' ')
        examev = input('Choose your event: ','s');
        
    end
    
    % Plot information about possibilities
    
    figure;
    
    hold on;
    
    datavec = ones(length(numlist),1);
    
    zerovec = zeros(length(numlist),1);
    
    % Plot magnitude differences
    
    magscale = 1 / abs(-0.0001 - min(magcomp(:,examev)));
    
    magadj = magcomp(:,examev) - (datavec * min(magcomp(:,examev)));
    
    scatter(datavec,numlist,100,[(magadj * magscale),zerovec,zerovec],'fill')
    
    % Plot distances
    
    distscale = 1 / (max(distcomp(:,examev)) - min(distcomp(:,examev)));
    
    distadj = distcomp(:,examev) - (datavec * min(distcomp(:,examev)));
    
    scatter(datavec*2,numlist,100,[zerovec,(distadj * distscale),zerovec],'fill')
    
    % Plot depth differences
    
    depscale = 1 / (max(depcomp(:,examev)) - min(depcomp(:,examev)));
    
    depadj = depcomp(:,examev) - (datavec * min(depcomp(:,examev)));
    
    scatter(datavec*3,numlist,100,[zerovec,zerovec,(depadj * depscale)],'fill')
    
    % Plot final evaluation
    
    scatter(datavec*4,numlist,100,[(magadj * magscale),(distadj * distscale),(depadj * depscale)],'fill')
    
    set(gca,'XLim',[0 5],'YLim',[0 length(numlist)+1],'XTick',[0:1:5],'XTickLabel',{'';'Magnitude';'Distance';'Depth';'Final Evaluation';''},'YGrid','on');
    ylabel('Event Number');
    title({['Possible EGFs for Event ',num2str(examev)],'Darker Colors Indicate Better EGFs'});
    
    disp(' ')
    spev = input('Examine EGF possibilities for another event? (N or Y): ','s');
    
end


%% Clear Temporary Variables

clear numstr maxdepdiff minmagdiff maxdist findEGF plcmop whpl evn cev plcomp;
