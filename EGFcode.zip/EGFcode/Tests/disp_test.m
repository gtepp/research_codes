
%% test known sine wave

sps = 50;

endt = 100;

t = 0:1/sps:endt;

freq = 1/4;

wf = 0.5*sin(2*pi*freq*t);

intwf = freq_integrate(wf,sps);

corrwf = detrend(intwf);

sumintwf = detrend(cumtrapz(wf)) / sps;

fobj = filterobject('h',0.01,4);

%filtwf = filtfilt(fobj,intwf,sps);

filtwf = hp_bu_co(intwf,0.001,sps,4,2);

%filtwf = butter(intwf,[0.001 sps/2]);

figure;

plot(t,wf,'b');

hold on;

plot(t,intwf,'g');

plot(t,sumintwf,'r');

plot(t,filtwf,'k');

% check spectra

wff = fft(wf);

intwff = fft(intwf);

filtwff = fft(filtwf);

sumintwff = fft(sumintwf);

figure;

 f=linspace(0,sps/2,length(wff)/2+1);

hold on;

plot(f,2*abs(wff(1:length(wff)/2+1)),'b');

plot(f,2*abs(intwff(1:length(intwff)/2+1)),'g');

plot(f,2*abs(sumintwff(1:length(sumintwff)/2+1)),'r');

plot(f,2*abs(filtwff(1:length(filtwff)/2+1)),'k');


%% test earthquake waveform

station = 'AFME';
channel = 'BHZ';
%eq = length(eqmag);

disp = freq_integrate(data.ev7.(station).(channel).wf,data.ev7.(station).sfreq);

sumdisp = detrend(cumtrapz(data.ev7.(station).(channel).wf)) / data.ev7.(station).sfreq;

% Plot waveforms
    
time = (0:1:length(data.ev7.(station).(channel).wf)-1) / data.ev7.(station).sfreq;

figure;

subplot(2,1,1);

hold on;

plot(time,data.ev7.(station).(channel).wf,'b');

xlabel('Time (s)');
ylabel('Amplitude');

subplot(2,1,2)

hold on;

plot(time,disp,'g');

plot(time,sumdisp,'r');

hold on;

% Filter results
    
% fobj = filterobject('b',[0.1 15],2);
% 
% %dispcorr = detrend(disp);
% 
% dispcorr = filtfilt(fobj,dispcorr,25);

dispcorr = hp_bu_co(disp,0.001,25,4,2);

%dispcorr = butter(disp,[0.001 25]);

%plot(time,dispcorr,'r');

xlabel('Time (s)');
ylabel('Amplitude');

% check spectra

wff = fft(data.ev7.(station).(channel).wf);

dispf = fft(disp);

sumdispf = fft(sumdisp);

figure;

 f=linspace(0,sps/2,length(wff)/2+1);

hold on;

plot(f,2*abs(wff(1:length(wff)/2+1))/max(wff),'b');

plot(f,2*abs(dispf(1:length(dispf)/2+1))/max(dispf),'g');

plot(f,2*abs(sumdispf(1:length(sumdispf)/2+1))/max(sumdispf),'r');

