%% Test values of lambda
% 
% Note: Run script 'egf_deconv' first to generate necessary variables

station = 'TRUE';
channel = 'BHZ';
%eq = length(eqmag);
eqnum = 'ev711';
%egf = egfdec.(station).(channel).egf;
egfn = 'ev719';

test = zeros(10,2);

% Make window (we'll just use the P-wave)

% tstrt = (119 - params.crop.start) * data.(eqnum).(station).sfreq;
% 
% tend = tstrt + (5 * data.(eqnum).(station).sfreq);

tstrt = (-1 + data.(evnum).(station).ppick - params.crop.start) * data.(eqnum).(station).sfreq;

tend = tstrt + (6 * data.(eqnum).(station).sfreq);

%lam = logspace(-9,10,20);
evdat = get(data.(eqnum).(station).(channel).wf,'Data');
egfdat = get(data.(egfn).(station).(channel).wf,'Data');

maxe = round(log10(max(egfdat(tstrt:tend))))*2;

lam = [0,10.^((maxe-8):maxe)];

%lam = 100:100:2000;

for ln = 1:10

    lamnum = strcat('ln',num2str(ln));
    
    % Use waveform data
    
   [deconv.(lamnum).raw,resid.(lamnum).raw] = seisdeconv(evdat(tstrt:tend),egfdat(tstrt:tend),lam(ln),data.(eqnum).(station).sfreq,'w');
    
    % Use spectral data
    
%     [deconv.(lamnum).raw,resid.(lamnum).raw] = seisdeconv(10.^data.(eqmag{eq,1}).(station).(channel).spec.data,10.^data.(egf).(station).(channel).spec.data,...
%         lam(ln),data.(eqmag{eq,1}).(station).sfreq,'s');
    
    % Calculate and save norms
    
    test((ln),1) = norm(deconv.(lamnum).raw);
    
    test((ln),2) = norm(resid.(lamnum).raw);
    
    test((ln),3) = lam(ln);
    
end

% Plot results

figure;

scatter(test(:,2),test(:,1),25,test(:,3),'filled');

%set(gca,'XScale','log')
xlabel('Residual Norm')
ylabel('Model Norm')
colorbar('EastOutside');

% Plot waveforms
    
%time = (0:1:length(data.(eqmag{eq,1}).(station).(channel).spec.data)-1) / data.(eqmag{eq,1}).(station).sfreq;
time = (0:1:length(evdat)-1) / data.(eqnum).(station).sfreq;

figure;

subplot(2,1,1);

hold on;
%wfdata = real(ifft(10.^data.(eqmag{eq,1}).(station).(channel).spec.data));
%plot(time(1:length(time)/2),wfdata(1:length(time)/2),'b');

plot(time(tstrt:tend),evdat(tstrt:tend),'b');

xlabel('Time (s)');
ylabel('Amplitude');

subplot(2,1,2)

%plot(time,real(ifft(10.^data.(egf).(station).(channel).spec.data)),'g');
plot(time(tstrt:tend),egfdat(tstrt:tend),'g');

xlabel('Time (s)');
ylabel('Amplitude');

% Filter & Plot results

for ln = 1:10

    lamnum = strcat('ln',num2str(ln));
    
    % Filter results
    
    fobj = filterobject('b',[0.1 15],2);
    
    %resid.(lamnum).filt = filtfilt(fobj,resid.(lamnum).raw,25);
    
    deconv.(lamnum).filt = filtfilt(fobj,deconv.(lamnum).raw,25);
    
    % Plot results

    figure;

    dtime = (0:length(deconv.(lamnum).raw)-1) / data.(eqnum).(station).sfreq * 2;
    
    subplot(2,1,1);
    
    hold on;
    
%    plot(time,real(ifft(deconv.(lamnum).raw)),'r');
    plot(dtime,deconv.(lamnum).raw,'k');
    plot(dtime,deconv.(lamnum).filt,'r');
    
    title(['Lambda = ',num2str(lam(ln))]);
    xlabel('Time (s)');
    ylabel('Amplitude');
    
    subplot(2,1,2);
    
    hold on;
    
 %   plot(time,real(ifft(resid.(lamnum).raw)),'k');
    plot(dtime,resid.(lamnum).raw,'k');
    %plot(dtime,resid.(lamnum).filt,'b');
    
    xlabel('Time (s)');
    ylabel('Residual');
    
end


%% Do a Noise Test

% [SNR,corrw,corrf]  = noiseanalysis(data.(egfn).(station).(channel).wf,15,5,1,data.(egfn).(station).sfreq,'plotspec','Y');
