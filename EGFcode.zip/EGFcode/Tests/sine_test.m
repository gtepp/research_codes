% Test for function seisdeconv using convolved sine waves + noise.

%% Make Waveform

dF = 5;                    % Sampling frequency
N = 801;                     % Length of signal
delay = -40;            % Start of window (w.r.t. signal start)

%---------------------
% the following is borrowed from: http://epsc.wustl.edu/seismology/michael/CIG/workshop06/Aster/Deconvolution_Demo/deconvolution_demo.m

%time vector for plots
t=linspace(delay,120,N);

%frequency vector for plots
F=linspace(0,dF/2,N-1);

noise = 5; % noise amplitude

tau = 10;

%generate system response here (actual time series are N-1 samples long)
for i=1:N-1
if (t(i)<0)
g(i) = 0;
else
g(i) = t(i)*exp(-t(i)/tau);
end
end

gmax=max(g);

%final response is a unit-height column vector
g=g'/gmax;

%synthetic signal to be estimated via deconvolution consists of two pulses of standard deviation sig
sig=2;
mtrue = (exp(-((t(1:N-1)-8).^2/(sig^2*2)))+0.5*exp(-((t(1:N-1)-25).^2/(sig^2*2))))';
mtrue=mtrue/max(mtrue);

%perform a time domain (serial) convolution to get the data (observed) time series vector

%note that the length of d will be equal to 2*(N-1)-1
d=conv(g,mtrue);

%generate Gaussian noise of amplitude noise
nn=noise*randn(length(d),1);

%generate the noisy data vector
dn=d+nn;

%first, we will plot the true deconvolution solution

figure
plot(t(1:N-1),mtrue,'k')
set(gca,'FontSize',18,'LineWidth',1.0);
xlabel('Time (s)')
axis tight
title('True Model')

%Here is a plot of the convolution kernal that smooths the model to produce the data vector

figure
plot(t(1:N-1),g,'k')
set(gca,'FontSize',18,'LineWidth',1.0);
xlabel('Time (s)')
axis tight
title('System Impulse Response')

%and here is the result of convolving the previous two plotted functions to produce a data vector 

figure
plot(t(1:N-1),dn(1:N-1),'k')
set(gca,'FontSize',18,'LineWidth',1.0);
xlabel('Time (s)')
axis tight
title('Noisy Data')

%----------------------

model = dn'; % convert to row vector

% Get SNR and remove noise form model waveform

%[SNR modelcorr modelcorrf] = noiseanalysis(model,40,80,0,dF,'plotspec','Y','waveformstart',-40);

impulse = g';

lam = [0.0001,0.001,0.01,0.1,1,10,100];

for n = 1:7

[wdec,resid] = seisdeconv(model,impulse,lam(n),dF,'w');

L = length(model);

% Plot results

figure(10);

hold on;

scatter(norm(resid),norm(wdec),25,lam(n),'filled');

%set(gca,'XScale','log')
xlabel('Residual Norm')
ylabel('Model Norm')
colorbar('EastOutside');

dt = (0:(length(wdec)-1)) / dF - abs(delay);

figure;

subplot(2,1,1)

plot(dt,wdec)

title({'Model',['    Lambda = ',num2str(lam(n))]})

subplot(2,1,2)

plot(dt,resid)

title('Residual')

end