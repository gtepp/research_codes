
% Empirical Green's function (EGF) or Frequency Index (FI) analysis
%
% The EGF part follows the method from Baltay et al., JGR, 2010.
%
% For more on FI, see Buurman & West, USGS Pub., 2010. To access the FI
% part of the code, choose 2 frequency bands.
%
% --------------------
%
% Utilizes the GISMO Correlation Toolbox and Waveform Suite
%
% By: Michael West and Celso Reyes (respectively)
%     Geophysical Institute, Alaska Volcano Observatory, U. Alaska Fairbanks
%     http://www.giseis.alaska.edu/Seis/EQ/tools/GISMO/
%
% Make sure the toolbox is installed. It is freely avaiable at the above website.
%
% --------------------
%
% The code uses a choice of an average of two horizontal components 
% (E & N) or a vertical component (Z). The horizontals are best for codas, 
% while the vertical is best for P-waves. Choose accordingly.
%
% Input defaults are listed second
%
% Event #'s are based on the order that the events are listed in your .mat file
%
% --------------------
%
% ** Before use, you will want to check/fix/update the following:
%
% ~ Create .mat Event File & Pick File (can be done with fileconvert.m)
%
% Your file should have the following column structure:
%
% [longitude latitude depth year month day hour minute second magnitude flag/extra(optional)]
%
% *Notes: 1) Event #'s are based on the order listed in your .mat file
%         2) Magnitude column is optional (not actually used here).
%         3) For files to produce earthquake timetables, long, lat, and 
%             depth are needed. Otherwise, they are unnecessary. However, 
%             the algorithm refers to the column #'s for the time info. If 
%             you leave out the location info, either use empty (or "dummy") 
%             columns or change the column numbers within the algorithm.
%         4) Flag/extra column is optional. Allows for the ability to ignore
%             events that you have flagged or to choose events with other limitations.
%             Flagged events should have a '1' in this column with all other events having a '0'.
%             For non-flags, you can choose the min/max allowable values in column 11.
% *Alternately, you could change the read-in file part of the code.
%
% Format for pick files:
%
% Header line: ['QUAK' year month day hour min sec 'O']
% Pick line (arrival time): [station year month day hour min sec phase]
%
% ~ Change the velocity values in the model fit part to those relevant for your data.
%
% ~ File locations
%
% The file location algorithm needs to be updated based on the location of the
% files and formatting of file and folder names. This algorithm is not file-type
% specific (i.e. works for non-SAC files). The algorithm expects a
% directory system of event folders each containing the files relevant to
% that event (i.e. for each station and/or channel).
%
% ~ File type
%
% The program is currently set-up to only read SAC files. However, the
% GISMO Toolbox/Waveform Suite can handle other types of files. Refer to those
% manuals for information on how to read in non-SAC files. The only place
% that refers to file type is when initally reading in the waveforms from the file.

% --------------------

% By: Gabrielle Tepp, University of Rochester
% Created: 3/28/14
% Last updated: 6/14/16

%--------------------------------------------------------------------------%

disp(' ')
disp('Clearing workspace....')

clear all % start with clean slate (some variables may change in size from one run to the next)


%% ** Hard-wired directory info - Change when needed! **

% Folder name format: (directory)(evfolderstart)yyyy-mm-ddTHH.MM.SS.ss*
% Filename format: (directory)(folder)/(arr).(sta)..(cha)*yyyy-mm-ddTHH.MM.SS.ss(evfileend)
% Note: (folder) is from a list of available folder names generated in the code

% directory = '/Lowfreq/May2010/';
% evfolderstart = '';
% evfileend = '_vel.SAC';

% directory = '/gpfs/fs1/home/gtepp/Documents/KIVULF/';
% evfolderstart = '';
% evfileend = '*.SAC';

directory = '/Users/labuser/JWEED.dir/KIVU_all/';
evfolderstart = '';
evfileend = '*.SAC';

disp('*----------------------------------------*')
disp(' ')
disp('Folder name format: (directory)(folder start)yyyy-mm-ddTHH.MM.SS.ss*')
disp('Filename format: (directory)(folder)/(arr).(sta)..(cha)*yyyy-mm-ddTHH.MM.SS.ss(file end)')
disp(' ')
disp('Default file locations and set-up:')
disp(['directory: ' directory])
disp(['folder start: ' evfolderstart])
disp(['file end: ' evfileend])
disp(' ')
chdef = input('Change default values for this run? (Y or N): ','s');

if strcmpi(chdef,'Y') == 1
    
    disp(' ')
    directory = input('Which directory should be used?: ','s');
    evfolderstart = input('What folder start should be used?: ','s');
    evfileend = input('What file ending should be used?: ','s');
    
end


%% Get information from user (station, channel, start/end times)

% Prompt for event information

disp('*----------------------------------------*')
disp(' ')
disp('Please enter the following information.')
disp('Comma separate (no space) multiple entries for array/station/channel.')
disp('--------------------')
disp(' ')

params.arr.str = input('Enter the array code (* for all): ', 's');

params.sta.str = input('Enter a station(s) (* for all): ', 's');

disp(' ')
disp('1 - Horizontals (*HE & *HN)')
disp('2 - Vertical (*HZ)')
disp(' ')
chaop = input('Pick a channel option (integer, default 1): ');

% If not broadband (BH*), change these to needed format

if chaop == 2
    
    params.cha.str = 'HHZ';
    
else
    
    params.cha.str = '*HE,*HN';
    
end

disp(' ')
params.time.start.str = input('Enter a start date and time [dd-Mon yyyy HH:MM]: ','s');

params.time.end.str = input('Enter an end date and time [dd-Mon yyyy HH:MM]: ','s');

disp(' ')
evfile = input('Enter the event list file name (.mat): ','s');
disp('--------------------')

% if array/channel/station left empty, make wildcard

if isempty(params.arr.str) == 1
    
    params.arr.str = '*';
    
end

if isempty(params.sta.str) == 1
    
    params.sta.str = '*';
    
end

% Allow user to check waveforms and choose to keep or ignore

disp(' ')
checkwf = input('Would you like to check waveforms? (Y or N): ','s');

% Keep all waveforms if no check wanted (default N)

if strcmpi(checkwf,'Y') == 0
        
    keepwf = 'Y';
    
end

% Since this option is not important here, ignore it
% % Allow user to override all sample frequency mismatches (default N)
% 
% disp(' ')
% alloverride = input('Automatically override all sample frequency mismatches? (Y or N): ','s');

alloverride = 'Y';

evdata = importdata(evfile);


%% Make Vector Lists From Input Strings

% Convert array/station/channel input to usuable lists

params.arr.list = makelist(params.arr.str,'str');

params.sta.list = makelist(params.sta.str,'str');

params.cha.list = makelist(params.cha.str,'str');
    
% Choose to restrict data & make event list

disp(' ')
restdat = input('Would you like to restrict the events (R) or use all events in the file (A, default)?: ','s');

if strcmpi(restdat,'R') == 1
    
   params = restrict_data(evdata,params);
   
else
    
    % Create list of numbers for all events
    
    params.num.str = '*';
    params.num.list = transpose(1:length(evdata));
    
end

disp('--------------------')
disp(' ')


%% Find Event Folders

% Convert to serial day/time

params.time.start.serial = datenum(params.time.start.str);

params.time.end.serial = datenum(params.time.end.str);

params.time.start.vector = datevec(params.time.start.str);

params.time.end.vector = datevec(params.time.end.str);

% Make list of folders within date range

nodates = 1;

% Make list of year + month to search

year = params.time.start.vector(1,1);

while year <= params.time.end.vector(1,1)
    
    if year == params.time.start.vector(1,1) % starting month
        
        month = params.time.start.vector(1,2);

    else % start with January when year turns
        
        month = 1;
        
    end
    
    while (month <= params.time.end.vector(1,2) && year == params.time.end.vector(1,1)) ||...
            (month < 13 && year < params.time.end.vector(1,1)) % go until December or ending month
    
        % Make search string
        
        if month < 10 % put zero before single digit months
            
            monstr = strcat('0',num2str(month));
            
        else
            
            monstr = num2str(month);
            
        end
        
        ndat = strcat(num2str(year),'-',monstr);
        
        if nodates == 1
        
            nodates = 0;
            
            searchdates = ndat;
            
        else
            
            searchdates = vertcat(searchdates,ndat);
        
        end
        
        month = month + 1; % move to next month
    
    end
    
    year = year + 1; % move to next year
    
end

% Find folders within year & month range

for ond = 1:size(searchdates,1)

    allfolds = dir(strcat(directory,evfolderstart,searchdates(ond,:),'*'));

    % Put into matrix
    
    for j = 1:length(allfolds)
    
        if ond == 1 && j == 1

            foldnames = allfolds(1).name;
            
        else
            
            foldnames = vertcat(foldnames,allfolds(j).name);
            
        end
    
    end
    
end

% Calculate serial time for all folders

datestart = 1 + length(evfolderstart);
dateend = datestart + 18;

foldser = datenum(foldnames(:,datestart:dateend),'yyyy-mm-ddTHH.MM.SS');

firstev = 0; % Has first event been added to folder list?

%keepevs = 0; % start with no events on list

% Make folder name for each event

for n = 1:length(params.num.list)
    
    evn = params.num.list(n,1); % on this event
    
    evserial = datenum(evdata(evn,4:9));
    
% Only look for files if within given date range
    
if params.time.start.serial < evserial && evserial < params.time.end.serial    
    
    % Go through folder serial dates to find a match
    
    for chk = 1:size(foldser,1)
        
        % Check within +/- 4 sec
        
        if foldser(chk,1) > (evserial - (4 / 3600 /24)) && foldser(chk,1) < (evserial + (4 / 3600 /24))
            
            % If folder found, add event to 'good' list
            
            if firstev == 0
                
                folderlist = foldnames(chk,:);
                
                keepevs = evn;
                
                firstev = 1;
                
            else
                
                folderlist = vertcat(folderlist,foldnames(chk,:));
                
                keepevs = vertcat(keepevs,evn);
                
            end
            
            % Keep event info
            
            evnum = strcat('ev',num2str(evn));
            
            data.(evnum).data = evdata(evn,:);
            
            break; % exit loop
            
        end
        
    end

end
    
end

% Change event list to reflect 'good' events

params.num.list = keepevs;

% clear temporary variables

clear keepevs q n evnum firstev chaop evn foldnames foldser allfolds chk ond j;


%% Get files (and data) and make correlation object

% Access each file and make a correlation object with all events

disp('--------------------')
disp(' ')
disp('Building correlation object....')
disp(' ')

% Make list of relevant files in folder
    
firstwf = 0; % indicates if first waveform has been included yet (switch to 1 after inclusion)

evwfnum = zeros(size(folderlist,1),2);

for m = 1:size(folderlist,1)

for a = 1:size(params.arr.list,1)
    
    arr = params.arr.list(a,:);
        
for s = 1:size(params.sta.list,1)
    
    sta = params.sta.list(s,:);
            
for c = 1:size(params.cha.list,1)
    
    cha = params.cha.list(c,:);

folderfile = strcat(directory,folderlist(m,:),'/',arr,'.',sta,'..',cha,evfileend); % Which files

filelist = dir(folderfile); % Make list of relevant files

numfiles = length(filelist);

% Look through each folder for files and add waveforms to correlation object

% Build correlation object

for k = 1:numfiles
    
    filename = strcat(directory,folderlist(m,:),'/',filelist(k).name);
    
    % Get correct channel
    
    chastart = length(directory) + length(folderlist(m,:)) + 11;
    
    chaend = chastart + 2;
    
    cha = filename(chastart:chaend);
    
    scnl = scnlobject(sta,cha,'*','*'); % Create SCNL object
    
    ds = datasource('sac', filename);
    
    w = waveform(ds,scnl,params.time.start.serial,params.time.end.serial); % create waveform from file
    
    if strcmpi('Y',checkwf) == 1
        
        plot(w);
    
        disp(' ')
        keepwf = input(['Would you like to keep waveform ' num2str(m) '-' num2str(k) '? (N or Y): '],'s'); % (default Y)
        
    else % check to see if there's actually data
        
        dl = get(w,'Data_Length');
        
        if dl > 24 % if there are at least 24 data points (required for filtering)
            
            keepwf = 'Y';
            
        else
            
            keepwf = 'N';
            
        end
        
    end
    
if strcmpi('N',keepwf) == 0
        
    evwfnum(m,1) = params.num.list(m); % add event number to list
    
    % Add waveforms to events matrix
    
    if firstwf == 0
        
        w1freq = get(w,'freq');
        
        trig1 = datenum(get(w,'start_str'),'yyyy-mm-dd HH:MM:SS.FFF',2005);

        cobj = correlation(w,trig1); % create correlation object from waveform
    
        allcobj = cobj;
        
        firstwf = 1;
        
        evwfnum(m,2) = evwfnum(m,2) + 1; % count waveforms per event
        
    else
        
        wfreq = get(w,'freq');
            
        trig = datenum(get(w,'start_str'),'yyyy-mm-dd HH:MM:SS.FFF',2005);
    
    % Only add to master if sampling frequency is the same as event 1
        
    if wfreq == w1freq
        
       cobj = correlation(w,trig); % create correlation object from waveform 
        
       allcobj = cat(allcobj,cobj);
       
       evwfnum(m,2) = evwfnum(m,2) + 1; % count waveforms per event
       
    else
       
       disp('--------------------')
       disp(' ')
       disp(['Event 1 freq = ' num2str(w1freq) ' & Event ' num2str(m) '-' num2str(k) ' freq = ' num2str(wfreq)]);
       
       if strcmpi(alloverride,'Y') == 1
           
           freqer = 'Y';
           
       else
       
           disp(' ')
           freqer = input('There is a frequency mismatch. Override? (Y or N): ','s'); % (default N)
       
       end
       
       if strcmpi(freqer,'Y') == 1
       
            wnew = set(w,'freq',w1freq);
        
            cobj = correlation(wnew,trig); % create correlation object from waveform 
        
            allcobj = cat(allcobj,cobj);
            
            evwfnum(m,2) = evwfnum(m,2) + 1; % count waveforms per event
            
       else
           
           disp(' ')
           disp(['Event ' num2str(k) ' was not added not correlation object.'])
           
       end
    
    end
    
    end
    
end

end

end

end

end

end

% Remove any events without waveforms

evwfnum = evwfnum(find(evwfnum(:,2) ~= 0),:);

% Replace params.num.list with list of events found

params.num.list = evwfnum(:,1);

% Get waveform type

wftype = get(w,'UNITS');

disp(' ')
disp('--------------------')
disp(' ')
disp(['Waveforms are in units of ' wftype '.'])

% Clear temporary variables

clear filelist folderlist cobj w wnew w1freq wfreq HH MM SS trig trig1;
clear evfile evfolder evserial filename folderfile evdates evdt evfile evfolder;


%% Cropping, (Initial) Filtering and Plotting

%plot(allcobj,'wig',1);

disp(' ')
vel2disp = input('Integrate waveforms? (Y or N): ','s');

if strcmpi(vel2disp,'Y') == 1
    
    allcobj = integrate(allcobj);
    
    plot(allcobj,'wig',1);
    
end

[allcobj,params] = filtcrop(allcobj,params,'wig');


%% Create Narrow-band filters

disp(' ')
disp('--------------------')
disp(' ')
filtnum = input('How many narrow-band filters would you like to use? (choose 2 for FI, integer): '); % no default

% no default - error message and force input

while isempty(filtnum) == 1
    
    disp(' ')
    disp('* Error: Please enter an integer value. *')
    disp(' ')
    filtnum = input('How many narrow-band filters would you like to use? (integer): ');
    
end

disp(' ')
picknb = input('Distribute narrow-bands: manually (m), evenly (e), or logarithmically (l)?: ','s'); % default l

if isempty(picknb) == 1
    
    picknb = 'l';
    
end

% Get bounds and center frequency for each filter

params.nbands = nbfilts(filtnum,picknb);

disp(' ')
disp('--------------------')

% Clear temporary variables

clear picknb


%% Apply Filters & Calculate Hilbert Transform & Envelopes

disp(' ')
disp('Applying filters and calculating envelopes....')

for nbf = 1:(filtnum+1)
    
    if nbf <= filtnum
    
        disp(' ')
        disp(['Working on filter ' num2str(nbf) ' of ' num2str(filtnum) '....'])
        
        % Apply filters

        nbfcobj = butter(allcobj,[params.nbands(nbf,1) params.nbands(nbf,2)]); % Default as 4-pole filter
        % Note: filter runs forward & backward, effectively doubling # of poles

        allwf = waveform(nbfcobj); % change correlation object to waveform object

        % First, calculate Hilbert transform (hil)

        hilb = hilbert(allwf);
        
        % Name for narrow-band

        nb = strcat('nb',num2str(nbf));
        
    else
        
        disp(' ')
        disp('Saving unfiltered waveforms....')
        
        allwf = waveform(allcobj); % change correlation object to waveform object
        
    end

    % Sort Waveforms by Event

    endr = 0;
    
    for h = 1:length(params.num.list)

        evnum = strcat('ev',num2str(evwfnum(h,1)));

        startr = 1 + endr;

        endr = startr + evwfnum(h,2) - 1;
    
        nosta = 1;
        
        cha = 1;
        
        % Get all waveforms of event from correlation object

        for hnum = startr:endr

            station = get(allwf(hnum),'station');
            channel = get(allwf(hnum),'channel');
            
            % Only make station list during 1st filter application
            
            if nbf == 1
            
                if nosta == 1
                    
                    data.(evnum).stalist = station;
                    
                    %disp(['Event ' evnum ' is on ' station '.'])
                    
                    nosta = 0;
                    
                else
                    
                    data.(evnum).stalist = vertcat(data.(evnum).stalist,station);
                    
                end
            
            end

            if strcmpi(channel(3),'E') == 1 || strcmpi(channel(3),'Z') == 1

                cha = 1;

            elseif strcmpi(channel(3),'N') == 1

                cha = 2;

            end

            if cha == 1

                if nbf <= filtnum
                
                    data.(evnum).(station).wf.(nb) = allwf(hnum);
                    data.(evnum).(station).hil.(nb) = hilb(hnum);   
                
                else
                    
                    data.(evnum).(station).wf.nb0 = allwf(hnum);
                    
                end

            elseif cha == 2

                if nbf <= filtnum
                    
                    data.(evnum).(station).wf.(nb) = vertcat(data.(evnum).(station).wf.(nb),allwf(hnum));
                    data.(evnum).(station).hil.(nb) = vertcat(data.(evnum).(station).hil.(nb),allwf(hnum));
                
                else
                    
                    data.(evnum).(station).wf.nb0 = vertcat(data.(evnum).(station).wf.nb0,allwf(hnum));
                    
                end
                
            end

        end

        % Work on station list during 1st filter
        
        if nbf == 1
        
            % Make sure station list only has one entry for each station
            
            data.(evnum).stalist = unique(data.(evnum).stalist,'rows');
            
            % Add new stations to "universal" station list
            
            if h == 1 % start list with 1st event
                
                params.sta.list = data.(evnum).stalist;
                
            else
            
                params.sta.list = unique(vertcat(params.sta.list,data.(evnum).stalist),'rows');
            
            end
        
        end
        
        if nbf <= filtnum

            % Calculate envelope for each channel

            for ns = 1:size(data.(evnum).stalist,1)

                station = data.(evnum).stalist(ns,:);

                data.(evnum).(station).env.(nb) = zeros(size(params.cha.list,1),...
                    length(get(data.(evnum).(station).wf.(nb)(1,1),'data')));

                for cr = 1:size(params.cha.list,1)

                    % Make envelope

                    data.(evnum).(station).env.(nb)(cr,:) = transpose(sqrt((get(data.(evnum).(station).wf.(nb)(cr,:),...
                        'data')).^2 + (get(data.(evnum).(station).hil.(nb)(cr,:),'data')).^2));

                    % Take log 10 of envelope

                    data.(evnum).(station).env.(nb)(cr,:) = log10(data.(evnum).(station).env.(nb)(cr,:));

                end

            end
        
        end
    
    end

end 

% Get sampling frequencies for later use & Other Data

disp(' ')
disp('--------------------')
disp(' ')

% Ask where to get phase picks from

whichpick = input('Get phase picks from waveform headers (h) or from a *.mat file (f)?: ','s'); % default file

if strcmpi(whichpick,'h') == 0
    
    disp(' ')
    pickfile = input('What is the name of the pick file (*.mat)?: ','s');
    
end

disp(' ')
disp('Getting event data....')

for h = 1:length(params.num.list)

    evnum = strcat('ev',num2str(params.num.list(h,1)));
    
    for ns = 1:size(data.(evnum).stalist,1)
        
        station = data.(evnum).stalist(ns,:);
        
        data.(evnum).(station).sfreq = get(data.(evnum).(station).wf.nb0(1,1),'FREQ'); % get event sampling frequency
        % get waveform start time (account for crop time [in days] to stay consistent with picks from SAC headers)
        data.(evnum).(station).wfstart = datenum(get(data.(evnum).(station).wf.nb0(1,1),'start_str'),'yyyy-mm-dd HH:MM:SS.FFF') - params.crop.start / 3600 / 24; 
        
        % Get picks from headers or mark as NaN for now and use function getpicks outside of loop
        
        if strcmpi(whichpick,'h') == 1
            
            data.(evnum).(station).spick = get(data.(evnum).(station).wf.nb0(1,1),'T2'); % get event S-wave pick
            data.(evnum).(station).ppick = get(data.(evnum).(station).wf.nb0(1,1),'T1'); % get event P-wave pick
            
        else
            
            data.(evnum).(station).spick = NaN; % get event S-wave pick
            data.(evnum).(station).ppick = NaN; % get event P-wave pick
            
        end
        
        % calculate travel time for models with Q
        
        if size(params.cha.list,1) == 2
            
            data.(evnum).(station).ttime = data.(evnum).(station).spick - get(data.(evnum).(station).wf.nb0(1,1),'O');
            
        elseif size(params.cha.list,1) == 1
            
            data.(evnum).(station).ttime = data.(evnum).(station).ppick - get(data.(evnum).(station).wf.nb0(1,1),'O');
            
        end
        
    end
    
    data.(evnum).data = evdata(params.num.list(h,1),:);
    
end

% If picks needed from a file, call function to get picks

if strcmpi(whichpick,'h') == 0
    
    gdpicks = 0;
    
    while gdpicks == 0
    
    [data] = getpicks(pickfile,params.num.list,data);
    
    % Decide what to do with events without picks
    
    disp(' ')
    nopicks = input('For events without picks, use default picks (d) or toss out (t)?: ','s'); % default toss out
    
    if strcmpi(nopicks,'d') == 1
        
        for h = 1:length(params.num.list)
            
            evnum = strcat('ev',num2str(params.num.list(h,1)));
            
            for ns = 1:size(data.(evnum).stalist,1)
                
                station = data.(evnum).stalist(ns,:);
                
                % If there is currently no pick, get pick from header
                
                if isnan(data.(evnum).(station).spick) == 1
                    
                    data.(evnum).(station).spick = get(data.(evnum).(station).wf.nb0(1,1),'T2'); % get event S-wave pick
                    
                end
                
                if isnan(data.(evnum).(station).ppick) == 1
                    
                    data.(evnum).(station).ppick = get(data.(evnum).(station).wf.nb0(1,1),'T1'); % get event P-wave pick
                    
                end
                
                % Mark all events as good
                
                data.(evnum).(station).bad = 0;
                
            end
            
        end
        
    else
        
        badct = 0; % counter for bad events
        
        for h = 1:length(params.num.list)
            
            evnum = strcat('ev',num2str(params.num.list(h,1)));
            
            for ns = 1:size(data.(evnum).stalist,1)
                
                station = data.(evnum).stalist(ns,:);
                
                % If there isn't a pick for current phase type, mark as bad
                
                if (isnan(data.(evnum).(station).spick) == 1 && size(params.cha.list,1) == 2) ||...
                        (isnan(data.(evnum).(station).ppick) == 1 && size(params.cha.list,1) == 1)
                    
                    data.(evnum).(station).bad = 1;
                    
                    badct = badct + 1;
                    
                else % otherwise, mark as good
                    
                    data.(evnum).(station).bad = 0;
                    
                    %disp(['Event ' evnum ' is good.'])
                    
                end
                
            end
            
        end
        
    end
    
    disp(' ')
    disp(['There are ' num2str(badct) ' of ' num2str(length(params.num.list)) ' events without picks that will be tossed.'])
    
    if length(params.num.list) == badct
        
        disp(' ')
        disp('** Uh oh... No picks were found.')
        disp(' ')
        newf = input('Get picks from headers (h), end program (e), or choose a different pick file (f)?: ','s'); % default f
        
        if strcmpi(newf,'h') == 1 % get picks from header
            
            for h = 1:length(params.num.list)
                
                evnum = strcat('ev',num2str(params.num.list(h,1)));
                
                for ns = 1:size(data.(evnum).stalist,1)
                    
                    station = data.(evnum).stalist(ns,:);
                    
                    % If there is currently no pick, get pick from header
                    
                    if isnan(data.(evnum).(station).spick) == 1
                        
                        data.(evnum).(station).spick = get(data.(evnum).(station).wf.nb0(1,1),'T2'); % get event S-wave pick
                        
                    end
                    
                    if isnan(data.(evnum).(station).ppick) == 1
                        
                        data.(evnum).(station).ppick = get(data.(evnum).(station).wf.nb0(1,1),'T1'); % get event P-wave pick
                        
                    end
                    
                    % Mark all events as good
                    
                    data.(evnum).(station).bad = 0;
                    
                end
                
            end
            
        elseif strcmpi(newf,'e') == 1
            
            return; % end script
            
        else
            
            disp(' ')
            pickfile = input('What is the name of the pick file (*.mat)?: ','s');
            
        end
        
    else
        
        gdpicks = 1;
        
    end
    
    end
    
else % if picks from header, mark all as good
    
     for h = 1:length(params.num.list)
         
         evnum = strcat('ev',num2str(params.num.list(h,1)));
         
         for ns = 1:size(data.(evnum).stalist,1)
             
             station = data.(evnum).stalist(ns,:);
             
             data.(evnum).(station).bad = 0;
             
         end
         
     end
     
end

% no longer need evdata, so clear it

clear evdata evwfnum;

smth = 'Y';

% Average horizontal envlopes (if applicable) & smooth result

while strcmpi(smth,'Y') == 1

disp(' ')
disp('--------------------')
disp(' ')

if size(params.cha.list,1) == 1
    
    disp('The envelopes in each band will now be smoothed with a moving average filter (mav).')
    
else

    disp('The horizontal component envelopes in each band will now be')
    disp('   averaged and smoothed with a moving average filter (mav).')

end

disp(' ')
mavwin = input('How many samples should the mav window span? (odd integer, default 301): '); % default 301

if isempty(mavwin) == 1
    
    mavwin = 301;
    
end

for ev = 1:length(params.num.list)
    
    evr = strcat('ev',num2str(params.num.list(ev,1)));
    
    disp(' ')
    disp(['Working on event ' num2str(ev) ' of ' num2str(length(params.num.list)) '....'])
    
    for star = 1:size(data.(evr).stalist,1)
    
        cursta = data.(evr).stalist(star,:);
        
        for nbr = 1:filtnum

            nb = strcat('nb',num2str(nbr));
            
            if size(params.cha.list,1) == 1
                
                envel = data.(evr).(cursta).env.(nb)(1,:);
                
            else
            
                % Average envelopes of horizontals (E&N)

                envel = (data.(evr).(cursta).env.(nb)(1,:) + data.(evr).(cursta).env.(nb)(2,:)) / 2;
            
            end

            % Smooth averaged envelope (moving average filter)
            
            if nbr == 1
            
                data.(evr).(cursta).allenv = transpose(smooth(envel,mavwin));
                
            else
                
                data.(evr).(cursta).allenv = vertcat(data.(evr).(cursta).allenv,...
                    transpose(smooth(envel,mavwin)));
              
            end
            
        end

        clear envel
        
    end
        
end

% Clear temporary variables

clear allwf hilb nbfcobj allcobj;


%% Make Envelope Plots

codabad = 'Y';

while strcmpi(codabad,'Y') == 1

disp('--------------------')
disp(' ')
disp('Options for amplitude measurement start:')
disp('1 - S-wave pick (default for horizontals)')
disp('2 - P-wave pick (default for vertical)')
disp('3 - Choose your own (not yet available)')
disp(' ')
ampstrtop = input('Pick an option (integer): ');

if isempty(ampstrtop) == 1
    
    if size(params.cha.list,1) == 2
        
        ampstrt = 'spick';
        
    elseif  size(params.cha.list,1) == 1
        
        ampstrt = 'ppick';
        
    end
    
else

    if ampstrtop == 1

        ampstrt = 'spick';

    elseif ampstrtop == 2

        ampstrt = 'ppick';

    else

        ampstrt = 'spick'; % add option to choose start later - for now, default to S-pick

    end

end

ampmlen = input('How long (sec) do you want the measurement? (double): ');

while isempty(ampmlen) == 1
    
   disp(' ')
   disp('** You must enter a measurement length. Please try again. **')
   disp(' ') 
   ampmlen = input('How long (sec) do you want the measurement? (double): ');
   
end

disp('--------------------')
disp(' ')
plenv = input('Plot envelope results? (N or Y): ','s'); % default Y

while strcmpi(plenv,'N') == 0

    evpl = 0;
    
    if length(params.num.list) == 1
        
        evpl = params.num.list;
        
    else
        
        while evpl == 0

            disp(' ')
            
            if isempty(params.num.str) == 0
            
                disp(['You chose events ' params.num.str])
            
            else
            
                disp('You chose all data.')
                disp(['Event numbers are ' num2str(params.num.list(1,1)) ' to ' num2str(params.num.list(length(params.num.list),1)) '.'])
                
            end
            
            disp(' ')
            evpl = input('Which event would you like to plot (integer): ');
            
            if isempty(evpl) == 1
                
                disp(' ')
                disp('Oops! You didn''t choose an event.')
                disp('Please try again.')
                
                evpl = 0;
                
            elseif isempty(find(params.num.list == evpl,1)) == 1
                
                disp(' ')
                disp('Oops! This event is not available.')
                disp('Please try again.')
                
                evpl = 0;
                
            end
     
        end
        
    end
    
    disp(' ')
    disp('Your narrowband filters are:')
    disp(' ')
   
    for fn = 1:filtnum
    
        disp([num2str(fn) '.) ' num2str(params.nbands(fn,1)) ' to ' num2str(params.nbands(fn,2))])
    
    end
    
    disp(' ')
    disp('** Entry format example: 6:10 or 6/7/8/9/10 or 6/7:9/10 or * for all')
    disp(' ')
    filtplot = input('Which narrow-band filters do you want to plot? (default all): ','s');
    disp(' ')
    
    % Plot waveforms above envelopes?
    
    plwf = input('Plot event waveforms above envelopes? (N or Y): ','s');
    
    evnum = strcat('ev',num2str(evpl));
    
    % Create list of narrow-band filters for plotting
    
    if strcmpi(filtplot,'*') == 1 || isempty(filtplot) == 1
        
    % Create list of numbers for all events
    
        plfilt = transpose(1:size(params.nbands,1));

    else 

        plfilt = makelist(filtplot,'num');
    
    end

%     % How to divide plots?
%     
%     disp(' ')
%     subtype = input('Sort sub-plots with 1 event (e) or 1 station (s) per figure?: ','s');
     
    % Figure out how many col/row for sub-plots
    
    stanum = size(data.(evnum).stalist,1);

    if stanum == 1

        col = 1;
        row = 1;
        rowpg = 1;

    else

        [row,col,rowpg] = subplotpar(stanum,'stations');

    end
    
    % When plotting waveforms + envelopes, need twice as many rows
    
    if strcmpi(plwf,'N') == 0
       
        rowpg = rowpg * 2;
        
        row = row * 2;
        
    end
    
    disp(' ')
    disp('Plotting....')
    
    % Make new figure window

    figure;

    title(['Waveform Envelopes for event ',evpl]);
    
    fignum = ceil(row/rowpg);

    onfig = 1;
    
    % Make colormap
    
    cmp = makecmp(params.nbands);
    
    % Make plot(s)

    for onsta = 1:stanum
        
        staname = data.(evnum).stalist(onsta,:);

        % Make time vector for x-axis

        time = 0:length(data.(evnum).(staname).allenv)-1;

        time = time / data.(evnum).(staname).sfreq + params.crop.start;
        
        % Plot waveform (if wanted)
   
        if strcmpi(plwf,'N') == 0
        
            wfspnum = onsta - (rowpg*col)*(onfig - 1) + col*(ceil(onsta/col) - 1); % sub-plot number for figure
            
            subplot(rowpg,col,wfspnum);
            
            hold on;
            
            plot(time,get(data.(evnum).(staname).wf.nb0(1,1),'data'),'-','Color','b')

            % Plot line marking S-wave pick & coda end (S-pick + 20 sec)

            mstrt = data.(evnum).(staname).(ampstrt);

            y = [min(get(data.(evnum).(staname).wf.nb0(1,1),'data')),max(get(data.(evnum).(staname).wf.nb0(1,1),'data'))];
            plmstrt = ones(length(y),1) * mstrt;
            ampm = ones(length(y),1) * (mstrt + ampmlen);

            hold on;

            grid on;

            plot(plmstrt,y,'-','color','k');   

            plot(ampm,y,'-','color','k');
            
            % Title
        
            title({['Station: ',staname],['Measurement start: ',num2str(mstrt),' s']})
            
        end
              
        % Plot envelope

        if strcmpi(plwf,'N') == 1
        
            spnum = onsta - (rowpg*col)*(onfig - 1); % sub-plot number for figure
        
        else
            
            spnum = col + wfspnum; % sub-plot number for figure
            
        end
        
        subplot(rowpg,col,spnum);
        
        hold on;
        
        for onnb = 1:filtnum

            plot(time,data.(evnum).(staname).allenv(onnb,:),'-','Color',cmp(onnb,:))
        
        end

        % Plot line marking measurement start & end

        mstrt = data.(evnum).(staname).(ampstrt);

        y = [0,(max(max(data.(evnum).(staname).allenv(:,:)))+0.5)];
        plmstrt = ones(length(y),1) * mstrt;
        ampm = ones(length(y),1) * (mstrt + ampmlen);

        hold on;
        
        grid on;

        plot(plmstrt,y,'-','color','k');   
        
        plot(ampm,y,'-','color','k');
        
        % Labels & legend
        
        if strcmpi(plwf,'N') == 1

            title({['Station: ',staname],['Measurement start: ',num2str(mstrt),' s']})
            
        end

        xlabel('Time (s)')
        ylabel('Non-dim Amplitude') 
        
        % Set colormap
        
        set(gca,'ColorOrder',cmp);
        
        % Make legend labels & plot legend
        
        clear ll; % reset legend labels
        
        for rn = 1:size(plfilt,1)
                
            ll{rn,:} = [num2str(params.nbands(plfilt(rn),1)),' to ',num2str(params.nbands(plfilt(rn),2)),' Hz'];
            
        end
        
        legend(ll,'location','EastOutside');
        
        % When figure filled, move to next one

        if strcmpi(plwf,'N') == 1
        
            if rem(onsta,(rowpg*col)) == 0 && onfig ~= fignum

                figure;

                title(['Waveform Envelopes for event ',evpl]);

                onfig = onfig + 1;

            end
        
        else
            
           if rem(onsta,(rowpg*col/2)) == 0 && onfig ~= fignum
              
                figure;

                title(['Waveform Envelopes for event ',evpl]);
            
                onfig = onfig + 1;
               
           end
            
        end
    
    end
    
    clear evpl evnum; % reset some variables
    
    disp(' ')
    plenv = input('Would you like to make another plot? (Y or N): ','s'); % default N
    
    if isempty(plenv) == 1
        
        plenv = 'N';
        
    end

end

disp(' ')
codabad = input('Would you like to change the measurement length? (Y or N): ','s');

end

% Try a different smoothing window

disp(' ')
smth = input('Would you like to try a different smoothing window? (Y or N): ','s'); % default N

% if yes, clear current envelopes

if strcmpi(smth,'Y') == 1

    for evt = 1:size(params.num.list,1)

        evr = strcat('ev',num2str(params.num.list(h,1)));

        for stn = 1:size(data.(evr).stalist,1);

            cursta = data.(evr).stalist(stn,:);

            clear data.(evr).(cursta).allenv

        end

    end

end

end


%% Calculate Amplitude Values for Chosen Interval 

ampreset = 1;

setnpar = 'Y';

while ampreset == 1

disp(' ')
disp('--------------------')
disp(' ')
disp('Calculating amplitudes for chosen interval...')

for e = 1:length(params.num.list)
    
    evnum = strcat('ev',num2str(params.num.list(e,1)));
    
    for st = 1:size(data.(evnum).stalist,1)
        
        station = data.(evnum).stalist(st,:);
        
        % Check to make sure event is good
        
        if data.(evnum).(station).bad == 0
            
            % Determine sample number limits of coda
            
            % start at desired value
            
            codastrt = ceil((data.(evnum).(station).(ampstrt) - params.crop.start) * data.(evnum).(station).sfreq);
            % round up to nearest integer; subtract off intial crop value
            
            % if coda start is <1, flag event
            
            if codastrt < 1
                
                data.(evnum).(station).bad = 1;
                
            end
            
            % end after chosen interval
            
            codaend = codastrt + ceil(ampmlen * data.(evnum).(station).sfreq);
            
            if data.(evnum).(station).bad == 0 % make sure event and pick are good
                
                for nbr = 1:filtnum
                    
                    % Find average amplitude of coda
                    
                    if nbr == 1
                        
                        data.(evnum).(station).cavg = sum(data.(evnum).(station).allenv(nbr,codastrt:codaend))...
                            / (codaend - codastrt + 1);
                        
                    else
                        
                        data.(evnum).(station).cavg = vertcat(data.(evnum).(station).cavg,...
                            (sum(data.(evnum).(station).allenv(nbr,codastrt:codaend)) / (codaend - codastrt + 1)));
                        
                    end
                    
                    % Check amplitude value & get rid of any less than or equal to zero
                    
                    if data.(evnum).(station).cavg(nbr,1) <= 0
                        
                        data.(evnum).(station).cavg(nbr,1) = NaN;
                        
                    end
                    
                end
                
            end
            
        else % if event is bad, mark cavg as NaN
            
            for nbr = 1:filtnum

                data.(evnum).(station).cavg(nbr,1) = NaN;
                
            end
            
        end
        
    end
    
end


%% Check SNR

disp(' ')
disp('--------------------')
disp(' ')
chksnr = input('Would you like to check signal-to-noise ratios? (N or Y): ','s');

badevs = 0;

if strcmpi(chksnr,'N') == 0
    
    while strcmpi(setnpar,'Y') == 1
        
        disp(' ')
        disp('Determine the bounds for the noise measurement.')
%         disp(' ')
%         chkpl = input('Would you like to check a plot of waveforms? (Y or N): ','s');
%         
%         if strcmpi(chkpl,'Y') == 1
%             
%             plot(allcobj,pltype,1,perm);
%             
%         end
        
        % Set time bounds for noise measurement
        
        disp(' ')
        noiseop = input('End noise measurement at a chosen time (t), at a delay preceding the P-pick (d), or at P-pick (p)?: ','s'); % default p
                
        % Ask what to do if no P-pick is available
        
        disp(' ')
        noppick = input('If no P-pick available, use P-pick from header (h), choose from waveform (w - N/A), or set a default time (t)?: ','s'); % default t
        
        while strcmpi(noppick,'w') == 1
            
            disp(' ')
            disp('This option is not yet developed.')
            disp(' ')
            %altop = input('Choose a time (t) or get P-pick from header (h)?: ','s');
            noppick = input('If no P-pick available, use P-pick from header (h), choose from waveform (w - N/A), or set a default time (t)?: ','s'); % default t
            
        end
        
        if strcmpi(noppick,'h') == 0 && strcmpi(noppick,'w') == 0
            
            disp(' ')
            tempp = input('What default P-pick time would you like to use? (double, in seconds): ');
            
        end
        
        % Get noise end time
        
        if strcmpi(noiseop,'t') == 1
            
            disp(' ')
            noiseend = input('What time should the noise measurement end? (double): ');
            
        elseif strcmpi(noiseop,'d') == 1
            
            disp(' ')
            noisedel = input('How long before the P-pick should the measurement end? (double): ');
            
        end
        
        % Get noise measurement length
                
        disp(' ')
        noiselen = input('How long should the noise measurement be? (double): ');
        
        setnpar = 'N';
        
    end
    
    disp(' ')
    snrbd = input('What is the minimum allowable SNR? (double, default 1): ');

    if isempty(snrbd) == 1

        snrbd = 1;

    end
    
    badevs = 0; % count bad events
    
    badlist = cell(1,2);
    
    goodevs = 0; % count good events
    
    % Get SNR for each event at each station
    
    for e = 1:length(params.num.list)
        
        evnum = strcat('ev',num2str(params.num.list(e,1)));
        
        for st = 1:size(data.(evnum).stalist,1)
                            
            station = data.(evnum).stalist(st,:);
                
            % Make sure event is good on station
            
            if data.(evnum).(station).bad == 0
                
                NaNnum = 0; % reset for each station

                % Determine sample number limits of noise measurement
                
                % Start and end at chosen bounds
                % round up to nearest integer; subtract off intial crop value
                
                % Set end bound & check for P-pick if used
                
                if strcmpi(noiseop,'t') == 0
                    
                    % Assign P-pick if needed
                    
                    if isnan(data.(evnum).(station).ppick) == 1
                        
                        if strcmpi(noppick,'h') == 1
                            
                            tempp = get(data.(evnum).(station).wf.nb0(1,1),'T1');
                            
                        elseif strcmpi(noppick,'w') == 1
                            
                            % Develop this further - plot waveform and allow for p-pick choice
                            
                        end
                        
                    else
                        
                        tempp = data.(evnum).(station).ppick;
                        
                    end
                    
                    if strcmpi(noiseop,'d') == 1 % if delay chosen, then account for it
                        
                        noiseend = tempp - noisedel;
                        
                    else
                        
                        noiseend = tempp;
                        
                    end
                    
                end
                
                nstrt = ceil((noiseend - noiselen - params.crop.start) * data.(evnum).(station).sfreq);
                
                % make sure bound does not start at point 0 (or is negative)
                
                if nstrt <= 0
                    
                    nstrt = 1;
                    
                end
                
                nend = ceil((noiseend - params.crop.start) * data.(evnum).(station).sfreq);
                
                for nbr = 1:filtnum
                    
                    % Find average amplitude of noise
                    
                    nlvl = sum(data.(evnum).(station).allenv(nbr,nstrt:nend)) / (nend - nstrt + 1);
                    
                    % Calculate SNR
                    
                    if nbr == 1
                        
                        % since we have log amplitudes, subtract then convert to "true" SNR
                        
                        data.(evnum).(station).snr = 10^(data.(evnum).(station).cavg(nbr,1) - nlvl);
                        
                    else
                        
                        data.(evnum).(station).snr = vertcat(data.(evnum).(station).snr,...
                            10^(data.(evnum).(station).cavg(nbr,1) - nlvl));
                        
                    end
                    
                    % Compare SNR to allowed value; if smaller, replace coda amp with NaN
                    % Or if amp is <0, also replace with NaN
                    
                    if data.(evnum).(station).snr(nbr,1) < snrbd %|| data.(evnum).(station).cavg(nbr,1) < 0
                        
                        data.(evnum).(station).cavg(nbr,1) = NaN;
                        
                        NaNnum = NaNnum + 1; % keep track of number of NaN values
                        
                    end
                    
                end
                
                % Flag event if fewer than 2 non-NaN values remain
                
                if (filtnum - NaNnum) < 2
                    
                    disp(' ')
                    disp(['Event ' num2str(params.num.list(e,1)) ' has < 2 non-NaN values and will be flagged.']);
                    
                    %disp(' ')
                    %disp(['SNR values are: ' num2str(transpose(data.(evnum).(station).snr))])
                    
                    %data.(evnum).(station).bad = 1;
                    
                    badevs = badevs + 1;
                    
                    % Make list of bad events to flag once SNR bounds set
                    
                    badlist{badevs,1} = evnum;
                    badlist{badevs,2} = station;
                    
                else
                    
                    %data.(evnum).(station).bad = 0;
                    
                    goodevs = goodevs + 1;
                    
                end
                
            end
            
        end
        
    end
    
    disp(' ')
    disp(['There are ' num2str(badevs) ' bad events out of ' num2str((goodevs+badevs)) ' total.'])
    disp(' ')
    disp('Amplitudes will be recalculated if SNR is changed.')
    disp(' ')
    chksnr = input('Would you like to change the acceptable signal-to-noise ratio? (Y or N): ','s');
    
    if strcmpi(chksnr,'Y') == 0
        
        ampreset = 0; % keep SNR & don't repeat amplitude calulation

        % Keep and flag bad events
        
        if badevs ~= 0
            
            for badn = 1:badevs
                
                data.(badlist{badn,1}).(badlist{badn,2}).bad = 1;
                
            end
            
        end
        
        % Ask if noise should be removed from measurements
        
        disp(' ')
        nonoise = input('Would you like to remove the noise from the amplitudes? (Y or N): ','s');
        
        if strcmpi(nonoise,'Y') == 1
  
            for e = 1:length(params.num.list)
                
                evnum = strcat('ev',num2str(params.num.list(e,1)));
                
                for st = 1:size(data.(evnum).stalist,1)
                    
                    station = data.(evnum).stalist(st,:);
                    
                    % Make sure event is good at station
                    
                    if data.(evnum).(station).bad == 0
                        
                        for nbr = 1:filtnum
                            
                            % if value isn't NaN and SNR > 1 - to avoid imaginary numbers
                            
                            if isnan(data.(evnum).(station).cavg(nbr,1)) == 0 && data.(evnum).(station).snr(nbr,1) > 1
                                
                                data.(evnum).(station).cavg(nbr,1) = data.(evnum).(station).cavg(nbr,1) + log10(1 -...
                                    (1/data.(evnum).(station).snr(nbr,1)));
                                
                            end
                            
                        end
                        
                    end
                    
                end
                
            end
            
        end
    
    else % If reseting SNR, ask whether to reset noise measurement parameters
        
        disp(' ')
        setnpar = input('Would you like to reset the noise measurement parameters? (Y or N): ','s');
        
    end

else
    
    % Kepp amplitudes as they are
    
    ampreset = 0;
    
end

end

% Remove events that are bad on all stations

disp(' ');
disp('Removing events that are bad on all stations....')

evlist = 0;

for e = 1:length(params.num.list)
    
    evnum = strcat('ev',num2str(params.num.list(e,1)));
    
    stabad = 0; % reset counter for each event
    
    % Count bad stations
    
    for st = 1:size(data.(evnum).stalist,1)
        
        station = data.(evnum).stalist(st,:);
        
        if data.(evnum).(station).bad == 1
            
            stabad = stabad + 1;
            
        end
        
    end
    
    % If all stations are bad, remove field
    
    if stabad == size(data.(evnum).stalist,1)
        
        % Remove field
        
        data = rmfield(data,evnum);
        
    else % if good add to event list
        
        if evlist == 0
        
            evlist = params.num.list(e,1);
         
        else
            
            evlist = vertcat(evlist,params.num.list(e,1));
            
        end
        
    end
    
end

% Update event list

clear params.num.list

params.num.list = evlist;

% Clear temporary variables

clear evlist setnpar stabad badlist badevs badn goodevs station evnum e nonoise ampreset chksnr NaNnum;
clear tempp nstrt nend nlvl noiseend noiseop noisedel noiselen altop noppick snrbd codaend codastrt;


%% Frequency Index Calculation

if filtnum == 2 % if only 2 nb filters, assume it's a FI calculation
    
    disp('--------------------')
    disp(' ')
    disp('Calculating the frequency index for each event....')
    
    % Calculate FI for each event at each station and averaged over all stations
    
    for e = 1:length(params.num.list)
        
        % reset for each event
        FIsum = 0; 
        total = 0;
        
        evnum = strcat('ev',num2str(params.num.list(e,1)));
        
        for st = 1:size(data.(evnum).stalist,1)
            
            station = data.(evnum).stalist(st,:);
            
            data.(evnum).(station).FI = log10(10^(data.(evnum).(station).cavg(2,1)) / 10^(data.(evnum).(station).cavg(1,1))); % higher/lower
            
            if isnan(data.(evnum).(station).FI) == 0
            
                FIsum = FIsum + data.(evnum).(station).FI;
                
                total = total + 1;
            
            end
            
        end
        
        % Calculate average FI for each event
        
        data.(evnum).FIavg = FIsum / total;
        
    end
    
    % Calculate average FI for each station
    
    stanum = size(params.sta.list,1);
    
    stafiavg = zeros(stanum,1);
    
    for onsta = 1:stanum
        
        staname = strcat(params.sta.list(onsta,:));
        
        % Find average of FI values at station
        
        FIvals = 0;
        numev = 0;
        
        for e = 1:size(params.num.list,1)
            
            evnum = strcat('ev',num2str(params.num.list(e,1)));
            
            % make sure event on station
            
            for n = 1:size(data.(evnum).stalist,1)
                
                if strcmpi(data.(evnum).stalist(n,:),staname) == 1
                    
                    if isnan(data.(evnum).(staname).FI) == 0 % if value isn't NaN, add it
                        
                        FIvals = FIvals + data.(evnum).(staname).FI;
                        
                        numev = numev + 1;
                        
                        break;
                        
                    end
                    
                end
                
            end
            
        end
        
        % Find station's average FI and add to list
        
        stafiavg(onsta,1) = FIvals / numev;
        
    end
    
    %% Make plot(s) for FI
    
    mkplot = 'Y';
    
    while strcmpi(mkplot,'Y') == 1
    
    disp('--------------------')
    disp(' ')
    disp('Plot options:')
    disp(' ')
    disp('1) Histogram for each station (default)')
    disp('2) Scatterplot for each event')
    disp('3) Histogram of average FI')
    disp('4) Scatterplot of average FI vs magnitude')
    disp('5) Scatterplot of FI vs magnitude for each station')
    disp('6) Plot of station-averaged FI ')
    disp(' ')
    plotop = input('Choose a plot type (integer, 0 to skip): ');
    
    if plotop == 2

        numev = size(params.num.list,1);

        if numev == 1
            
            col = 1;
            row = 1;
            rowpg = 1;
            
        else
            
            [row,col,rowpg] = subplotpar(numev,'events');
            
        end
        
        % Make new figure window

        figure;

        title('Frequency Index');

        fignum = ceil(row/rowpg);

        onfig = 1;
        
        for onev = 1:numev
     
            evnum = strcat('ev',num2str(params.num.list(onev,1)));
            
            % Set-up subplot

            spnum = onev - (rowpg*col)*(onfig - 1); % sub-plot number for figure
            
            subplot(rowpg,col,spnum);
            
            hold on;
            
            % Make list of FI values
            
            FIvals = zeros((size(data.(evnum).stalist,1)+1),1) * NaN;
            
            for sta = 1:size(data.(evnum).stalist,1)
                
                staname = strcat(data.(evnum).stalist(sta,:));
                    
                 FIvals(sta,1) = data.(evnum).(staname).FI;
                
            end
            
            FIvals((sta+1),1) = data.(evnum).FIavg;
            
            stations = 1:1:(size(data.(evnum).stalist,1)+1);
            
            % Make plot
            
            scatter(stations,FIvals,'filled');
            
            grid on;
            xlim([0 stations])
            set(gca,'XTickLabel',[data.(evnum).stalist;'AVG*'],'XTick',stations)
            title(['Event: ' num2str(params.num.list(onev,1))])
            xlabel('Station')
            ylabel('Frequency Index')
            
            % Make new figure if necessary
            
            if rem(onev,(rowpg*col)) == 0 && onfig ~= fignum

                figure;

                title('Frequency Index');

                onfig = onfig + 1;

            end
            
        end
        
    elseif plotop == 3
        
        % Make list of FI values
            
        FIvals = zeros(size(params.num.list,1),1) * NaN;
        
        for e = 1:size(params.num.list,1)
            
            evnum = strcat('ev',num2str(params.num.list(e,1)));
            
            FIvals(e,1) = data.(evnum).FIavg;
            
        end
                
        % Prompt for bin width
        
        disp(' ')
        binw = input('What bin width would you like? (double): ');
        
        figure;
        
        % Plot histogram
        
        bincent = unique(horzcat(fliplr(0:binw:abs(min(FIvals)))*-1,0:binw:max(FIvals)));
       
        hist(FIvals,bincent);
        
        title('Frequency Index Average Over All Stations')
        xlabel('Frequency Index')
        ylabel('Number of Events')
        
    elseif plotop == 4
        
        % Make list of FI values
        
        FIvals = zeros(size(params.num.list,1),1) * NaN;
        
        mags = zeros(size(params.num.list,1),1) * NaN;
        
        flags = zeros(size(params.num.list,1),1) * NaN;

        for onev = 1:size(params.num.list,1)
     
            evnum = strcat('ev',num2str(params.num.list(onev,1)));
            
            FIvals(onev,1) = data.(evnum).FIavg;
            
            mags(onev,1) = data.(evnum).data(1,10);
                
            if size(data.(evnum).data,2) == 11
            
                flags(onev,1) = data.(evnum).data(1,11);
                
            end
            
        end
        
        % Make plot
        
        figure;
        
        scatter(mags,FIvals,42,flags,'fill');
        
        grid on;
        title('Average Frequency Index vs Magnitude')
        xlabel('Local Magnitude')
        ylabel('Frequency Index')
        
    elseif plotop == 5
        
        % Get info for subplots
        
        disp(' ')
        stanum = size(params.sta.list,1);

        if stanum == 1
            
            col = 1;
            row = 1;
            rowpg = 1;
            
        else
            
           [row,col,rowpg] = subplotpar(stanum,'stations');
            
        end
        
        % Make new figure window
        
        figure;
        
        title('Frequency Index vs Magnitude');
        
        fignum = ceil(row/rowpg);
        
        onfig = 1;
        
        for onsta = 1:stanum
            
            staname = strcat(params.sta.list(onsta,:));
            
            % Set up subplot
            
            spnum = onsta - (rowpg*col)*(onfig - 1); % sub-plot number for figure
            
            subplot(rowpg,col,spnum);
            
            hold on;
            
            % Make list of FI values
            
            FIvals = zeros(size(params.num.list,1),1) * NaN;
            
            mags = zeros(size(params.num.list,1),1) * NaN;
            
            flags = zeros(size(params.num.list,1),1) * NaN;
            
            for e = 1:size(params.num.list,1)
                
                evnum = strcat('ev',num2str(params.num.list(e,1)));
                
                % make sure event on station
                
                for n = 1:size(data.(evnum).stalist,1)
                    
                    if strcmpi(data.(evnum).stalist(n,:),staname) == 1
                        
                        FIvals(e,1) = data.(evnum).(staname).FI;
                        
                        mags(e,1) = data.(evnum).data(1,10);
                        
                        if size(data.(evnum).data,2) == 11
                            
                            flags(e,1) = data.(evnum).data(1,11);
                            
                        end
                        
                        break;
                        
                    end
                    
                end
                
            end
            
            % Make plot

            scatter(mags,FIvals,42,flags,'fill');
            
            grid on;
            title(['Station: ' staname])
            xlabel('Local Magnitude')
            ylabel('Frequency Index')
            
            % Make new figure if necessary
            
            if rem(onsta,(rowpg*col)) == 0 && onfig ~= fignum
                
                figure;
                
                title('Frequency Index vs Magnitude');
                
                onfig = onfig + 1;
                
            end
            
        end

    elseif plotop == 6
        
        stanum = size(params.sta.list,1);
        
        % Make plot
        
        figure;
        
        staind = 1:1:stanum;
        
        hold on;
        
        scatter(staind,stafiavg,42,'fill');
        
        grid on;
        xlim([0 stanum])
        title('Station-Averaged Frequency Index');
        set(gca,'XTickLabel',[params.sta.list(:,:)],'XTick',staind);
        xlabel('Station')
        ylabel('Average Frequency Index')
        
    elseif plotop == 0
        
        % do nothing - skip plotting
        
    else
        
        % Set up subplots
        
        stanum = size(params.sta.list,1);

        if stanum == 1
            
            col = 1;
            row = 1;
            rowpg = 1;
            
        else
            
           [row,col,rowpg] = subplotpar(stanum,'stations');
            
        end
        
        % Prompt for bin width
        
        disp(' ')
        binw = input('What bin width would you like? (double, default 0.1): ');
        
        if isempty(binw) == 1
            
            binw = 0.1;
            
        end
        
        % Make new figure window

        figure;

        title('Frequency Index Histograms');

        fignum = ceil(row/rowpg);

        onfig = 1;
        
        for onsta = 1:stanum
            
            staname = strcat(params.sta.list(onsta,:));
            
            % Set up subplot

            spnum = onsta - (rowpg*col)*(onfig - 1); % sub-plot number for figure
            
            subplot(rowpg,col,spnum);
            
            hold on;
            
            % Make list of FI values
            
            FIvals = zeros(size(params.num.list,1),1) * NaN;
            
            for e = 1:size(params.num.list,1)
                
                 evnum = strcat('ev',num2str(params.num.list(e,1)));
                    
                 % make sure event on station
                 
                 for n = 1:size(data.(evnum).stalist,1)
                 
                     if strcmpi(data.(evnum).stalist(n,:),staname) == 1
                         
                         FIvals(e,1) = data.(evnum).(staname).FI;
                
                         break;
                         
                     end
                 
                 end
                     
            end
            
            % Plot histogram
            
            bincent = unique(horzcat(fliplr(0:binw:abs(min(FIvals)))*-1,0:binw:max(FIvals)));
            
            hist(FIvals,bincent);
            
            title(['Station: ' staname])
            ylabel('Number of Events')
            xlabel('Frequency Index')
            
            % Make new figure if necessary
            
            if rem(onsta,(rowpg*col)) == 0 && onfig ~= fignum

                figure;

                title('Frequency Index Histograms');

                onfig = onfig + 1;

            end
            
        end
        
    end
    
    disp(' ')
    mkplot = input('Make another plot? (Y or N): ','s'); % default N
    
    end
    
    
%% Write FI Results to File
    
disp('--------------------')
disp(' ')
writeFI = input('Write FI results to a text file? (N or Y): ','s'); % default Y
    
if strcmpi(writeFI,'N') == 0

    % Make matrix of values to print
    
    FIvals = ones(size(params.num.list,1),(size(params.sta.list,1)+1)) * NaN;
    
    for evn = 1:size(params.num.list,1)
        
        evnum = strcat('ev',num2str(params.num.list(evn)));
        
        % go through all stations that event has FIs for
        
        for sta = 1:size(data.(evnum).stalist,1)
        
            station = data.(evnum).stalist(sta,:);
        
            for sn = 1:size(params.sta.list,1)
                
                % figure out what number station the current one is
                
                if strcmpi(station,params.sta.list(sn,:)) == 1
                    
                    FIvals(evn,sn) = data.(evnum).(station).FI;
                    
                    break; % stop loop & move to next station
                    
                end
            
            end
            
        end
        
        % include average value
        
        FIvals(evn,size(FIvals,2)) = data.(evnum).FIavg;
        
    end
    
    % Write file
    
    writeresults(data,params.num.list,FIvals,'%6.3f  %6.3f');
    
    % Write station-averaged FI
    
    disp(' ')
    wrstaavg = input('Write station-averaged FI as *.mat file? (Y or N): ','s');
    
    if strcmpi(wrstaavg,'Y') == 1
        
        staavg = [num2cell(params.sta.list,2) num2cell(stafiavg)];
        
        % Save as *.mat file
        
        disp(' ')
        staavgfn = input('Name your file (including directory and .mat): ','s');
        
        save(staavgfn,'staavg');
        
    end
    
    % Clear temporary variables
    
    clear FIvals sta writeFI evnum station

end

else % otherwise, proceed with EGF methods


%% Stack/Average Smaller Events

disp('--------------------')
disp(' ')
stackev = input('Would you like to stack events? (N or Y): ','s');

if strcmpi(stackev,'N') == 0

% Get event magnitudes

evmag = zeros(size(params.num.list,1),2);

for h = 1:length(params.num.list)

    evnum = strcat('ev',num2str(params.num.list(h,1)));
    
    evmag(h,1) = params.num.list(h,1);
    
    evmag(h,2) = data.(evnum).data(1,10);
    
end

% Set up bins

keepbins = 'N';

while strcmpi(keepbins,'N') == 1

disp('--------------------')
disp(' ')
disp(['Minimum magnitude: ' num2str(min(evmag(:,2)))])
disp(['Median magnitude: ' num2str(median(evmag(:,2)))])
disp(['Maximum magnitude: ' num2str(max(evmag(:,2)))])
disp(' ')
disp('Smaller magnitude events will be stacked.')
disp('Choose the magnitude bounds for stacking.')
disp(' ')
stackmin = input('Minimum (integer): ');
stackmax = input('Maximum (integer): ');

pickbin = 'N';

% Get number of bins
    
while strcmpi(pickbin,'N') == 1

    disp(' ')
    params.stack.binnum = input('How many bins would you like? (integer >= 2): ');
    
    if params.stack.binnum < 2
        
        disp(' ')
        disp('Bin number is less than 2. Please try again.')
        
    elseif isempty(params.stack.binnum) == 1
        
        disp(' ')
        disp('Please enter an integer number of bins.')        
        
    else
        
        stackrange = (stackmax - stackmin) / params.stack.binnum;

        disp(' ')
        disp(['Each bin will span ' num2str(stackrange) '.'])
        disp(' ')
        pickbin = input('Is this okay? (N or Y): ','s'); % default Y
    
    end

end

% Determine events per bin

stackbins = stackmin:stackrange:stackmax;

[evperbin,bin] = histc(evmag(:,2),stackbins);

disp(' ')
disp('The maximum number of events in each bin is:')
disp(' ')

for k = 1:(length(evperbin)-1)
    
    disp([num2str(stackmin+(stackrange*(k-1))) ' - ' num2str(stackmin+(stackrange*k)) ': ' num2str(evperbin(k))])
    
end

disp(['Unbinned events: ' num2str(length(find(bin==0)))])
disp(' ')
disp('* Bins for some stations may have fewer if events have been flagged. *')
disp(' ')
keepbins = input('Would you like to keep these bins? (N or Y): ','s');

if strcmpi(keepbins,'N') == 1
    
   pickbin = 'N'; 
    
end

end

% Find events outside magnitude limits

params.stack.nostack = params.num.list(bin==0);

% Stack coda amplitudes in each bin

for bn = 1:params.stack.binnum
    
    binstr = strcat('bin',num2str(bn));
    
    data.(binstr).bounds = [stackmin+(stackrange*(bn-1)) stackmin+(stackrange*bn)];
    
    data.(binstr).events = zeros(evperbin(bn),1);

    br = 1;
    
    % Get events in each bin
    
    for ebn = 1:size(evmag,1)
    
        if (evmag(ebn,2) >= data.(binstr).bounds(1,1)) && (evmag(ebn,2) < data.(binstr).bounds(1,2))
            
            data.(binstr).events(br,1) = evmag(ebn,1);
            
            br = br + 1;
            
        % for last bin check if magnitude equals upper bound
            
        elseif (ebn == size(evmag,1)) && (evmag(ebn,2) == data.(binstr).bounds(1,2))
            
            data.(binstr).events(br,1) = evmag(ebn,1);

            br = br + 1;
            
        end
        
    end
    
    % Collect coda amplitudes (and travel times) & average for each station
    
    for stn = 1:size(params.sta.list,1)
            
        ttsum = 0;
        
        ttcount = 0;
        
        stnnm = params.sta.list(stn,:);
        
        % start with vector of NaNs
        
        data.(binstr).(stnnm).camp = zeros(size(data.(binstr).events,1),filtnum) * NaN;
        
        for evr = 1:size(data.(binstr).events,1)
            
            evnum = strcat('ev',num2str(data.(binstr).events(evr,1)));
            
            % make sure event recorded on current station
            
            starec = 0;
            
            for n = 1:size(data.(evnum).stalist,1)
                
                if strcmpi(data.(evnum).stalist(n,:),stnnm) == 1
                    
                    starec = 1;
                    
                    break;
                    
                end
                
            end
            
            % add amplitude data if event exists on and is 'good' on station
            
            if starec == 1
            
                if data.(evnum).(stnnm).bad == 0
                    
                    data.(binstr).(stnnm).camp(evr,:) = transpose(data.(evnum).(stnnm).cavg);
                    
                    ttsum = ttsum + data.(evnum).(stnnm).ttime;
                    
                    ttcount = ttcount + 1;
                    
                end
        
            end
            
        end
        
        % Find average travel time
        
        data.(binstr).(stnnm).ttime = ttsum / ttcount;
        
        % Average coda amplitude over all events in bin
        
        NaNnum = 0; % reset NaN count
        
        for fr = 1:filtnum
           
            sum = 0;
        
            scount = 0;
            
            for evr = 1:size(data.(binstr).events,1)

                % if value for event isn't NaN, add it to sum

                if isnan(data.(binstr).(stnnm).camp(evr,fr)) == 0

                    sum = data.(binstr).(stnnm).camp(evr,fr) + sum;

                    scount = scount + 1;

                end

            end
            
            data.(binstr).(stnnm).cavg(fr,1) = sum / scount;

            % if value is NaN, add to count

            if isnan(data.(binstr).(stnnm).cavg(fr,1)) == 1

                NaNnum = NaNnum + 1;

            end
        
        end
       
        % Flag bins with too many NaNs
        
        if (filtnum - NaNnum) < 2
            
            data.(binstr).(stnnm).bad = 1;
            
        else
        
            data.(binstr).(stnnm).bad = 0;
        
        end
        
    end
    
end

% Make list of stations for each bin

for bn = 1:params.stack.binnum

     binstr = strcat('bin',num2str(bn));
    
     fields = fieldnames(data.(binstr));
     
     data.(binstr).stalist = fields(3:size(fields,1));
    
end

else
    
    % If events not stacked, make variables for use later
    
    params.stack.nostack = params.num.list; % no events have been stacked
    
    params.stack.binnum = 0; % no bins created
    
end


%% Plot Coda Amplitudes

disp(' ')
disp('--------------------')
disp(' ')
plcamp = input('Would you like to plot the coda amplitudes? (Y or N): ','s'); % default N

while strcmpi(plcamp,'Y') == 1

    if strcmpi(stackev,'N') == 1
        
        plop = 1;

    else
    
        disp(' ')
        disp('Plotting options:')
        disp('1) Events only (choose)')
        disp('2) Stacked event bins only (all)')
        disp('3) Both chosen events and all stacked bins (default)')
        disp(' ')
        plop = input('Which option would you like? (integer): ');

        disp('--------------------')
        
        if isempty(plop) == 1
            
            plop = 3; % give default value
            
        end
        
    end

    if plop ~= 2

        disp(' ')
        if isempty(params.num.str) == 0
            disp(['You selected events: ' params.num.str])
        else
            disp('You selected all data.')
        end
        disp(' ')
        disp(['Events that haven''t been stacked: ' num2str(transpose(params.stack.nostack))])
        disp(' ')
        disp('** Entry format example: 6:10 or 6/7/8/9/10 or 6/7:9/10')
        disp('** Use * for all selected data.')
        disp(' ')
        disp('Default: All non-stacked events')
        disp(' ')
        evnumpl = input('Which event(s) would you like to plot?: ','s');

        if strcmpi(evnumpl,'*') == 1 || isempty(evnumpl) == 1

            % Create list of numbers for all events

            plevs = params.stack.nostack;

        else 

            % Convert event #s to usuable list

            plevs = makelist(evnumpl,'num');
            
        end

    end

    % Get list of bins and total event+bin number 

    if plop ~= 1

        plbns = transpose(1:params.stack.binnum);

        if plop == 2

            plebnum = params.stack.binnum;
            plevs = plbns;

        else

            plebnum = params.stack.binnum + size(plevs,1);
            
            plevs = vertcat(plevs,plbns);

        end
        
        clear plbns % no longer needed

    else

        plebnum = size(plevs,1);

    end
    
    % Plot coda amplitudes
               
    % if only 1 event, plot all stations on one fig
    
    if size(plevs,1) == 1 && plop == 1
        
        pleb = strcat('ev',num2str(plevs));

        plsta = data.(pleb).stalist;
        
        % Make colormap

        cmp = makecmp(plsta);

        figure;         
        hold on;
        grid on;

        for stafig = 1:size(plsta,1)

            csta = plsta(stafig,:);

            plot(params.nbands(:,3),data.(pleb).(csta).cavg,'-o','LineWidth',2,'Color',cmp(stafig,:))

        end
        
        set(gca,'XScale','log');
        title(['Event: ',num2str(plevs(1,1))]);
        xlabel('Frequency (Hz)');
        ylabel('Non-dim Amplitude');      
        legend(plsta,'location','EastOutside');
    
    else
        
        % organize by stations (multiple events per figure)
        
        % Make colormap

        cmp = makecmp(plevs);
        
        % Make string for legend labels

        ll = cellstr(transpose(blanks(plebnum)));    
        
        % plot all events/bins on figure for each station
    
        for stafig = 1:size(params.sta.list,1)

            csta = params.sta.list(stafig,:);

            figure;

            hold on;

            grid on;

            for oneb = 1:plebnum
            
                % Make sure eb exists for current station
                
                starec = 0;
                
                 if oneb <= (size(plevs,1) - params.stack.binnum) % Plot events

                     pleb = strcat('ev',num2str(plevs(oneb,1)));
                     
                 else % Plot bins
                     
                     pleb = strcat('bin',num2str(plevs(oneb,1)));
                     
                 end
                
                for n = 1:size(data.(pleb).stalist,1)
                    
                    if strcmpi(data.(pleb).stalist(n,:),csta) == 1
                        
                        starec = 1;
                        
                        break;
                        
                    end
                    
                end
                    
                if starec == 1
                
                if plop == 1

                    % Plot events

                    plot(params.nbands(:,3),data.(pleb).(csta).cavg,'-o','LineWidth',2,'Color',cmp(oneb,:))
                    
                    % Add legend label for event
                    
                    ll{oneb,1} = strcat(['Ev ',num2str(plevs(oneb,1))]);

                elseif plop == 2
                    
                    % Plot bins

                    plot(params.nbands(:,3),data.(pleb).(csta).cavg,'-o','LineWidth',2,'Color',cmp(oneb,:))
  
                    % Add legend label for bin
                    
                    ll{oneb,1} = strcat(['Bin ',num2str(oneb)]);
                        
                else

                    if oneb <= (size(plevs,1) - params.stack.binnum) % Plot events
      
                        ll{oneb,1} = strcat(['Ev ',num2str(plevs(oneb,1))]); % Add legend label for event
                        
                    else % Plot bins
    
                        ll{oneb,1} = strcat(['Bin ',num2str(plevs(oneb,1))]); % Add legend label for event
                        
                    end

                    plot(params.nbands(:,3),data.(pleb).(csta).cavg,'-o','LineWidth',2,'Color',cmp(oneb,:))
                        
                end

                end
            
            end
            
            set(gca,'XScale','log');
            title(['Station: ',csta]);
            xlabel('Frequency (Hz)');
            ylabel('Non-dim Amplitude');      
            legend(ll,'location','EastOutside');
            
        end
    
    end
    
    disp(' ')
    plcamp = input('Would you like to make another waveform amplitude plot? (Y or N): ','s'); % default N
    
    % If making new plot, clear legend label variable
    
    if strcmpi(plcamp,'Y') == 1
        
       clear ll 
        
       disp(' ')
       disp('--------------------')
       
    end
    
end

% clear temporary variables

clear plevs plebnum csta cmp plcamp ll stafig plsta plop evnumpl


%% Choose Events/Bins for EGF Correction & Analysis

pickebcorr = 'Y';

while strcmpi(pickebcorr,'Y') == 1

disp(' ')
disp('--------------------')
disp(' ')
disp('You may now manually select events to use in the EGF correction')
disp('  and analysis. Choosing ''N'' will use all data.')
disp(' ')
mansel = input('Would you like to select events to be used? (N or Y): ','s');
    
if strcmpi(mansel,'N') == 0
        
    for onsta = 1:size(params.sta.list,1)
        
        station = params.sta.list(onsta,:);
        
        disp(' ')
        disp('--------------------')
        disp(['Working on station ' station '....'])
        disp(' ')
        plamp = input('Would you like to see a plot of the amplitudes? (N or Y): ','s');
        
        % Make amplitude plot for station if requested
        
        if strcmpi(plamp,'N') == 0
            
            % Get list of bins & events and total event+bin number 

            plevs = params.stack.nostack;
            
            if params.stack.binnum > 0

                plebnum = params.stack.binnum + size(plevs,1);
                
                plevs = vertcat(plevs,transpose(1:params.stack.binnum));

            else

                plebnum = size(plevs,1);

            end
            
            % Make colormap

            cmp = makecmp(plevs);

            % Make string for legend labels

            ll = cellstr(transpose(blanks(plebnum)));    

            % plot all events/bins on figure

            csta = params.sta.list(onsta,:);

            figure;

            hold on;

            grid on;

            % Plot events & bins
            
            for oneb = 1:plebnum

                 if oneb <= (size(plevs,1) - params.stack.binnum) % Plot events

                    pleb = strcat('ev',num2str(plevs(oneb,1)));

                    ll{oneb,1} = strcat(['Ev ',num2str(plevs(oneb,1))]); % Add legend label for event

                else % Plot bins

                    pleb = strcat('bin',num2str(plevs(oneb,1)));

                    ll{oneb,1} = strcat(['Bin ',num2str(plevs(oneb,1))]); % Add legend label for event

                 end

                % if event/bin on station, plot it
                
                for sn = 1:size(data.(pleb).stalist)
                 
                    if strcmpi(data.(pleb).stalist(sn,:),csta) == 1
                        
                        if data.(pleb).(csta).bad == 0 % if event is good
                            
                            plot(params.nbands(:,3),data.(pleb).(csta).cavg,'-o','LineWidth',2,'Color',cmp(oneb,:))
                            
                            % Add label to legend
                            
                            if oneb <= (size(plevs,1) - params.stack.binnum)
                                
                                ll{oneb,1} = strcat(['Ev ',num2str(plevs(oneb,1))]); % Add legend label for event
                                
                            else
                                
                                ll{oneb,1} = strcat(['Bin ',num2str(plevs(oneb,1))]); % Add legend label for event
                                
                            end
                        
                        end
                        
                        break;
                        
                    end
                    
                end
                
            end

            set(gca,'XScale','log');
            title(['Station: ',csta]);
            xlabel('Frequency (Hz)');
            ylabel('Non-dim Amplitude');      
            legend(ll,'location','EastOutside');

        end

        pickeb = 1;

        while pickeb > 0

            keepall = 0;
            
            % Choose events/bins to keep
            
            if pickeb == 1

                disp(' ')
                disp(['Events: ' num2str(transpose(params.stack.nostack))])
                disp(' ')
                disp('** Entry format example: 6:10 or 6/7/8/9/10 or 6/7:9/10')
                disp('** Use * to throw out all data.')
                disp('** Leave entry blank to keep all data. (default)')
                disp(' ')
                evnumpl = input('Which event(s) would you like to throw out?: ','s');

            elseif pickeb == 2

                disp(' ')
                disp(['Number of bins: ' num2str(params.stack.binnum)])
                disp(' ')
                disp('** Entry format example: 6:10 or 6/7/8/9/10 or 6/7:9/10')
                disp('** Use * to throw out all bins.')
                disp('** Leave entry blank to keep all bins. (default)')
                disp(' ')
                evnumpl = input('Which bin(s) would you like to throw out?: ','s');

            end

            if strcmpi(evnumpl,'*') == 1

                % Create list of numbers for all events/bins
                
                if pickeb == 1

                    tosseb = params.stack.nostack;
                
                elseif pickeb == 2
                    
                    tosseb = transpose(1:params.stack.binnum);
                    
                end
                
            elseif isempty(evnumpl) == 1
                
                keepall = 1;
                
            else 
                
                tosseb = makelist(evnumpl,'num');

            end
       
            % flag events/bins if on toss list

            if keepall ~= 1

                for evt = 1:length(tosseb)

                    if pickeb == 1

                        ebnum = strcat('ev',num2str(tosseb(evt,1)));
                        
                    elseif pickeb == 2

                        ebnum = strcat('bin',num2str(tosseb(evt,1)));

                    end

                    data.(ebnum).(station).bad = 1;

                end

            end
            
            if params.stack.binnum > 0 && pickeb == 1 % if available, pick bins after events
                
                pickeb = 2;
                
            else % exit loop
                
                pickeb = 0;
                
            end
            
            clear tosseb keepall evt ebnum
            
        end
        
    end

end

% clear temporary variables

clear plevs plebnum csta cmp onsta mansel plamp plbns ll v pickeb evnumpl


%% Set-up For EGF Correction & Analysis

ebmag = cell((size(params.stack.nostack,1)+params.stack.binnum),2);

% Get magnitude for all events & average magnitude for bins

for evr = 1:(size(params.stack.nostack,1)+params.stack.binnum)
    
    if evr <= size(params.stack.nostack,1)
       
        ebmag{evr,1} = strcat('ev',num2str(params.stack.nostack(evr,1)));
        
        ebmag{evr,2} = data.(ebmag{evr,1}).data(1,10);
       
    else
        
       ebmag{evr,1} = strcat('bin',num2str(evr - size(params.stack.nostack,1)));
        
       % Find average magnitude of binned events
       
       sum = 0;
       
       for row = 1:size(data.(ebmag{evr,1}).events,1)
          
           evname = strcat('ev',num2str(data.(ebmag{evr,1}).events(row,1)));
           
           sum = sum + data.(evname).data(1,10);
           
       end
       
       ebmag{evr,2} = sum / size(data.(ebmag{evr,1}).events,1);
       
    end

end

% Sort magnitudes so 'eb' numbers increase with magnitude
% (i.e. eb1 = smallest event (EGF), eb2 = next smallest event, etc.)

ebmag = sortrows(ebmag,2);

% Keep list of events and bins for later reference

egfcorr.eblist = ebmag(:,1);

% Convert to moment magnitude & store in data structure

for evr = 1:size(ebmag,1)
    
    ebname = ebmag{evr,1};

    data.(ebname).Mo = 10.^(2 * ebmag{evr,2} + 6.5);

end

% Create list of useable events for each station

for sta = 1:size(params.sta.list,1)
    
   station = params.sta.list(sta,:);
   
   listnum = 1; % start with empty list
   
   % loop through all non-stacked events & bins
   
   for eb = 1:size(ebmag,1)
       
       for n = 1:size(data.(ebmag{eb,1}).stalist)
              
           % if event recorded at station
           
           if strcmpi(station,data.(ebmag{eb,1}).stalist(n,:)) == 1
               
               % if event good at station, add to list
               
               if data.(ebmag{eb,1}).(station).bad == 0
                   
                   egfcorr.(station).eblist{listnum,1} = ebmag{eb,1};
                   
                   listnum = listnum + 1;
                   
               end
               
               break; % stop searching station list - match found
               
           end
       
       end
       
   end
    
end

% Clear temporary variables

clear ebmag evr sum row sta listnum station eb ebname


%% Make EGF and Apply Correction

EGFcorr = 'Y';

while strcmpi(EGFcorr,'Y') == 1

disp(' ')
disp('--------------------')
disp(' ')
disp('Smallest event/bin will be fit to a Brune spectrum model.')
disp(' ')
disp('The model choices are:')
disp('1) C*Mo/(1+(f/fc)^(n*y))^(1/y) with fc, C free (default)')
disp('2) C*Mo/(1+(f/fc)^(n*y))^(1/y) with fc, C, n free')
disp('3) C*Mo*exp(-pi*t*f/Q)/(1+(f/fc)^(n*y))^(1/y) with fc, C, Q free')
disp('4) C*Mo*exp(-pi*t*f/Q)/(1+(f/fc)^(n*y))^(1/y) with fc, C, n free')
disp('5) C*Mo*exp(-pi*t*f/Q)/(1+(f/fc)^(n*y))^(1/y) with fc, C free')
disp(' ')
whichmod = input('Which model would you like to use? (integer): ');
disp(' ')

if isempty(whichmod) == 1
    
    whichmod = 1;
    
end
 
if whichmod == 2 || whichmod == 4
    
    n = input('Choose parameter ''n'' for EGF event/bin (double, default 2): ');
    
else
    
    n = input('Choose parameter ''n'' (double, default 2): ');

end

if isempty(n) == 1
    
    n = 2;
    
end

y = input('Choose parameter ''y'' (double, default 1): ');

if isempty(y) == 1
    
    y = 1;
    
end

if whichmod > 2
    
    Q = input('Choose parameter ''Q'' (double): ');
    
    while isempty(Q) == 1
    
        disp(' ')
        disp('Error: Please enter a value for Q.')
        Q = input('Choose parameter ''Q'' (double): ');
    
    end
    
end

% Set parameters for corner freq calculation

if size(params.cha.list,1) == 1
    
    k = 0.32; % for P-waves from Madariaga (1976)
    
    Vel = 6200; % m/s for P-waves at 3km
    
else
    
    k = 0.21; % for S-waves from Madariaga (1976)
    
    Vel = 3450; % m/s for S-waves at ~3km
    
end

disp(' ')
sdrop = input('What stress drop should be used for the EGF? (double, MPa, default 1): ');

if isempty(sdrop) == 1
    
    sdrop = 1;
    
end

% Calculate Brune model for EGF at given frequencies

disp(' ')
disp('Fitting Brune model to EGF....')

for sta = 1:size(params.sta.list,1)

    station = strcat(params.sta.list(sta,:));
    
    % Calculate corner freq for smallest event
    
    fc = (sdrop * 10^6 / data.(egfcorr.(station).eblist{1,1}).Mo * 16/7)^(1/3) * k * Vel % Hz

    % for center frequency of each filter, calculate Brune amplitude
    
    egfcorr.(station).eb1.corramp = zeros(filtnum,1);
    
    for fn = 1:filtnum
    
        if whichmod <= 2
        
            egfcorr.(station).eb1.corramp(fn,1) = log10(data.(egfcorr.(station).eblist{1,1}).Mo /...
                (1 + (params.nbands(fn,3) / fc)^(n*y))^(1/y));

        else
        
            egfcorr.(station).eb1.corramp(fn,1) = log10(data.(egfcorr.(station).eblist{1,1}).Mo * exp(- pi * ...
                data.(egfcorr.(station).eblist{1,1}).(station).ttime * params.nbands(fn,3) / Q) / (1 + (params.nbands(fn,3) / fc)^(n*y))^(1/y));
        
        end
        
    end
    
end

% Calculate "Brune ratio" (amount EGF event/bin is adjusted by to fit Brune model)
% Uses +/- since amplitudes are in log space

for sta = 1:size(params.sta.list,1)

    station = strcat(params.sta.list(sta,:));

    egfcorr.(station).Brat = egfcorr.(station).eb1.corramp - data.(egfcorr.(station).eblist{1,1}).(station).cavg;

end

% Correct all other events & bins using Brune ratio

disp(' ')
disp('Applying EGF correction to other events & bins....')

for sta = 1:size(params.sta.list,1)
    
    station = strcat(params.sta.list(sta,:));
    
    for row = 2:size(egfcorr.(station).eblist,1) % skip the smallest (EGF) event
        
        ebname = strcat('eb',num2str(row));
        
        % First, copy over original values

        egfcorr.(station).(ebname).corramp = data.(egfcorr.(station).eblist{row,1}).(station).cavg;
        
        % Apply correction to amplitude value of each filter
        
        for fr = 1:filtnum
            
            % Want to apply correction from high to low (filtnum to 1)
            
            onfilt = (filtnum - fr + 1);
           
            % Check to see if Brat = NaN for any filter
            
            if isnan(egfcorr.(station).Brat(onfilt,1)) == 1 
             
               % Check to see if current event/bin has NaN value for that filter
              
               % If there's a value, calculate a ratio to use for larger events/bins
                             
               if isnan(egfcorr.(station).(ebname).corramp(onfilt,1)) == 0 && fr ~= 1
               
                   % Calculate theoretical fc for event/bin
                   
                   fc = (sdrop * 10^6 / data.(egfcorr.(station).eblist{row,1}).Mo * 16/7)^(1/3) * k * Vel; % Hz
                   
                   % If fc < current filter's center freq, copy ratio from lower filter
                   
                   if fc < params.nbands(onfilt,3)
                       
                       egfcorr.(station).Brat(onfilt,1) = egfcorr.(station).Brat((onfilt-1),1);
                       
                   else
                       
                       % Else, use ratio between values for the current filter and next highest filter
                       % This essentially flattens the point to match the next highest filter
                       
                       egfcorr.(station).Brat(onfilt,1) = egfcorr.(station).(ebname).corramp((onfilt+1),1) -...
                           egfcorr.(station).(ebname).corramp(onfilt,1);
                       
                   end
                   
               end
               
            end
              
            % Apply correction 

            egfcorr.(station).(ebname).corramp(onfilt,1) =  egfcorr.(station).Brat(onfilt,1) +...
                egfcorr.(station).(ebname).corramp(onfilt,1);
               
        end
            
    end
    
end


%% Plot Corrected Coda Amplitudes

disp(' ')
disp('--------------------')
disp(' ')
plcorr = input('Plot the corrected amplitudes? (Y or N): ','s'); % default N

while strcmpi(plcorr,'Y') == 1
    
    % Plot corrected amplitudes
        
    % organize by stations (multiple events per figure)

    for stafig = 1:size(params.sta.list,1)
    
        station = params.sta.list(stafig,:);
        
        % Make colormap

        cmp = makecmp(egfcorr.(station).eblist);

        figure;
        hold on;
        grid on;

        % Plot events
            
        for oneb = 1:size(egfcorr.(station).eblist,1)

            pleb = strcat('eb',num2str(oneb));

            plot(params.nbands(:,3),egfcorr.(station).(pleb).corramp,'-o','LineWidth',2,'Color',cmp(oneb,:))

        end

        set(gca,'XScale','log');
        title(['Station: ',station]);
        xlabel('Frequency (Hz)');
        ylabel('Non-dim Amplitude');      
        legend(egfcorr.(station).eblist{:,1},'location','EastOutside');

    end
    
    disp(' ')
    plcorr = input('Would you like to make another waveform amplitude plot? (Y or N): ','s'); % default N
    
end


%% Fit Brune Model to All Events/Bins & Calculate Corner Frequency

disp('--------------------')
disp(' ')
disp('A Brune model will now be fit to all events and stations.')

% Create Brune Model

if whichmod == 1

    Bmod = fittype('log10(C*Mo/(1+(f/fc)^(n*y))^(1/y))','coefficients',{'C','fc'},'problem',{'n','y','Mo'},...
        'independent','f','dependent','u');

    % Save parameter info
    
    egfcorr.model.coeff = {'C','fc'};
    egfcorr.model.problem = {'n','y','Mo'};
    
elseif whichmod == 2
    
    Bmod = fittype('log10(C*Mo/(1+(f/fc)^(n*y))^(1/y))','coefficients',{'C','fc','n'},'problem',{'y','Mo'},...
        'independent','f','dependent','u');
    
     % Save parameter info
    
    egfcorr.model.coeff = {'C','fc','n'};
    egfcorr.model.problem = {'y','Mo'};
    
elseif whichmod == 3
    
    Bmod = fittype('log10(C*Mo*exp(-pi*t*f/Q)/(1+(f/fc)^(n*y))^(1/y))','coefficients',{'C','fc','Q'},'problem',{'n','y','Mo','t'},...
        'independent','f','dependent','u');
    
     % Save parameter info
    
    egfcorr.model.coeff = {'C','fc','Q'};
    egfcorr.model.problem = {'n','y','Mo','t'};
    
elseif whichmod == 4
    
    Bmod = fittype('log10(C*Mo*exp(-pi*t*f/Q)/(1+(f/fc)^(n*y))^(1/y))','coefficients',{'C','fc','n'},'problem',{'y','Mo','t','Q'},...
        'independent','f','dependent','u');
    
     % Save parameter info
    
    egfcorr.model.coeff = {'C','fc','n'};
    egfcorr.model.problem = {'y','Mo','t','Q'};
    
elseif whichmod == 5
    
    Bmod = fittype('log10(C*Mo*exp(-pi*t*f/Q)/(1+(f/fc)^(n*y))^(1/y))','coefficients',{'C','fc'},'problem',{'n','y','Mo','t','Q'},...
        'independent','f','dependent','u');
    
     % Save parameter info
    
    egfcorr.model.coeff = {'C','fc'};
    egfcorr.model.problem = {'n','y','Mo','t','Q'};
    
end

% Note: y & n determined earlier when creating EGF

fitop = fitoptions(Bmod);
fitop.Robust = 'LAR';

disp(' ')
disp('Model to be fit:')
Bmod

% Fit Brune model to each corrected coda amp curve

 if whichmod == 3
     
     disp(' ')
     Qstrt = input('What value of Q should be used to start? (double): ');
     
     while isempty(Qstrt) == 1
         
         disp(' ')
         disp('Error: Please enter a numerical value.')
         Qstrt = input('What value of Q should be used to start? (double): ');
         
     end
     
 end

disp(' ')
disp('Fitting Brune model to each event/bin....')
disp(' ')

for sta = 1:size(params.sta.list,1)

    station = strcat(params.sta.list(sta,:));
    
    for row = 1:size(egfcorr.(station).eblist,1)
    
        ebname = strcat('eb',num2str(row));
        
        realval = [0 0]; % reset temporary matrix
        
        % Put all non-NaN values into a temporary matrix
        
        for fn = 1:filtnum
            
            if isnan(egfcorr.(station).(ebname).corramp(fn,1)) == 0
                
                if realval == 0
                
                    realval = [egfcorr.(station).(ebname).corramp(fn,1) params.nbands(fn,3)];
                    
                else
                    
                    realval = vertcat(realval,[egfcorr.(station).(ebname).corramp(fn,1) params.nbands(fn,3)]);
                
                end
                
            end
            
        end
        
        % Set up starting point & boundaries for co-efficients
        
%        Cstrt = log10(corrcamp.(ebname).Mo);
        Cstrt = 1;
        fcstrt = (sdrop * 10^6 / data.(egfcorr.(station).eblist{row,1}).Mo * 16/7)^(1/3) * k * Vel; % Hz
        
        if whichmod == 1
            
            fitop.StartPoint = [Cstrt fcstrt];
            fitop.Lower = [0 0];
            fitop.Upper = [2 15];
            
            % perform fit
            
            [egfcorr.(station).(ebname).Bfit, egfcorr.(station).(ebname).gof, egfcorr.(station).(ebname).out] = fit(realval(:,2),...
                realval(:,1),Bmod,'problem',{n y data.(egfcorr.(station).eblist{row,1}).Mo},fitop);
    
            
        elseif whichmod == 2
            
            fitop.StartPoint = [Cstrt fcstrt 2];
            fitop.Lower = [0 0 1];
            fitop.Upper = [2 15 5];
            
            % perform fit
            
            [egfcorr.(station).(ebname).Bfit, egfcorr.(station).(ebname).gof, egfcorr.(station).(ebname).out] = fit(realval(:,2),...
                realval(:,1),Bmod,'problem',{y data.(egfcorr.(station).eblist{row,1}).Mo},fitop);
            
        elseif whichmod == 3
            
            fitop.StartPoint = [Cstrt fcstrt Qstrt];
            fitop.Lower = [0 0 0];
            fitop.Upper = [2 15 1000];
        
            % perform fit
            
            [egfcorr.(station).(ebname).Bfit, egfcorr.(station).(ebname).gof, egfcorr.(station).(ebname).out] = fit(realval(:,2),...
                realval(:,1),Bmod,'problem',{n y data.(egfcorr.(station).eblist{row,1}).Mo data.(egfcorr.(station).eblist{row,1}).(station).ttime},fitop);
            
        elseif whichmod == 4
           
            fitop.StartPoint = [Cstrt fcstrt 2];
            fitop.Lower = [0 0 1];
            fitop.Upper = [2 15 5];
            
            % perform fit
            
            [egfcorr.(station).(ebname).Bfit, egfcorr.(station).(ebname).gof, egfcorr.(station).(ebname).out] = fit(realval(:,2),...
                realval(:,1),Bmod,'problem',{y data.(egfcorr.(station).eblist{row,1}).Mo data.(egfcorr.(station).eblist{row,1}).(station).ttime Q},fitop);
            
        elseif whichmod == 5
            
            fitop.StartPoint = [Cstrt fcstrt];
            fitop.Lower = [0 0];
            fitop.Upper = [2 15];
            
            % perform fit
            
            [egfcorr.(station).(ebname).Bfit, egfcorr.(station).(ebname).gof, egfcorr.(station).(ebname).out] = fit(realval(:,2),...
                realval(:,1),Bmod,'problem',{n y data.(egfcorr.(station).eblist{row,1}).Mo data.(egfcorr.(station).eblist{row,1}).(station).ttime Q},fitop);
            
        end

    end
        
end

% Average corner frequency over all stations for each event/bin
% If applicable, do same for n or Q

disp(' ')
disp('Averaging free parameters for each event/bin over all stations....')

for row = 1:size(egfcorr.eblist,1)
    
    % reset variables for each event
    
    stanum = 0;   
    fcsum = 0;
    
    if whichmod == 2 || whichmod == 4
    
        nsum = 0;
    
    elseif whichmod == 3
    
        Qsum = 0;
    
    end
    
    for sta = 1:size(params.sta.list,1)
    
        station = strcat(params.sta.list(sta,:));
        
        % make sure event/bin is 'good' on the station
        
        for r = 1:size(egfcorr.(station).eblist,1)
            
            if strcmpi(egfcorr.(station).eblist{r,1},egfcorr.eblist{row,1}) == 1
                
                ebname = strcat('eb',num2str(r));
                
                fcsum = fcsum + egfcorr.(station).(ebname).Bfit.fc; % add fc value
                
                if whichmod == 2 || whichmod == 4
                    
                    nsum = nsum + egfcorr.(station).(ebname).Bfit.n;
                    
                elseif whichmod == 3
                    
                    Qsum = Qsum + egfcorr.(station).(ebname).Bfit.Q;
                    
                end
                
                stanum = stanum + 1; % number of values added
                
                break; % match found - exit loop & move to next station
                
            end

        end
            
    end
        
    % Calculate the average fc (& n or Q when applicable)
    
    name = egfcorr.eblist{row,1};
    
    egfcorr.fcavg.(name) = fcsum / stanum;
    
    if whichmod == 2 || whichmod == 4
    
        egfcorr.navg.(name) = nsum / stanum;
        
    elseif whichmod == 3
        
        egfcorr.Qavg.(name) = Qsum / stanum;
        
    end
    
end

% Clear temporary variables

clear realval ebname fcstrt Cstrt sta sum stanum station r row name


%% Plot Brune Model Fit and/or Goodness of Fit

disp('--------------------')
disp(' ')
plBmod = input('Plot the Brune model fit? (N or Y): ','s');

while strcmpi(plBmod,'N') == 0
        
        % organize by stations (multiple events per figure)
        
        % plot all events/bins on figure for each station
    
        for stafig = 1:size(params.sta.list,1)

            station = params.sta.list(stafig,:);

            figure;

            hold on;

            grid on;

            for oneb = 1:size(egfcorr.(station).eblist,1)

                % Plot events

                pleb = strcat('eb',num2str(oneb));

                linespec = ['-r' '-g' '-b' '-c' '-m' '-y' '-k'];
                
                dataspec = ['*r' '*g' '*b' '*c' '*m' '*y' '*k'];
                
                plot(egfcorr.(station).(pleb).Bfit,linespec(1,(rem(oneb,7)*2+1):(rem(oneb,7)*2+2)),...
                    params.nbands(:,3),egfcorr.(station).(pleb).corramp,...
                    dataspec(1,(rem(oneb,7)*2+1):(rem(oneb,7)*2+2)));

            end
            
            set(gca,'XScale','log');
            title(['Station: ',station]);
            xlabel('Frequency (Hz)');
            ylabel('Non-dim Amplitude');      
            
        end
    
    disp(' ')
    plBmod = input('Make another Brune model plot? (N or Y): ','s'); 
    
end

% Following section not working - could be due to difference in Matlab version

% % Plot goodness of fit (r-squared value)
% 
% disp(' ')
% plgof = input('Make r-squared value plot? (N or Y): ','s');
% 
% if strcmpi(plgof,'N') == 0
%     
%     for stafig = 1:size(params.sta.list,1)
%     
%         station = params.sta.list(stafig,:);
%         
%         % Make colormap
% 
%         cmp = makecmp(egfcorr.(station).eblist);
% 
%         % Plot all events on one plot
% 
%         figure;
% 
%         for oneb = 1:size(egfcorr.eblist,1)
% 
%             pleb = strcat('eb',num2str(oneb));
% 
%             hold on;
% 
%             grid on;
% 
%             % Plot r-squared values by station
% 
%             scatter(stafig,egfcorr.(station).(pleb).gof.rsquare,fcerr(1,2),fcerr(2,2),...
%                 'o','SizeData',64,'MarkerFaceColor',cmp(oneb,:),'MarkerEdgeColor','none')
% 
%         end
% 
%     end
%         
%     title('R-Squared Values for Each Brune Model Fit');
%     xlabel('Station');
%     ylabel('R-Squared');      
%     legend(egfcorr.(station).eblist{:,1},'location','EastOutside','ColorOrder',cmp);
%     ylim([-2 2]);
% 
%     % Set x-axis ticks to have station names
% 
%     set(gca,'XTick',0:1:(size(params.sta.list,1)+1));
% 
%     stalabels = cell((size(params.sta.list,1)+2),1);
% 
%     stalabels{1,1} = '';
%     stalabels{size(stalabels,1),1} = 'Avg';
% 
%     for onsta = 1:size(params.sta.list,1)
% 
%         stalabels{(onsta+1),1} = params.sta.list(onsta,:);
% 
%     end
% 
%     set(gca,'XTickLabel',stalabels);
% 
% end


%% Plot Free Parameters

disp('--------------------')
disp(' ')
plfc = input('Plot the fitted free parameter(s)? (N or Y): ','s');

while strcmpi(plfc,'N') == 0
    
    disp(' ')
    disp('Options for plotting:')
    disp('1 - Mo vs fc for all events plotted for each station')
    disp('2 - fc at all stations plotted for each event/bin')
    
     if whichmod == 2 || whichmod == 4
    
        disp('3 - Mo vs n for all events plotted for each station')
        disp('4 - n at all stations plotted for each event/bin')
        
    elseif whichmod == 3
        
        disp('3 - Mo vs Q for all events plotted for each station')
        disp('4 - Q at all stations plotted for each event/bin')
        
    end
    
    disp(' ')
    plop = input('Choose an option (default 2): ');
    
    if isempty(plop) == 1
    
        plop = 2;
        
    end
    
    % organize by stations (multiple events per figure)
    
   if plop == 1 || plop == 3
        
       if plop == 1
           
           % Make Mo ~ fc^-3 line to plot
           
           fc = 0.1:1:15.1;
           
           theoryline = (fc).^(-3) * 10^14;
           
           % Assign free parameter name
           
           fpar = 'fc';
           
       else
           
           % Assign free parameter name
           
           if whichmod == 3
               
               fpar = 'Q';
               
           else
               
               fpar = 'n';
               
           end
           
       end
       
       % Plot Mo vs fc (or n or Q) for each station
       
        for stafig = 1:size(params.sta.list,1)
         
            station = params.sta.list(stafig,:);
            
            % plot all events/bins on figure for each station

            figure;
            hold on;
            grid on;

            for oneb = 1:size(egfcorr.(station).eblist,1)

                pleb = strcat('eb',num2str(oneb));

                % Plot fc and bounds
                
                scatter(egfcorr.(station).(pleb).Bfit.(fpar),data.(egfcorr.(station).eblist{oneb,1}).Mo,'fill','o')

            end
            
            if plop == 1
                
                % Add the Mo ~ fc^-3 line
                
                plot(fc,theoryline,'k')
                
            end
            
            title(['Station: ',station,' - Mo vs ' fpar]);
            ylabel('Moment (N*m)');
            
            if whichmod == 3 && plop == 3
                xlabel('Q-value');
                set(gca,'YScale','log');
            elseif (whichmod == 2 || whichmod == 4) && plop == 3
                xlabel('Frequency Fall-off n')
                set(gca,'YScale','log');
            else
                xlabel('Corner Frequency (Hz)');
                xlim([0.1 20])
                set(gca,'YScale','log','XScale','log');
            end
            
            legend(egfcorr.(station).eblist{:,1},'location','EastOutside');
            
        end
        
        % Plot Mo vs fc (or n or Q) for the average
        
        figure;
        hold on;
        grid on;
        
        for oneb = 1:size(egfcorr.eblist,1)
            
            pleb = strcat('eb',num2str(oneb));
            
            % Plot free parameter and bounds
            
            scatter(egfcorr.(strcat(fpar,'avg')).(egfcorr.eblist{oneb,1}),data.(egfcorr.eblist{oneb,1}).Mo,'fill','o')
            
        end
        
        if plop == 1
            
            % Add the Mo ~ fc^-3 line
            
            plot(fc,theoryline,'k')
            
        end
        
        title(['Station Average - Mo vs ' fpar]);
        ylabel('Moment (N*m)');
        
        if whichmod == 3 && plop == 3
            xlabel('Q-value');
            set(gca,'YScale','log');
        elseif (whichmod == 2 || whichmod == 4) && plop == 3
            xlabel('Frequency Fall-off n')
            set(gca,'YScale','log');
        else
            xlabel('Corner Frequency (Hz)');
            xlim([0.1 20])
            set(gca,'YScale','log','XScale','log');
        end
        
        legend(egfcorr.eblist{:,1},'location','EastOutside');
        
   else   % organize by event/bin (multiple stations per figure)
        
        % plot all events/bins on figure for each station
    
        if plop == 4
            
            if whichmod == 3
                
                fpar = 'Q';
            
            else
                
                fpar = 'n';
            
            end
            
            fparnum = 3;
            
        else
            
            fpar = 'fc';
            
            fparnum = 2;
            
        end
        
        for oneb = 1:size(egfcorr.eblist,1)

            figure;
            hold on;
            grid on;

            for stafig = 1:size(params.sta.list,1)

                station = params.sta.list(stafig,:);
                
                % make sure event/bin is 'good' on the station
                
                for r = 1:length(egfcorr.(station).eblist)
                    
                    if strcmp(egfcorr.(station).eblist{r,1},egfcorr.eblist{oneb,1}) == 1
                        
                        pleb = strcat('eb',num2str(r));
                        
                        % Calculate 95% confidence bounds
                        
                        fparerr = confint(egfcorr.(station).(pleb).Bfit);
                        
                        % Plot free parameter and bounds
                        
                        errorbar(stafig,egfcorr.(station).(pleb).Bfit.(fpar),fparerr(1,fparnum),fparerr(2,fparnum),...
                            'o','LineWidth',2,'Color','b')
                        
                        break; % match found - exit loop
                        
                    end
                    
                end

            end
            
            % Plot average of free parameter
                
            scatter((stafig+1),egfcorr.(strcat(fpar,'avg')).(egfcorr.eblist{oneb,1}),'fill','bo','SizeData',64)
            
            if strcmpi(egfcorr.eblist{oneb,1}(1),'e') == 1
                
                title({['Event ',egfcorr.eblist{oneb,1}(3:(length(egfcorr.eblist{oneb,1}))),...
                    ' Values'],'With 95% Confidence Bounds'});
                
            else
                
               title({['Bin ',egfcorr.eblist{oneb,1}(4:(length(egfcorr.eblist{oneb,1}))),...
                   ' Values'],'With 95% Confidence Bounds'});
                
            end
            
            xlabel('Station');
            
            if whichmod == 3 && plop == 4
                ylabel('Q-value');
            elseif (whichmod == 2 || whichmod ==4) && plop == 4
                ylabel('Frequency Fall-off n');
            else
                ylabel('Corner Frequency (Hz)');
            end
%            ylim([0 15]);
            
            % Set x-axis ticks to have station names
            
            set(gca,'XTick',0:1:(size(params.sta.list,1)+1));
            
            stalabels = cell((size(params.sta.list,1)+2),1);
            
            stalabels{1,1} = '';
            stalabels{size(stalabels,1),1} = 'Avg';
            
            for onsta = 1:size(params.sta.list,1)
                
                stalabels{(onsta+1),1} = params.sta.list(onsta,:);
                
            end
            
            set(gca,'XTickLabel',stalabels);
            
        end
        
    end
    
    disp(' ')
    plfc = input('Make another free parameter plot? (N or Y): ','s'); 
        
end


%% Write Results to file

disp('--------------------')
disp(' ')
writefpar = input('Write free parameter results to file? (N or Y): ','s'); % default Y

if strcmpi(writefpar,'N') == 0
    
    disp(' ')
    filename = input('Name your file (including directory): ','s');
    
    fid = fopen(filename,'w'); % open file for writing
    
    % Write headers
    
    fprintf(fid,'Name Station ');
    
    for col = 1:size(egfcorr.model.coeff,2)
        
        fprintf(fid,'%s lower upper ',egfcorr.model.coeff{col});
       
    end
    
    fprintf(fid,'\n'); % move to next line
    
    % Write data
       
    for sta = 1:size(params.sta.list,1)
        
        station = params.sta.list(sta,:);
        
        for ebn = 1:size(egfcorr.(station).eblist,1)
            
            ebname = strcat('eb',num2str(ebn));
            
            % Get 95% confidence bounds
            
            fparerr = confint(egfcorr.(station).(ebname).Bfit);
            
            % Print name and station
            
            fprintf(fid,'%s %s ',egfcorr.(station).eblist{ebn,:},station);
            
            % Print data
            
            for col = 1:size(egfcorr.model.coeff,2)
                
                fprintf(fid,'%9.4f %9.4f %9.4f ',egfcorr.(station).(ebname).Bfit.(egfcorr.model.coeff{col}),...
                    fparerr(1,col),fparerr(2,col));
                
            end
            
            fprintf(fid,'\n');
            
        end
        
    end
    
    fclose(fid); % close file
    
end

% Clear temporary variables

clear fid headformat format filename;


%% Give Choice to Repeat EGF Correction/Analysis

disp(' ')
EGFcorr = input('Repeat EGF corrections & analysis with new model? (Y or N): ','s');

end

disp(' ')
pickebcorr = input('Re-pick events/bins for EGF corrections & analysis? (Y or N): ','s');

end

end


%% End of program message

disp('--------------------')
disp(' ')
disp('End of Program :)')
disp(' ')
disp('--------------------')
disp(' ')