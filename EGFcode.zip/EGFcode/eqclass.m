%--------------------------------------------------------------------------%

% This program analyzes earthquake waveforms and defines them as
% high-frequency, hybrid, or low-frequency.

% Methods used:

% 1) Frequency Index from Buurman & West (2010)

% By: Gabrielle Tepp
% Created: 7/24/14
% Last updated: 7/24/14

% --------------------

% Utilizes the GISMO Correlation Toolbox and Waveform Suite
%
% By: Michael West and Celso Reyes (respectively)
%     Geophysical Institute, Alaska Volcano Observatory, U. Alaska Fairbanks
%     http://www.giseis.alaska.edu/Seis/EQ/tools/GISMO/
%
% Make sure the toolbox is installed. It is freely avaiable at the above website.

% --------------------

% Input defaults are listed second

% Event #'s are based on the order that the events are listed in your .mat file

% --------------------

% ** Before use, you will want to check/fix/update the following:

% ~ Create .mat Event File
%
% Your file should have the following column structure:
%
% [longitude latitude depth year month day hour minute second magnitude flag(optional)]
%
% *Notes: 1) Event #'s are based on the order listed in your .mat file
%         2) Magnitude column is optional (not actually used here).
%         3) For files to produce earthquake timetables, long, lat, and 
%             depth are needed. Otherwise, they are unnecessary. However, 
%             the algorithm refers to the column #'s for the time info. If 
%             you leave out the location info, either use empty (or "dummy") 
%             columns or change the column numbers within the algorithm.
%         4) Flag column is optional. Allows for the ability to ignore
%             events that you have flagged. Flagged events should have a
%             '1' in this column with all other events having a '0'.
% Alternately, you could change the read-in file part of the code.

% ~ File locations
%
% The file location algorithm needs to be updated based on the location of the
% files and formatting of file and folder names. This algorithm is not file-type
% specific (i.e. works for non-SAC files). The algorithm expects a
% directory system of event folders each containing the files relevant to
% that event (i.e. for each station and/or channel).

% ~ File type
%
% The program is currently set-up to only read SAC files. However, the
% GISMO Toolbox/Waveform Suite can handle other types of files. Refer to those
% manuals for information on how to read in non-SAC files. The only place
% that refers to file type is when initally reading in the waveforms from the file.

%--------------------------------------------------------------------------%

disp(' ')
disp('Clearing workspace....')

clear all % start with clean slate (some variables may change in size from one run to the next)


%% Get information from user (station, channel, start/end times)

% Prompt for event information

disp('*----------------------------------------*')
disp(' ')
disp('Please enter the following information.')
disp('Comma separate (no space) multiple entries for array/station/channel.')
disp('--------------------')
disp(' ')

params.arr.str = input('Enter the array code (* for all): ', 's');

params.sta.str = input('Enter a station(s) (* for all): ', 's');

params.cha.str = input('Enter a channel(s) (* for all): ');

disp(' ')
params.time.start.str = input('Enter a start date and time [dd-Mon yyyy HH:MM]: ','s');

params.time.end.str = input('Enter an end date and time [dd-Mon yyyy HH:MM]: ','s');

disp(' ')
evfile = input('Enter the event list file name (.mat): ','s');
disp(' ')
disp('You may choose one or more events from your file list (default all).')
disp('** Entry format example: 6:10 or 6/7/8/9/10 or 6/7:9/10')
disp('** Use ''*'' for all events within date bounds.')
disp(' ')
params.num.str = input('List the event #''s you would like to see (* for all): ','s');

disp('--------------------')

% if array/channel/station left empty, make wildcard

if isempty(params.arr.str) == 1
    
    params.arr.str = '*';
    
end

if isempty(params.sta.str) == 1
    
    params.sta.str = '*';
    
end

if isempty(params.cha.str) == 1
    
    params.cha.str = '*';
  
end

% Allow user to check waveforms and choose to keep or ignore

disp(' ')
checkwf = input('Would you like to check waveforms? (Y or N): ','s');

% Keep all waveforms if no check wanted (default N)

if strcmpi(checkwf,'Y') == 0
        
    keepwf = 'Y';
    
end

evdata = importdata(evfile);

% Since this option is not important here, ignore it
% % Allow user to override all sample frequency mismatches (default N)
% 
% disp(' ')
% alloverride = input('Automatically override all sample frequency mismatches? (Y or N): ','s');

alloverride = 'Y';


%% Make Vector Lists From Input Strings

% Make list with all events in time range (default)

if strcmpi(params.num.str,'*') == 1 || isempty(params.num.str) == 1
        
    % Create list of numbers for all events
    
    params.num.list = transpose(1:length(evdata));

else 
   
    % Convert event #s to usuable list

    params.num.list = makelist(params.num.str,'num');

end

% Remove any events that go beyond the number in evdata

templist = 0;

for n = 1:length(params.num.list)
    
    if params.num.list(n) <= size(evdata,1)
       
        if templist == 0
              
            templist = params.num.list(n);

        else

            templist = vertcat(templist,params.num.list(n));

        end
       
   end
    
end

% Replace event list with temporary list

params.num.list = sort(templist); % make sure final event list is ordered

% Convert array/station/channel input to usuable lists

params.arr.list = makelist(params.arr.str,'str');

params.sta.list = makelist(params.sta.str,'str');

params.cha.list = makelist(params.cha.str,'str');
    

%% Find Event Folders

% Convert to serial day/time

params.time.start.serial = datenum(params.time.start.str);

params.time.end.serial = datenum(params.time.end.str);

% Make event date-time string for foldername

for n = 1:length(evdata)
    
    % Change month and day to 2 digits if <10

    if evdata(n,5) < 10
        
        mm = strcat('0',num2str(evdata(n,5)));
        
    else
        
        mm = num2str(evdata(n,5));
        
    end
    
    if evdata(n,6) < 10
        
        dd = strcat('0',num2str(evdata(n,6)));
        
    else
        
        dd = num2str(evdata(n,6));
        
    end
    
    % Change hour, minute, and seconds to 2 digits if <10

    if evdata(n,7) < 10
        
        HH = strcat('0',num2str(evdata(n,7)));
        
    else
        
        HH = num2str(evdata(n,7));
        
    end
    
    if evdata(n,8) < 10
        
        MM = strcat('0',num2str(evdata(n,8)));
        
    else
        
        MM = num2str(evdata(n,8));
        
    end
        
%     if evdata(n,9) < 10
%         
%         SS = strcat('0',num2str(evdata(n,9)));
%         
%     else
%         
%         SS = num2str(evdata(n,9));
%         
%     end
    
    % Make string array of event date-times
    
    evdt = strcat(num2str(evdata(n,4)),'-',mm,'-',dd,'T',HH,'.',MM);
    
    if n == 1
        
        evdates = evdt;
            
    else
       
        evdates = vertcat(evdates,evdt);
        
    end
            
end

firstev = 0; % Has first event been added to folder list?

q = 1; % start with first listed event

keepevs = 0; % start with no events on list

% Make folder name for each event

for n = 1:length(evdata)
    
    evserial = datenum(evdates(n,:), 'yyyy-mm-ddTHH.MM');
        
if n == params.num.list(q) % only consider event if it's on list
    
% Only look for files if within given date range
    
if params.time.start.serial < evserial && evserial < params.time.end.serial    
    
    evfolder = strcat('/gpfs/fs1/home/gtepp/Documents/AFAR/20072009/AFAR07_',evdates(n,:),'.*');
    
    allfolderMM = dir(evfolder);
    
    if length(allfolderMM) > 1 % if more than 1 possibility, check seconds
        
        for j = 1:length(allfolderMM)
        
            SS = str2double(allfolderMM(j).name(25:26));
            
            % if folder within 2 sec of listed time, add and exit loop
            
            if (evdata(n,9)-2) < SS && SS < (evdata(n,9)+2)
               
                 if firstev == 0;
        
                    folderlist = allfolderMM(j).name;
                    
                    firstev = 1;
        
                 else
            
                    folderlist = vertcat(folderlist,allfolderMM(j).name);
            
                 end
                 
                 j = length(allfolderMM) + 1; % exit loop
                
            end
        
        end
        
    else % if only one possibility, then add to list
        
        if firstev == 0
        
            folderlist = allfolderMM.name;
            
            firstev = 1;
        
        else
            
            folderlist = vertcat(folderlist,allfolderMM.name);
            
        end
        
    end
    
    % Keep event info
    
    evnum = strcat('ev',num2str(n));
    
    data.(evnum).data = evdata(n,:);
    
    % If folder found, add event to 'good' list
    
    if isempty(allfolderMM) == 0
    
        if keepevs == 0

           keepevs = n;

        else

           keepevs = vertcat(keepevs,n);

        end
    
    end
end

    % if event is added, move to next event

    if q == size(params.num.list,1)
        
        n = size(folderlist,1);
    
    else
    
        q = q + 1;
        
    end
    
end
    
end

% Change event list to reflect 'good' events

params.num.list = keepevs;

% clear temporary variables

clear keepevs q n evnum firstev chaop


%% Get files (and data) and make correlation object

% Access each file and make a correlation object with all events

disp('--------------------')
disp(' ')
disp('Building correlation object....')
disp(' ')

% Make list of relevant files in folder
    
firstwf = 0; % indicates if first waveform has been included yet (switch to 1 after inclusion)
        
evwfnum = zeros(size(folderlist,1),2);

for m = 1:size(folderlist,1)

for a = 1:size(params.arr.list,1)
    
    arr = params.arr.list(a,:);
        
for s = 1:size(params.sta.list,1)
    
    sta = params.sta.list(s,:);
            
for c = 1:size(params.cha.list,1)
    
    cha = params.cha.list(c,:);

folderfile = strcat('/gpfs/fs1/home/gtepp/Documents/AFAR/20072009/',folderlist(m,:),'/',arr,'.',sta,'..',cha,'*Z.SAC'); % Which files

filelist = dir(folderfile); % Make list of relevant files

numfiles = length(filelist);

scnl = scnlobject(sta,cha,'*','*'); % Create SCNL object

% Look through each folder for files and add waveforms to correlation object

% Build correlation object

for k = 1:numfiles
    
    filename = strcat('/gpfs/fs1/home/gtepp/Documents/AFAR/20072009/',folderlist(m,:),'/',filelist(k).name);
    
    ds = datasource('sac', filename);
    
    w = waveform(ds,scnl,params.time.start.serial,params.time.end.serial); % create waveform from file
    
    if strcmpi('Y',checkwf) == 1
        
        plot(w);
    
        disp(' ')
        keepwf = input(['Would you like to keep waveform ' num2str(m) '-' num2str(k) '? (N or Y): '],'s'); % (default Y)
        
    end
    
if strcmpi('N',keepwf) == 0
        
    evwfnum(m,1) = params.num.list(m); % add event number to list
    
    % Add waveforms to events matrix
    
    if firstwf == 0
        
        w1freq = get(w,'freq');
        
        trig1 = datenum(get(w,'start_str'),'yyyy-mm-dd HH:MM:SS.FFF',2005);

        cobj = correlation(w,trig1); % create correlation object from waveform
    
        allcobj = cobj;
        
        firstwf = 1;
        
        evwfnum(m,2) = evwfnum(m,2) + 1; % count waveforms per event
        
    else
        
        wfreq = get(w,'freq');
            
        trig = datenum(get(w,'start_str'),'yyyy-mm-dd HH:MM:SS.FFF',2005);
    
    % Only add to master if sampling frequency is the same as event 1
        
    if wfreq == w1freq
        
       cobj = correlation(w,trig); % create correlation object from waveform 
        
       allcobj = cat(allcobj,cobj);
       
       evwfnum(m,2) = evwfnum(m,2) + 1; % count waveforms per event
       
    else
       
       disp('--------------------')
       disp(' ')
       disp(['Event 1 freq = ' num2str(w1freq) ' & Event ' num2str(m) '-' num2str(k) ' freq = ' num2str(wfreq)]);
       
       if strcmpi(alloverride,'Y') == 1
           
           freqer = 'Y';
           
       else
       
           disp(' ')
           freqer = input('There is a frequency mismatch. Override? (Y or N): ','s'); % (default N)
       
       end
       
       if strcmpi(freqer,'Y') == 1
       
            wnew = set(w,'freq',w1freq);
        
            cobj = correlation(wnew,trig); % create correlation object from waveform 
        
            allcobj = cat(allcobj,cobj);
            
            evwfnum(m,2) = evwfnum(m,2) + 1; % count waveforms per event
            
       else
           
           disp(' ')
           disp(['Event ' num2str(k) ' was not added not correlation object.'])
           
       end
    
    end
    
    end
    
end

end

end

end

end

end

% Clear temporary variables

clear filelist folderlist cobj w wnew w1freq wfreq HH MM SS trig allfolderMM trig1;
clear evfile evfolder evserial filename folderfile evdates evdt evfile evfolder;


%% Cropping, (Initial) Filtering and Plotting

disp(' ')
disp('--------------------')

[allcobj params] = filtcrop(allcobj,params,'wig');


%% Calculate SNR

disp('--------------------')
disp(' ')
disp('Determine the bounds for the noise measurement.')
disp(' ')
chkpl = input('Would you like to check a plot of waveforms? (Y or N): ','s');

if strcmpi(chkpl,'Y') == 1
    
    plot(allcobj,pltype,1,perm);
    
end

% set time bounds for noise measurement

chkbd = 0;

while chkbd == 0
    
    disp(' ')
    minbd = input('Minimum bound (sec, double): ');
    maxbd = input('Maximum bound (sec, double): ');
    
    if minbd < params.crop.start
        
        disp(' ')
        disp('Minimum bound is less than waveform starting value.')
        disp('Please try again.')
        
    elseif minbd > maxbd
        
        disp(' ')
        disp('Minimum bound is greater than maximum bound.')
        disp('Please try again.')
        
    else
        
        chkbd = 1;
        
    end
    
end

disp(' ')
snrbd = input('Flag events below what SNR value? (double, default 1): ');

if isempty(snrbd) == 1
    
    snrbd = 1;
    
end

badevs = 0;

goodevs = 0;

% Get SNR for each event at each station

for e = 1:length(params.num.list)
    
    evnum = strcat('ev',num2str(evwfnum(e,1)));
    
    for st = 1:size(data.(evnum).stalist,1)
    
        station = data.(evnum).stalist(st,:);
        
        % Determine sample number limits of noise measurement
        
        % Start and end at chosen bounds
        % round up to nearest integer; subtract off intial crop value
        
        nstrt = ceil((minbd - params.crop.start) * data.(evnum).(station).sfreq);
        
        % make sure bound does not start at point 0
        
        if nstrt == 0
            
            nstrt = 1;
            
        end
        
        nend = ceil((maxbd - params.crop.start) * data.(evnum).(station).sfreq);
        
        for nbr = 1:filtnum
            
            % Find average amplitude of noise
            
            nlvl = sum(data.(evnum).(station).allenv(nbr,nstrt:nend)) / (nend - nstrt + 1);
            
            % Calculate SNR
            
            if nbr == 1
                
                % since we have log amplitudes, subtract then convert to "true" SNR
                
                data.(evnum).(station).snr = exp(data.(evnum).(station).cavg(nbr,1) - nlvl);
                
            else
                
                data.(evnum).(station).snr = vertcat(data.(evnum).(station).snr,...
                    exp(data.(evnum).(station).cavg(nbr,1) - nlvl));
                
            end
            
            % Compare SNR to allowed value; if smaller, flag event
            
            if data.(evnum).(station).snr(nbr,1) < snrbd
                
                data.(evnum).(station).bad = 1;
                
                badevs = badevs + 1;
                
            else
                
                data.(evnum).(station).bad = 0;
                
                goodevs = goodevs + 1;
                
            end
            
        end
        
    end
    
end

disp(' ')
disp(['There are ' num2str(badevs) ' bad events out of ' num2str((goodevs+badevs)) ' total.'])
disp(' ')
disp('Amplitudes will be recalculated if SNR is changed.')

% if strcmpi(chksnr,'Y') == 0
%     
%     % Ask if noise should be removed from measurements
%     
%     disp(' ')
%     nonoise = input('Would you like to remove the noise from the amplitudes? (Y or N): ','s');
%     
%     if strcmpi(nonoise,'Y') == 1
%         
%         for e = 1:length(params.num.list)
%             
%             evnum = strcat('ev',num2str(evwfnum(e,1)));
%             
%             for st = 1:size(data.(evnum).stalist,1)
%                 
%                 station = data.(evnum).stalist(st,:);
%                 
%                 for nbr = 1:filtnum
%                     
%                     % if value isn't NaN and SNR > 1 - to avoid imaginary numbers
%                     
%                     if isnan(data.(evnum).(station).cavg(nbr,1)) == 0 && data.(evnum).(station).snr(nbr,1) > 1
%                         
%                         data.(evnum).(station).cavg(nbr,1) = data.(evnum).(station).cavg(nbr,1) + log(1 -...
%                             1/(data.(evnum).(station).snr(nbr,1)));
%                         
%                     end
%                     
%                 end
%                 
%             end
%             
%         end
%         
%     end
%     
% end
    

%% Frequency Index Method

% Calculate SNR starting at P-pick

% Choose frequency bands

params.nbands = nbfilts(2,'m'); % make 2 filters with manually selected bounds

disp(' ')
disp('--------------------')

% Choose where to start amplitude measurement

disp('--------------------')
disp(' ')
disp('Options for amplitude measurement start:')
disp('1 - S-wave pick')
disp('2 - P-wave pick')
disp('3 - Choose your own (not yet available)')
disp(' ')
ampstrtop = input('Pick an option (integer): ');

while isempty(ampstrtop) == 1
    
    disp(' ')
    disp('** You must choose an option. Please try again. **')
    disp(' ')
    ampstrtop = input('Pick an option (integer): ');
    
end

 if ampstrtop == 1
     
     ampstrt = 'spick';
     
 elseif ampstrtop == 2
     
     ampstrt = 'ppick';
     
 end

disp(' ')
ampmlen = input('How long (sec) do you want the measurement? (double): ');

while isempty(ampmlen) == 1
    
   disp(' ')
   disp('** You must enter a measurement length. Please try again. **')
   disp(' ') 
   ampmlen = input('How long (sec) do you want the measurement? (double): ');
   
end

disp('--------------------')
disp(' ')

% Apply Filters & Calculate Envelopes

disp(' ')
disp('Applying filters and calculating envelopes....')

for nbf = 1:(filtnum+1)
    
    if nbf <= filtnum
    
        disp(' ')
        disp(['Working on filter ' num2str(nbf) ' of ' num2str(filtnum) '....'])
        
        % Apply filters

        nbfcobj = butter(allcobj,[params.nbands(nbf,1) params.nbands(nbf,2)]); % Default as 4-pole filter
        % Note: filter runs forward & backward, effectively doubling # of poles

        allwf = waveform(nbfcobj); % change correlation object to waveform object

        % First, calculate Hilbert transform (hil)

        hilb = hilbert(allwf);
        
        % Name for narrow-band

        nb = strcat('nb',num2str(nbf));
        
    else
        
        disp(' ')
        disp('Saving unfiltered waveforms....')
        
        allwf = waveform(allcobj); % change correlation object to waveform object
        
    end

    % Sort Waveforms by Event

    endr = 0;
    
    for h = 1:length(params.num.list)

        evnum = strcat('ev',num2str(evwfnum(h,1)));

        startr = 1 + endr;

        endr = startr + evwfnum(h,2) - 1;
    
        nosta = 1;
        
        cha = 1;
        
        % Get all waveforms of event from correlation object

        for hnum = startr:endr

            station = get(allwf(hnum),'station');
            channel = get(allwf(hnum),'channel');
            
            if nosta == 1

                data.(evnum).stalist = station;
                
                nosta = 0;
                
            else
                
                data.(evnum).stalist = vertcat(data.(evnum).stalist,station);
            
            end  

            if strcmpi(channel(3),'E') == 1 || strcmpi(channel(3),'Z') == 1

                cha = 1;

            elseif strcmpi(channel(3),'N') == 1

                cha = 2;

            end

            if cha == 1

                if nbf <= filtnum
                
                    data.(evnum).(station).wf.(nb) = allwf(hnum);
                    data.(evnum).(station).hil.(nb) = hilb(hnum);   
                
                else
                    
                    data.(evnum).(station).wf.nb0 = allwf(hnum);
                    
                end

            elseif cha == 2

                if nbf <= filtnum
                    
                    data.(evnum).(station).wf.(nb) = vertcat(data.(evnum).(station).wf.(nb),allwf(hnum));
                    data.(evnum).(station).hil.(nb) = vertcat(data.(evnum).(station).hil.(nb),allwf(hnum));
                
                else
                    
                    data.(evnum).(station).wf.nb0 = vertcat(data.(evnum).(station).wf.nb0,allwf(hnum));
                    
                end
                
            end

        end

        % Make sure station list only has one entry for each station

        data.(evnum).stalist = unique(data.(evnum).stalist,'rows');
    
        if nbf <= filtnum

            % Calculate envelope for each channel

            for ns = 1:size(data.(evnum).stalist,1)

                station = data.(evnum).stalist(ns,:);

                data.(evnum).(station).env.(nb) = zeros(size(params.cha.list,1),...
                    length(get(data.(evnum).(station).wf.(nb)(1,1),'data')));

                for cr = 1:size(params.cha.list,1)

                    % Make envelope

                    data.(evnum).(station).env.(nb)(cr,:) = transpose(sqrt((get(data.(evnum).(station).wf.(nb)(cr,:),...
                        'data')).^2 + (get(data.(evnum).(station).hil.(nb)(cr,:),'data')).^2));

                    % Take log 10 of envelope

                    data.(evnum).(station).env.(nb)(cr,:) = log10(data.(evnum).(station).env.(nb)(cr,:));

                end

            end
        
        end
    
    end

end 

params.sta.list = data.(evnum).stalist;

% Get S-picks & sampling frequencies for later use & Other Data

for h = 1:size(params.num.list,1)

    evnum = strcat('ev',num2str(evwfnum(h,1)));
    
    for ns = 1:size(data.(evnum).stalist,1)
        
        station = data.(evnum).stalist(ns,:);

        data.(evnum).(station).spick = get(data.(evnum).(station).wf.nb0(1,1),'T2'); % get event S-wave pick
        data.(evnum).(station).ppick = get(data.(evnum).(station).wf.nb0(1,1),'T1'); % get event P-wave pick
        data.(evnum).(station).sfreq = get(data.(evnum).(station).wf.nb0(1,1),'FREQ'); % get event sampling frequency
        
    end
    
    data.(evnum).data = evdata(evwfnum(h,1),:);
    
end

% no longer need evdata, so clear it

clear evdata;

smth = 'Y';

% Average horizontal envlopes (if applicable) & smooth result

while strcmpi(smth,'Y') == 1

disp(' ')
disp('--------------------')
disp(' ')

if size(params.cha.list,1) == 1
    
    disp('The envelopes in each band will now be smoothed with a moving average filter (mav).')
    
else

    disp('The horizontal component envelopes in each band will now be')
    disp('   averaged and smoothed with a moving average filter (mav).')

end

disp(' ')
mavwin = input('How many samples should the mav window span? (odd integer, default 301): '); % default 301

if isempty(mavwin) == 1
    
    mavwin = 301;
    
end

for ev = 1:length(params.num.list)
    
    evr = strcat('ev',num2str(evwfnum(ev,1)));
    
    disp(' ')
    disp(['Working on event ' num2str(ev) ' of ' num2str(length(params.num.list)) '....'])
    
    for star = 1:size(data.(evr).stalist,1)
    
        cursta = data.(evr).stalist(star,:);
        
        for nbr = 1:filtnum

            nb = strcat('nb',num2str(nbr));
            
            if size(params.cha.list,1) == 1
                
                envel = data.(evr).(cursta).env.(nb)(1,:);
                
            else
            
                % Average envelopes of horizontals (E&N)

                envel = (data.(evr).(cursta).env.(nb)(1,:) + data.(evr).(cursta).env.(nb)(2,:)) / 2;
            
            end

            % Smooth averaged envelope (moving average filter)
            
            if nbr == 1
            
                data.(evr).(cursta).allenv = transpose(smooth(envel,mavwin));
                
            else
                
                data.(evr).(cursta).allenv = vertcat(data.(evr).(cursta).allenv,...
                    transpose(smooth(envel,mavwin)));
              
            end
            
        end

        clear envel
        
    end
        
end

% Clear temporary variables

clear allwf hilb nbfcobj allcobj;

end

% Calculate Amplitude Values for Chosen Interval 

disp(' ')
disp('--------------------')
disp(' ')
disp('Calculating amplitudes for chosen interval...')

for e = 1:length(params.num.list)

    evnum = strcat('ev',num2str(evwfnum(e,1)));
    
    for st = 1:size(data.(evnum).stalist,1)

        station = data.(evnum).stalist(st,:);

        % Determine sample number limits of coda

        % start at desired value
        
        codastrt = ceil((data.(evnum).(station).(ampstrt) - params.crop.start) * data.(evnum).(station).sfreq); 
        % round up to nearest integer; subtract off intial crop value

        % end after chosen interval
        
        codaend = codastrt + ceil(ampmlen * data.(evnum).(station).sfreq);

        for nbr = 1:filtnum

            % Find average amplitude of coda
            
            if nbr == 1

                data.(evnum).(station).cavg = sum(data.(evnum).(station).allenv(nbr,codastrt:codaend))...
                    / (codaend - codastrt + 1);

            else

                data.(evnum).(station).cavg = vertcat(data.(evnum).(station).cavg,...
                    (sum(data.(evnum).(station).allenv(nbr,codastrt:codaend)) / (codaend - codastrt + 1)));

            end
            
            % Check amplitude value & get rid of any less than or equal to zero

            if data.(evnum).(station).cavg(nbr,1) <= 0
                
                 data.(evnum).(station).cavg(nbr,1) = NaN;
                
            end
            
        end

    end
    
end
