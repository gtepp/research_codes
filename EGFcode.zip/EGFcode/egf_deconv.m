%--------------------------------------------------------------------------%

% This program is for doing empirical Green's function analysis using a
% deconvolution method. 

% By: Gabrielle Tepp, University of Rochester
% Created: 8/20/14
% Last updated: 5/25/16

% --------------------

% Utilizes the GISMO Correlation Toolbox and Waveform Suite
%
% By: Michael West and Celso Reyes (respectively)
%     Geophysical Institute, Alaska Volcano Observatory, U. Alaska Fairbanks
%     http://www.giseis.alaska.edu/Seis/EQ/tools/GISMO/
%
% Make sure the toolbox is installed. It is freely avaiable at the above website.

% The signal processing toolbox may also be used, primarily for filtering.
% If you don't have the toolbox, you can replace the filtering steps with
% your own filters.

% --------------------

% Input defaults are listed second

% Event #'s are based on the order that the events are listed in your .mat file

% --------------------

% ** Before use, you will want to check/fix/update the following:

% ~ Create .mat Event File
%
% Your file should have the following column structure:
%
% [longitude latitude depth year month day hour minute second magnitude flag(optional)]
%
% *Notes: 1) Event #'s are based on the order listed in your .mat file
%         2) Magnitude column is optional (not actually used here).
%         3) For files to produce earthquake timetables, long, lat, and 
%             depth are needed. Otherwise, they are unnecessary. However, 
%             the algorithm refers to the column #'s for the time info. If 
%             you leave out the location info, either use empty (or "dummy") 
%             columns or change the column numbers within the algorithm.
%         4) Flag column is optional. Allows for the ability to ignore
%             events that you have flagged. Flagged events should have a
%             '1' in this column with all other events having a '0'.
% Alternately, you could change the read-in file part of the code.

% ~ File locations
%
% The file location algorithm needs to be updated based on the location of the
% files and formatting of file and folder names. This algorithm is not file-type
% specific (i.e. works for non-SAC files). The algorithm expects a
% directory system of event folders each containing the files relevant to
% that event (i.e. for each station and/or channel).

% ~ File type
%
% The program is currently set-up to only read SAC files. However, the
% GISMO Toolbox/Waveform Suite can handle other types of files. Refer to those
% manuals for information on how to read in non-SAC files. The only place
% that refers to file type is when initally reading in the waveforms from the file.

%--------------------------------------------------------------------------%

disp(' ')
disp('Clearing workspace....')

clear all % start with clean slate (some variables may change in size from one run to the next)


%% Get information from user (station, channel, start/end times)

% Prompt for event information

disp('*----------------------------------------*')
disp(' ')
disp('Please enter the following information.')
disp('Comma separate (no space) multiple entries for array/station/channel.')
disp('--------------------')
disp(' ')

params.arr.str = input('Enter the array code (* for all): ', 's');

params.sta.str = input('Enter a station(s) (* for all): ', 's');

params.cha.str = input('Enter a channel(s) (* for all): ','s');

% disp(' ')
% disp('1 - Horizontals (BHE & BHN)')
% disp('2 - Vertical (BHZ)')
% disp(' ')
% chaop = input('Pick a channel option (integer, default 1): ');
% 
% % If not broadband (BH*), change these to needed format
% 
% if chaop == 2
%     
%     params.cha.str = 'BHZ';
%     
% else
%     
%     params.cha.str = 'BHE,BHN';
%     
% end

disp(' ')
params.time.start.str = input('Enter a start date and time [dd-Mon yyyy HH:MM]: ','s');

params.time.end.str = input('Enter an end date and time [dd-Mon yyyy HH:MM]: ','s');

disp(' ')
evfile = input('Enter the event list file name (.mat): ','s');
disp('--------------------')

% if array/channel/station left empty, make wildcard

if isempty(params.arr.str) == 1
    
    params.arr.str = '*';
    
end

if isempty(params.sta.str) == 1
    
    params.sta.str = '*';
    
end

if isempty(params.cha.str) == 1
    
    params.cha.str = '*';
    
end

% Allow user to check waveforms and choose to keep or ignore

disp(' ')
checkwf = input('Would you like to check waveforms? (Y or N): ','s');

% Keep all waveforms if no check wanted (default N)

if strcmpi(checkwf,'Y') == 0
        
    keepwf = 'Y';
    
end

evdata = importdata(evfile);

% Choose to restrict data

disp(' ')
restdat = input('Would you like to restrict the events (R) or use all events in the file (A, default)?: ','s');

if strcmpi(restdat,'R') == 1
    
   params = restrict_data(evdata,params);
   
else
    
    % Create list of numbers for all events
    
    params.num.str = '*';
    params.num.list = transpose(1:length(evdata));
    
end

disp('--------------------')
disp(' ')

% % Optional: allow ability to leave out events flagged in file
% 
% if size(evdata,2) == 11
% 
%     disp(' ')
%     keepflag = input('Keep flagged events? (Y or N): ','s');
%     
% else
%     
%     keepflag = 'Y'; % if no flags in file, ignore option
% 
% end
keepflag = 'Y';
% Since this option is not important here, ignore it
% % Allow user to override all sample frequency mismatches (default N)
% 
% disp(' ')
% alloverride = input('Automatically override all sample frequency mismatches? (Y or N): ','s');

alloverride = 'Y';


%% Make Vector Lists From Input Strings

% Make list with all events (default)

if strcmpi(params.num.str,'*') == 1 || isempty(params.num.str) == 1
        
    % Create list of numbers for all events
    
    params.num.list = transpose(1:length(evdata));

else 
   
    % Convert event #s to usuable list

    params.num.list = makelist(params.num.str,'num');

end

% Remove any events that go beyond the number in evdata

templist = 0;

for n = 1:length(params.num.list)
    
    if params.num.list(n) <= size(evdata,1)
       
        if templist == 0
              
            templist = params.num.list(n);

        else

            templist = vertcat(templist,params.num.list(n));

        end
       
   end
    
end

% Replace event list with temporary list
    
params.num.list = templist;

% Remove any flagged events if desired

if strcmpi(keepflag,'Y') == 0
    
    templist = 0;
    
    for p = 1:length(params.num.list)
        
       if evdata(params.num.list(p),11) == 0
           
          if templist == 0
              
              templist = params.num.list(p);
              
          else
              
              templist = vertcat(templist,params.num.list(p));
              
          end
           
       end
        
    end
    
    % Replace event list with temporary list
    
    params.num.list = templist;
    
end

params.num.list = sort(params.num.list); % make sure final event list is ordered

% Convert array/station/channel input to usuable lists

params.arr.list = makelist(params.arr.str,'str');

params.sta.list = makelist(params.sta.str,'str');

params.cha.list = makelist(params.cha.str,'str');
    

%% Find Event Folders

% Convert to serial day/time

params.time.start.serial = datenum(params.time.start.str);

params.time.end.serial = datenum(params.time.end.str);

params.time.start.vector = datevec(params.time.start.str);

params.time.end.vector = datevec(params.time.end.str);

% Make list of folders within date range

nodates = 1;

% Make list of year + month to search

year = params.time.start.vector(1,1);

while year <= params.time.end.vector(1,1)
    
    if year == params.time.start.vector(1,1) % starting month
        
        month = params.time.start.vector(1,2);

    else % start with January when year turns
        
        month = 1;
        
    end
    
    while (month <= params.time.end.vector(1,2) && year == params.time.end.vector(1,1)) ||...
            (month < 13 && year < params.time.end.vector(1,1)) % go until December or ending month
    
        % Make search string
        
        if month < 10 % put zero before single digit months
            
            monstr = strcat('0',num2str(month));
            
        else
            
            monstr = num2str(month);
            
        end
        
        ndat = strcat(num2str(year),'-',monstr);
        
        if nodates == 1
        
            nodates = 0;
            
            searchdates = ndat;
            
        else
            
            searchdates = vertcat(searchdates,ndat);
        
        end
        
        month = month + 1; % move to next month
    
    end
    
    year = year + 1; % move to next year
    
end

% Find folders within year & month range

for ond = 1:size(searchdates,1)

    allfolds = dir(strcat('/gpfs/fs1/home/gtepp/Documents/AFAR/20072009/AFAR07_',searchdates(ond,:),'*'));

    % Put into matrix
    
    for j = 1:length(allfolds)
    
        if ond == 1 && j == 1

            foldnames = allfolds(1).name;
            
        else
            
            foldnames = vertcat(foldnames,allfolds(j).name);
            
        end
    
    end
    
end

% Calculate serial time for all folders

foldser = datenum(foldnames(:,8:26),'yyyy-mm-ddTHH.MM.SS');

firstev = 0; % Has first event been added to folder list?

keepevs = 0; % start with no events on list

% Make folder name for each event

for n = 1:length(params.num.list)
    
    evn = params.num.list(n,1); % on this event
    
    evserial = datenum(evdata(evn,4:9));
    
% Only look for files if within given date range
    
if params.time.start.serial < evserial && evserial < params.time.end.serial    
    
    % Go through folder serial dates to find a match
    
    for chk = 1:size(foldser,1)
        
        % Check within +/- 4 sec
        
        if foldser(chk,1) > (evserial - (4 / 3600 /24)) && foldser(chk,1) < (evserial + (4 / 3600 /24))
            
            if firstev == 0;
                
                folderlist = foldnames(chk,:);
                
                firstev = 1;
                
            else
                
                folderlist = vertcat(folderlist,foldnames(chk,:));
                
            end
            
            % Keep event info
            
            evnum = strcat('ev',num2str(evn));
            
            data.(evnum).data = evdata(evn,:);
            
            % If folder found, add event to 'good' list
            
            if keepevs == 0
                
                keepevs = evn;
                
            else
                
                keepevs = vertcat(keepevs,evn);
                
            end
            
            break; % exit loop
            
        end
        
    end

end
    
end

% Change event list to reflect 'good' events

params.num.list = keepevs;

% clear temporary variables

clear keepevs q n evnum firstev chaop evn foldnames foldser allfolds chk ond j templist;


%% Get files (and data) and make correlation object

% Access each file and make a correlation object with all events

disp('--------------------')
disp(' ')
disp('Building correlation object....')
disp(' ')

% Make list of relevant files in folder
    
firstwf = 0; % indicates if first waveform has been included yet (switch to 1 after inclusion)
        
evwfnum = zeros(size(folderlist,1),2);

for m = 1:size(folderlist,1)

for a = 1:size(params.arr.list,1)
    
    arr = params.arr.list(a,:);
        
for s = 1:size(params.sta.list,1)
    
    sta = params.sta.list(s,:);
            
for c = 1:size(params.cha.list,1)
    
    cha = params.cha.list(c,:);

folderfile = strcat('/gpfs/fs1/home/gtepp/Documents/AFAR/20072009/',folderlist(m,:),'/',arr,'.',sta,'..',cha,'_disp.SAC'); % Which files

filelist = dir(folderfile); % Make list of relevant files

numfiles = length(filelist);

scnl = scnlobject(sta,cha,'*','*'); % Create SCNL object

% Look through each folder for files and add waveforms to correlation object

% Build correlation object

for k = 1:numfiles
    
    filename = strcat('/gpfs/fs1/home/gtepp/Documents/AFAR/20072009/',folderlist(m,:),'/',filelist(k).name);
    
    ds = datasource('sac', filename);
    
    w = waveform(ds,scnl,params.time.start.serial,params.time.end.serial); % create waveform from file
    
    if strcmpi('Y',checkwf) == 1
        
        plot(w);
    
        disp(' ')
        keepwf = input(['Would you like to keep waveform ' num2str(m) '-' num2str(k) '? (N or Y): '],'s'); % (default Y)
        
    end
    
if strcmpi('N',keepwf) == 0
        
    evwfnum(m,1) = params.num.list(m); % add event number to list
    
    % Add waveforms to events matrix
    
    if firstwf == 0
        
        w1freq = get(w,'freq');
        
        trig1 = datenum(get(w,'start_str'),'yyyy-mm-dd HH:MM:SS.FFF',2005);

        cobj = correlation(w,trig1); % create correlation object from waveform
    
        allcobj = cobj;
        
        firstwf = 1;
        
        evwfnum(m,2) = evwfnum(m,2) + 1; % count waveforms per event
        
    else
        
        wfreq = get(w,'freq');
            
        trig = datenum(get(w,'start_str'),'yyyy-mm-dd HH:MM:SS.FFF',2005);
    
    % Only add to master if sampling frequency is the same as event 1
        
    if wfreq == w1freq
        
       cobj = correlation(w,trig); % create correlation object from waveform 
        
       allcobj = cat(allcobj,cobj);
       
       evwfnum(m,2) = evwfnum(m,2) + 1; % count waveforms per event
       
    else
       
       disp('--------------------')
       disp(' ')
       disp(['Event 1 freq = ' num2str(w1freq) ' & Event ' num2str(m) '-' num2str(k) ' freq = ' num2str(wfreq)]);
       
       if strcmpi(alloverride,'Y') == 1
           
           freqer = 'Y';
           
       else
       
           disp(' ')
           freqer = input('There is a frequency mismatch. Override? (Y or N): ','s'); % (default N)
       
       end
       
       if strcmpi(freqer,'Y') == 1
       
            wnew = set(w,'freq',w1freq);
        
            cobj = correlation(wnew,trig); % create correlation object from waveform 
        
            allcobj = cat(allcobj,cobj);
            
            evwfnum(m,2) = evwfnum(m,2) + 1; % count waveforms per event
            
       else
           
           disp(' ')
           disp(['Event ' num2str(k) ' was not added not correlation object.'])
           
       end
    
    end
    
    end
    
end

end

end

end

end

end

% Clear temporary variables

clear filelist folderlist cobj w wnew w1freq wfreq HH MM SS trig allfolderMM trig1;
clear evfile evfolder evserial filename folderfile evdates evdt evfile evfolder;


%% Cropping, Filtering and Plotting
    
disp(' ')
disp('--------------------')

% Crop & Filter

[allcobj,params] = filtcrop(allcobj,params,'wig');


%% Spectral Classification - Peak Frequency & Energy Content
    
allwf = waveform(allcobj); % change correlation object to waveform object

disp('--------------------')
disp(' ')
specclass = input('Would you like to spectrally classify events? (Y or N): ','s'); % default N

if strcmpi(specclass,'Y') == 1
    
    disp(' ')
    disp('Choose spectrogram parameters:')
    disp(' ')
    
    maxf = input('Maximum frequency (Hz): ','s');
    % disp(' ')
    % mindB = input('Minimum dB: ','s');
    % maxdB = input('Maximum dB: ','s');
    
    disp(' ')
    cutf = input('What max frequency should be used for percent energy calculation? (Hz, double): '); % max frequency cut-off for percent energy calculation
    
    % dB limits not needed here (not plotting)
    %s = spectralobject(512,410,str2double(maxf),[str2double(mindB) str2double(maxdB)]);
    
    s = spectralobject(512,410,str2double(maxf),[40 120]);
    
    endr = 0;
    
    for h = 1:length(params.num.list)
        
        startr = 1 + endr;
        
        endr = startr + evwfnum(h,2) - 1;
        
        evnum = strcat('ev',num2str(evwfnum(h,1)));
        
        % Go through all waveforms of event
        
        for wfn = startr:endr
            
            station = get(allwf(wfn),'station');
            channel = get(allwf(wfn),'channel');
            
            [data.(evnum).(station).(channel).specamp,data.(evnum).(station).(channel).freq,data.(evnum).(station).(channel).time] = specgram_out(s,...
                allwf(wfn)); % data is Fourier Transform in dB
            
            % Find peak frequency
            
            [val,row] = max(data.(evnum).(station).(channel).specamp); % max of each column
            
            [~,col] = max(val); % max of all columns
            
            data.(evnum).(station).(channel).peakf =data.(evnum).(station).(channel).freq(row(1,col),1);
            
            % Calculate percent energy (?) below cut-off
            
            % Convert out of dB
            
            data.(evnum).(station).(channel).specamp = 10.^(data.(evnum).(station).(channel).specamp/20);
            
            totalE = sum(sum(data.(evnum).(station).(channel).specamp)); % total energy
            
            for fn = 1:length(data.(evnum).(station).(channel).freq)
                
                if data.(evnum).(station).(channel).freq(fn,1) <= cutf
                    
                    frow = fn;
                    
                else
                    
                    disp(' ')
                    disp(['Frequency cut-off is ' num2str(data.(evnum).(station).(channel).freq(frow,1)) 'Hz.'])
                    
                    break; % exit loop once maxf is passed
                    
                end
                
            end
            
            % Calculate total energy below maxf
            
            maxE = sum(sum(data.(evnum).(station).(channel).specamp(1:frow,:)));
            
            % Caluclate percent of total
            
            data.(evnum).(station).(channel).percE = maxE / totalE;
            
        end
        
    end
    
    % Clear temporary variables
    
    clear val pval row col wfn channel station evnum startr endr h maxE totalE;
    
    
%% Plot Spectral Classifications
    
    disp(' ')
    disp('--------------------')
    disp(' ')
    specpl = input('Plot spectral classification values? (N or Y): ','s'); % default Y
    
    while strcmpi(specpl,'N') == 0
        
        plop = input('Plot percent energy (percE) or peak frequency (peakf)?: ','s'); % default peakf
        
        if isempty(plop) == 1
            
            plop = 'peakf';
            
        end
        
        for sn = 1:size(params.sta.list,1)
            
            station = params.sta.list(sn,:);
            
            for cn = 1:size(params.cha.list,1)
                
                channel = params.cha.list(cn,:);
                
                figure;
                
                hold on;
                
                for evn = 1:length(params.num.list)
                    
                    evnum = strcat('ev',num2str(params.num.list(evn,1)));
                    
                    % Make sure event on station & channel
                    
                    if isfield(data.(evnum),station) == 1
                        
                        if isfield(data.(evnum).(station),channel) == 1
                            
                            scatter(data.(evnum).data(1,10),data.(evnum).(station).(channel).(plop),'o');
                            
                        end
                        
                    end
                    
                end
                
                title(['Station: ',station,'    Channel: ',channel]);
                xlabel('Local Magnitude');
                
                if strcmpi(plop,'percE') == 1
                    
                    ylabel('Percent Energy Below Cut-off');
                    
                else
                    
                    ylabel('Peak Frequency (Hz)');
                    
                end
                
            end
            
        end
        
        disp(' ')
        specpl = input('Make another spectral classification plot? (N or Y): ','s');
        
    end

% Clear temporary variables

clear specpl plop sn cn station channel evnum evn;

    
%% Write Spectral Classification Results to File
    
disp('--------------------')
disp(' ')
writespec = input('Write spectral classification results to a text file? (N or Y): ','s'); % default Y
    
while strcmpi(writespec,'N') == 0

    % Make matrix of values to print
    
    disp(' ')
    specwr = input('Write percent energy (percE) or peak frequency (peakf) results?: ','s'); % default peakf
      
    if isempty(specwr) == 1
        
        specwr = 'peakf';
        
    end
    
    specdata = ones(size(evwfnum,1),(size(evwfnum,1)+1)) * NaN;

    for evn = 1:size(evwfnum,1)
        
        evnum = strcat('ev',num2str(evwfnum(evn)));
        
        % go through all stations that event has FIs for
        
        for sta = 1:size(data.(evnum).stalist,1)
        
            station = data.(evnum).stalist(sta,:);
        
            for sn = 1:size(params.sta.list,1)
                
                % figure out what number station the current one is
                
                if strcmpi(station,params.sta.list(sn,:)) == 1

                    specdata(evn,sn) = data.(evnum).(station).BHZ.(specwr);
                    
                    break; % stop loop & move to next station
                    
                end
            
            end
            
        end
        
    end
    
    % Write file
    
    writeresults(data,evwfnum(:,1),specdata,'%5.3f');
    
    % Clear temporary variables
    
    clear sta writespec evnum station evn sn;
    
    % Write another file?
    
    disp(' ')
    writespec = input('Write another spectral classification file? (N or Y): ','s'); % default Y

end
    
end

% Clear temporary variables

clear writespec specwr specdata specclass;


%% Get & Save Data from Waveforms

disp(' ')
disp('--------------------')

% Ask where to get phase picks from

disp(' ')
whichpick = input('Get phase picks from waveform headers (h) or from a *.mat file (f)?: ','s'); % default file

if strcmpi(whichpick,'h') == 0
    
    disp(' ')
    pickfile = input('What is the name of the pick file (*.mat)?: ','s');
    
end

disp(' ')
disp('Getting and saving waveforms....')

% Sort Waveforms by Event

endr = 0;

for h = 1:length(params.num.list)
    
    evnum = strcat('ev',num2str(evwfnum(h,1)));
    
    startr = 1 + endr;
    
    endr = startr + evwfnum(h,2) - 1;
    
    nosta = 1;
    
    nocha = 1;
    
    % Get all waveforms of event from correlation object
    
    for hnum = startr:endr
        
        station = get(allwf(hnum),'station');
        channel = get(allwf(hnum),'channel');
        
        % Make station list
        
        if nosta == 1
            
            data.(evnum).stalist = station;
            
            nosta = 0;
            
        else
            
            data.(evnum).stalist = vertcat(data.(evnum).stalist,station);
            
        end
        
        % Make channel list
        
        if nocha == 1
            
            data.(evnum).chalist = channel;
            
            nocha = 0;
            
        else
            
            data.(evnum).chalist = vertcat(data.(evnum).chalist,channel);
            
        end
        
        data.(evnum).(station).(channel).wf = allwf(hnum);
        
        % Get picks from headers for now
        
        if strcmpi(whichpick,'h') == 1
            
            data.(evnum).(station).spick = get(data.(evnum).(station).(channel).wf,'T2'); % get event S-wave pick
            data.(evnum).(station).ppick = get(data.(evnum).(station).(channel).wf,'T1'); % get event P-wave pick
            
        else
            
            data.(evnum).(station).spick = NaN; % get event S-wave pick
            data.(evnum).(station).ppick = NaN; % get event P-wave pick
            
        end
        
        % Get sampling & waveform start time
        
        data.(evnum).(station).sfreq = get(data.(evnum).(station).(channel).wf,'FREQ'); % get event sampling frequency
        data.(evnum).(station).wfstart = datenum(get(data.(evnum).(station).(channel).wf,'start_str'),'yyyy-mm-dd HH:MM:SS.FFF') -...
            params.crop.start / 3600 / 24; 
        
        % calculate travel time for models with Q
        
        % ** NEED TO EDIT THIS PART **
        
%         if size(params.cha.list,1) == 2
%             
%             data.(evnum).(station).ttime =data.(evnum).(station).spick - get(data.(evnum).(station).wf.nb0(1,1),'O');
%             
%         elseif size(params.cha.list,1) == 1
%             
%             data.(evnum).(station).ttime =data.(evnum).(station).ppick - get(data.(evnum).(station).wf.nb0(1,1),'O');
%             
%         end
        
    end
    
    % Make sure station & channel lists only have one entry for each station/channel
    
    data.(evnum).stalist = unique(data.(evnum).stalist,'rows');
    
    data.(evnum).chalist = unique(data.(evnum).chalist,'rows');
    
    % Add new stations to "universal" station list
    
    if h == 1 % start list with 1st event
        
        params.sta.list = data.(evnum).stalist;
        
    else % add any new stations for subsequent events
        
        params.sta.list = unique(vertcat(params.sta.list,data.(evnum).stalist),'rows');
        
    end
    
end

% If picks needed from a file, call function to get picks

if strcmpi(whichpick,'h') == 0
    
    [data] = getpicks(pickfile,params.num.list,data);
    
    % Decide what to do with events without picks
    
    disp(' ')
    nopicks = input('For events without picks, use default picks (d) or toss out (t)?: ','s'); % default toss out
    
    if strcmpi(nopicks,'d') == 1
        
        for h = 1:length(params.num.list)
            
            evnum = strcat('ev',num2str(params.num.list(h,1)));
            
            for ns = 1:size(data.(evnum).stalist,1)
                
                station = data.(evnum).stalist(ns,:);
                
                % If there is currently no pick, get pick from header
                
                if isnan(data.(evnum).(station).spick) == 1
                    
                    data.(evnum).(station).spick = get(data.(evnum).(station).(channel).wf,'T2'); % get event S-wave pick
                    
                end
                
                if isnan(data.(evnum).(station).ppick) == 1
                    
                    data.(evnum).(station).ppick = get(data.(evnum).(station).(channel).wf,'T1'); % get event P-wave pick
                    
                end
                
                % Mark all events as good
                
                data.(evnum).(station).bad = 0;
                
            end
            
        end
        
    else
        
        badct = 0; % counter for bad events

        templist = params.num.list; % list of good events
        
        for h = 1:length(params.num.list)
            
            evnum = strcat('ev',num2str(params.num.list(h,1)));
            
            for ns = 1:size(data.(evnum).stalist,1)
                
                station = data.(evnum).stalist(ns,:);
                
                % If there isn't a P-pick (or S-pick for horizontals), mark as bad
                
                if isnan(data.(evnum).(station).ppick) == 1 || (isnan(data.(evnum).(station).spick) == 1 &&...
                        isempty(regexpi(transpose(params.sta.list(:,3)),'[N E T R]')) == 0)
                    
                    data.(evnum).(station).bad = 1;
                    
                    badct = badct + 1; % count bad events
                    
                    % Remove bad event from templist
                    
                    templist = templist(find(templist ~= params.num.list(h,1)));
                    
                else % otherwise, mark as good
                    
                    data.(evnum).(station).bad = 0;
                    
                    %disp(['Event ' evnum ' is good.'])
                    
                end
                
            end
            
        end
        
    end
    
    disp(' ')
    disp(['There are ' num2str(length(badct)) ' of ' num2str(length(params.num.list)) ' events without picks that will be tossed.'])
    
    params.num.list = templist; % replace num list with new list of only good events
    
else % if picks from header, mark all as good
    
     for h = 1:length(params.num.list)
         
         evnum = strcat('ev',num2str(params.num.list(h,1)));
         
         for ns = 1:size(data.(evnum).stalist,1)
             
             station = data.(evnum).stalist(ns,:);
             
             data.(evnum).(station).bad = 0;
             
         end
         
     end
     
end

% Clear temporary and unneeded variables

clear evdata evn sn allwf hnum whichpick ns h badct evnum station nopicks nocha nosta pickfile endr startr templist;


%% Find Suitable EGFs

disp(' ')
disp('--------------------')

% Make list of events, magnitudes, and locations

eqmag = cell(size(params.num.list,1),5);

% If > 10 columns, ask whether to use extra info

ev1 = strcat('ev',num2str(params.num.list(1,1))); % just check data length for 1st event

if size(data.(ev1).data,2) >= 11
    
    disp(' ')
    useextra = input('Use extra columns of parameters? (N or Y): ','s');
    
    if strcmpi(useextra,'N') == 0
    
        if size(data.(ev1).data,1) > 11
        
            disp(' ')
            disp(['You have ' num2str(size(data.(ev1).data,1) - 10) ' extra columns.'])
            disp(' ')
            whichcol = input('Which columns would you like to use? (e.g. 11/12 or 11:13/15 or * for all [default]): ','s'); % default all
            
            if strcmpi(params.num.str,'*') == 1 || isempty(params.num.str) == 1
                
                % Create list of numbers for all events
                
                colnum = transpose(11:size(data.(ev1).data,1));
                
            else
                
                % Convert event #s to usuable list
                
                colnum = makelist(whichcol,'num');
                
            end
            
        else
            
            colnum = 11;
            
        end
        
        % Add extra columns to eqmag
        
        eqmag = cell(size(params.num.list,1),(5 + length(colnum)));
        
        % Set difference limit
        
        disp(' ')
        disp('Set difference limits:')
        
        for p = 1:length(colnum)
                        
            cname = strcat('col',num2str(colnum(p)));
            
            disp(' ')
            limtype.(cname) = input(['For Column ' num2str(colnum(p)) ' - minimum (min) or maximum (max, default)?:  '],'s'); % default max
            
            if strcmpi(limtype.(cname),'min') == 1
                
                limval.(cname) = input('Choose a minimum allowed difference (double): ');
                
            else
                
                limtype.(cname) = 'max'; % make sure it's not empty or some other string
                limval.(cname) = input('Choose a maximum allowed difference (double): ');
                
            end
            
        end
        
    end
        
end

for eq = 1:size(params.num.list,1)
    
    eqmag{eq,1} = strcat('ev',num2str(params.num.list(eq,1))); % get event name/number
    
    eqmag{eq,2} = data.(eqmag{eq,1}).data(1,10); % get magnitude
    
    eqmag{eq,3} = data.(eqmag{eq,1}).data(1,1); % get hypocenter longitude
    
    eqmag{eq,4} = data.(eqmag{eq,1}).data(1,2); % get hypocenter latitude
    
    eqmag{eq,5} = data.(eqmag{eq,1}).data(1,3); % get hypocenter depth
    
    % If other columns used, get those too
    
    if strcmpi(useextra,'N') == 0
        
        qc = 6; % move to next open column
        
        for q = 1:length(colnum)
            
            eqmag{eq,qc} = data.(eqmag{eq,1}).data(1,colnum(q));
            
            qc = qc + 1; % move to next column in eqmag
            
        end
        
    end
    
end

% Ask whether to check correlation

disp(' ')
usecorr = input('Check correlation values? (N or Y): ','s');

if strcmpi(usecorr,'N') == 0
    
    % Get options for correlation
    
    disp(' ')
    trigreset = input('Reset triggger times to P-picks? (N or Y):','s'); % default Y
    
    if size(params.cha.list,1) > 1
        
        disp(' ')
        disp(['You have channels: ' transpose(params.cha.list)])
        disp(' ')
        channel = input('Please choose one channel from the list for cross-correlation: ','s');
        
    else
        
        channel = params.cha.list;
        
    end
    
    % Make correlation object
    
    for onsta = 1:size(params.sta.list)
    
        station = params.sta.list(onsta,:);
        
        tempcorr = [];
        
    for oneq = 1:length(params.num.list)
        
        evnum = strcat('ev',num2str(params.num.list(oneq)));

        % check if event is on station
        
        if isempty(regexpi(cell2mat(transpose(cellstr(data.(evnum).stalist))),station)) == 0
        
            % If event is good, add to correlation object
            
            if data.(evnum).(station).bad == 0
                
                if strcmpi(trigreset,'N') == 1 % use waveform start as trigger
                    
                    trig = datenum(get(data.(evnum).(station).(channel).wf,'start_str'),'yyyy-mm-dd HH:MM:SS.FFF',2005);
                    
                else % use P-pick as trigger (need to convert to actual time)
                    
                    trig = datenum(get(data.(evnum).(station).(channel).wf,'start_str'),'yyyy-mm-dd HH:MM:SS.FFF',2005) +...
                        ((data.(evnum).(station).ppick - params.crop.start) / 3600 / 24);
                    
                end
                
                if isempty(tempcorr) == 1
                    
                    tempcorr = correlation(data.(evnum).(station).(channel).wf,trig);
                    
                else
                    
                    tempcorr = cat(tempcorr,correlation(data.(evnum).(station).(channel).wf,trig));
                    
                end
                
            end
         
        end
            
    end
        
    % Move temporary correlation object into structure
    
    allcorr.(station) = tempcorr;
    
    clear tempcorr;
    
    end

    % Get correlation window start and end
    
    disp(' ')
    disp('Choose a correlation window with respect to the trigger times.')
    disp('Use (-) for times before the trigger.')
    disp('Set both values to 0 for full (cropped) window (default).')
    disp(' ')
    gett = 1;
    
    while gett == 1
        
        cst = input('Choose a window start time (double, default 0): ');
        cend = input('Choose a window end time (double, default 0): ');
        
        if isempty(cst) == 1
            
            cst = 0;
            
        end
        
        if isempty(cend) == 1
            
            cend = 0;
            
        end
        
        if cst > cend % make sure start time is before end time
            
            disp(' ')
            disp('Oops! Your start time is after the end time. Please try again.')
            
        else
            
            gett = 0;
            
        end
        
    end
    
    % Make a list of possible EGFs from magnitude and hypocenter
    
    [EGFlistmld,~] = findEGF(cell2mat(eqmag(:,2)),cell2mat(eqmag(:,3:5)),'numlist',params.num.list,'correlate','yes',...
        'corrobj',allcorr,'corrtime',[cst cend]);
    
else
    
    % Make a list of possible EGFs from magnitude and hypocenter
    
    [EGFlistmld,~] = findEGF(cell2mat(eqmag(:,2)),cell2mat(eqmag(:,3:5)),'numlist',params.num.list);
    
end

% Get rid of events with no EGFs and check any other parameters

for evn = 1:length(params.num.list)
    
    evname = strcat('ev',num2str(params.num.list(evn)));
    
    if strcmpi(usecorr,'N') == 1
        
        if EGFlistmld.(evname) ~= 0 % if there are EGF matches
              
            % Check based on other parameters (if wanted)
            
            if strcmpi(useextra,'N') == 1
                
                EGFlist.(evname) = EGFlistmld.(evname);
                
            else
                
                chklist = ones(length(EGFlistmld.(evname)),1);
                
                for z = 1:length(colnum)
                    
                    cname = strcat('col',num2str(colnum(z)));
                    
                    % Check all EGFs
                    
                    for egfn = 1:length(EGFlistmld.(evname))
                        
                        egfname = strcat('ev',num2str(EGFlistmld.(evname)(egfn)));
                        
                        % Only check 'good' EGFs
                        
                        if chklist(egfn,1) == 1
                            
                            % If EGF does NOT satisfy limits for a column change to 0 and ignore (needs to fit all requirements)
                            
                            if (abs(data.(evname).data(1,colnum(z)) - data.(egfname).data(1,colnum(z))) >= limval.(cname) &&...
                                    strcmpi(limtype.(cname),'max') == 1) || (strcmpi(limtype.(cname),'min') == 1 &&...
                                    abs(data.(evname).data(1,colnum(z)) - data.(egfname).data(1,colnum(z))) <= limval.(cname))
                                
                                chklist(egfn,1) = 0;
                                
                            end
                            
                        end
                        
                    end
                    
                end
                
                % Keep EGFs that satisfy all criteria
                
                EGFlist.(evname) = EGFlistmld.(evname)(find(chklist == 1),1);
                
            end
            
        end
        
    else
        
        for st = 1:size(params.sta.list,1)
            
            staname = params.sta.list(st,:);
            
            if EGFlistmld.(evname).(staname) ~= 0 % if there are EGF matches
                
                % Check based on other parameters (if wanted)
                
                if strcmpi(useextra,'N') == 1
                    
                    EGFlist.(evname).(staname) = EGFlistmld.(evname).(staname);
                    
                else
                    
                    chklist = ones(length(EGFlistmld.(evname).(staname)),1);
                    
                    for z = 1:length(colnum)
                        
                        cname = strcat('col',num2str(colnum(z)));
                        
                        % Check all EGFs
                        
                        for egfn = 1:length(EGFlistmld.(evname).(staname))
                            
                            egfname = strcat('ev',num2str(EGFlistmld.(evname).(staname)(egfn)));
                            
                            % Only check 'good' EGFs
                            
                            if chklist(egfn,1) == 1
                                
                                % If EGF does NOT satisfy limits for a column change to 0 and ignore (needs to fit all requirements)
                                
                                if (abs(data.(evname).data(1,colnum(z)) - data.(egfname).data(1,colnum(z))) >= limval.(cname) &&...
                                        strcmpi(limtype.(cname),'max') == 1) || (strcmpi(limtype.(cname),'min') == 1 &&...
                                        abs(data.(evname).data(1,colnum(z)) - data.(egfname).data(1,colnum(z))) <= limval.(cname))
                                    
                                    chklist(egfn,1) = 0;
                                    
                                end
                                
                            end
                            
                        end
                        
                    end
                    
                    % Keep EGFs that satisfy all criteria
                    
                    EGFlist.(evname).(staname) = EGFlistmld.(evname).(staname)(find(chklist == 1),1);
                    
                end
                
            end
            
        end
        
    end
    
end

% Clear any temporary variables

clear allcorr channel evn evname gett cst cend station trig oneq onsta colnum limtype limval trigreset useextra ev1 chklist;


%% Deconvolve EGF from Other Events

wingood = 0;

while wingood == 0

% Get time window that should be deconvolved

disp(' ')
stdecon = input('Start deconvolution time relative to waveform start (w), S-pick (s), or P-pick (p)?: ','s');

if strcmpi(stdecon,'w') == 1
    
    ststr = 'waveform start';
    
elseif strcmpi(stdecon,'s') == 1
    
    ststr = 'S-pick';
    
else
    
    ststr = 'P-pick';
    
end

disp(' ');
strt = input(['What time should the deconvolution start relative to the ' ststr '? (double, (-) for earlier): ']);

wind = input('How long should the deconvolution window be? (double): ');

% Make sure times are valid for cropped waveforms (note: only checks if relative to waveform start)

if isempty(strt) == 1 || isempty(wind) == 1
    
    disp(' ');
    disp('Please enter both a start time and a window length.');
    disp('--------------------')
    
elseif (strt <= params.crop.start || (strt + wind) >= params.crop.end) && strcmpi(stdecon,'w') == 1
    
    disp(' ');
    
    if strt >= params.crop.start
        
        disp('WARNING: Start time is out-of-bounds.');
        
    end
    
    if (strt + wind) >= params.crop.end
        
        disp('WARNING: End time is out-of-bounds.');
        
    end
    
    disp('Please try again.');
    disp('--------------------')
    
else
    
    wingood = 1;

end

end

% Do deconvolution for each EGF

evwegf = fieldnames(EGFlist);

for num = 1:size(evwegf,1)
    
    evnum = char(evwegf{num,1});
    
    for sn = 1:size(params.sta.list,1)
        
        station = params.sta.list(sn,:);
        
        % Find starting & ending points in data vector
        
        if strcmpi(stdecon,'w') == 1 % use waveform start
            
            relst = 0;

        elseif strcmpi(stdecon,'s') == 1 % use S-pick
            
            relst = data.(evnum).(station).spick;

        else % use P-pick
            
            relst =data.(evnum).(station).ppick;

        end
        
        strtin = (strt + relst - params.crop.start) * data.(eqmag{num,1}).(station).sfreq;
        
        endin = wind * data.(eqmag{num,1}).(station).sfreq + strtin;
        
        for cn = 1:size(params.cha.list,1)
            
            channel = params.cha.list(cn,:);
                        
            % For every station and channel, deconvolve for each EGF
            
            for egfn = 1:size(EGFlist.(evwegf{num,1}),1)
                
                if strcmpi(usecorr,'N') == 1
                    
                    if EGFlist.(evwegf{num,1})(egfn,1) ~= 0 % if there's an EGF
                        
                        egfname = strcat('ev',num2str(EGFlist.(evwegf{num,1})(egfn,:)));
                        
                        disp(' ')
                        disp(['Deconvolving ' egfname ' from ' evwegf{num,1} '....'])
                        
                        eqdata = transpose(get(data.(evwegf{num,1}).(station).(channel).wf,'Data'));
                        
                        egfdata = transpose(get(data.(egfname).(station).(channel).wf,'Data'));
                        
                        [egfdec.(evwegf{num,1}).(station).(channel).deconv.(egfname), egfdec.(evwegf{num,1}).(station).(channel).resid.(egfname)] =...
                            seisdeconv(eqdata(strtin:endin),egfdata(strtin:endin),100000,data.(evwegf{num,1}).(station).sfreq,'w');
                        
                    end
                    
                else
                    
                    if EGFlist.(evwegf{num,1}).(station)(egfn,1) ~= 0 % if there's an EGF
                        
                        egfname = strcat('ev',num2str(EGFlist.(evwegf{num,1}).(station)(egfn,:)));
                        
                        disp(' ')
                        disp(['Deconvolving ' egfname ' from ' evwegf{num,1} '....'])
                        
                        eqdata = transpose(get(data.(evwegf{num,1}).(station).(channel).wf,'Data'));
                        
                        egfdata = transpose(get(data.(egfname).(station).(channel).wf,'Data'));
                        
                        [egfdec.(evwegf{num,1}).(station).(channel).deconv.(egfname), egfdec.(evwegf{num,1}).(station).(channel).resid.(egfname)] =...
                            seisdeconv(eqdata(strtin:endin),egfdata(strtin:endin),10^-25,data.(evwegf{num,1}).(station).sfreq,'w');
                        
                    end
                    
                end
                
            end
            
        end
        
    end

end


%% Plot Deconvolved Waveforms

disp('--------------------')
disp(' ')
repeat = input('Plot deconvolved waveforms? (N or Y): ','s');

while strcmpi(repeat,'N') == 0

disp(' ')
showev = input('Show events used in deconvolution? (N or Y): ','s');

if strcmpi(showev,'N') == 0

    disp(' ')
    disp('The following events have matching EGFs:')
    disp(' ')
    disp(transpose(evwegf))

end

disp(' ')
evnum = input('Choose an event (input as ev#, e.g. ev42): ','s');

if size(params.sta.list,1) > 1

    station = input('Choose a station: ','s');

else
    
    station = params.sta.list;
    
end

% Show EGFs if more than one

if strcmpi(usecorr,'N') == 1
    
    if size(EGFlist.(evnum),1) > 1
        
        disp(' ');
        disp('The EGFs for this event are:')
        disp(' ')
        disp(EGFlist.(evnum));
        disp(' ');
        egfn = input('Choose an egf (input as ev#, e.g. ev42): ','s');
        
    else
        
        egfn = EGFlist.(evnum);
        
    end
    
else
    
    if size(EGFlist.(evnum).(station),1) > 1
        
        disp(' ');
        disp('The EGFs for this event are:')
        disp(' ')
        disp(EGFlist.(evnum).(station));
        disp(' ');
        egfn = input('Choose an egf (input as ev#, e.g. ev42): ','s');
        
    else
        
        egfn = EGFlist.(evnum).(station);
        
    end
    
end

figure;

plot(time,egfdec.(evnum).(station).BHZ.deconv.(egfn))

title(['Event: ' evnum '    Station: ' station '    EGF: ' egfn]);

repeat = input('Make another plot? (N or Y):  ','s');

end


%% Calculate Spectra

% This is done in a roundabout way in order to make use of MatLab's
% multitaper abilities. The function pmtm calculates the multitaper power
% spectral density using Thomson's multitaper method which has less frequency 
% leakage and variance than other commonly used methods. Since we don't
% want the PSD, it's converted back to the initial amplitude (e.g. displacement).

% disp(' ')
% disp('--------------------')
% 
% disp(' ')
% disp('Calculating spectra....')
% 
% for evn = 1:length(params.num.list)
%     
%     evnum = strcat('ev',num2str(params.num.list(evn,1)));
%     
%     for sn = 1:size(data.(evnum).stalist,1)
%     
%         station = data.(evnum).stalist(sn,:);
%         
%         for cha = 1:size(data.(evnum).chalist,1)
%         
%             channel = data.(evnum).chalist(cha,:);
%             
%             % Make sure channel's recorded at station
% 
%             if isfield(data.(evnum).(station),channel) == 1
% 
%                 % Calculate PSD
%                 
%                 [psd,data.(evnum).(station).(channel).spec.f] = pmtm(data.(evnum).(station).(channel).wf,4,size(data.(evnum).(station).(channel).wf,2),...
%                     data.(evnum).(station).sfreq,'onesided');
%                 
%                 % Convert back to inital amplitude units
%                 
%                 data.(evnum).(station).(channel).spec.data = log10(sqrt(psd).*data.(evnum).(station).(channel).spec.f);
%                 
%             end
%             
%         end
%         
%     end
%     
% end
% 
% 
% %% Plot Spectra
% 
% disp(' ')
% specplot = input('Plot spectra? (Y or N): ','s'); % default N
% 
% while strcmpi(specplot, 'Y') == 1
%     
%     disp(' ')
%     disp(['Events: ' num2str(transpose(params.num.list))])
%     disp(' ')
%     evlist = input('Choose your event(s): ','s');
%     
%     % If no event(s) chosen, use all
%     
%     if isempty(evlist) == 1 || strcmpi(evlist,'*') == 1
%         
%         evlist = params.num.list;
%         
%     else
%         
%         evlist = makelist(evlist,'num');
%         
%     end
%     
%     disp(' ')
%     station = input('Pick a station: ','s');
%     channel = input('Pick a channel: ','s');
%     
%     % Find # of columns for subplots if more than 1 event
%     
%     if length(evlist) == 1
%         
%         col = 1;
%         row = 1;
%         rowpg = 1;
%         
%     else
%         
%         [row,col,rowpg] = subplotpar(length(evlist),'waveforms');
%         
%     end
%     
%     disp(' ')
%     stfreq = input('Choose a lower frequency cut-off (Hz): ');
%     endfreq = input('Choose an upper frequency cut-off (Hz): ');
%     
%     if stfreq > endfreq % if limits are switched, change back
%         
%         sfq = stfreq;
%         stfreq = endfreq;
%         endfreq = sfq;
%         
%     end
%     
%     % Plot spectra
%     
%     fignum = ceil(row/rowpg);
%     
%     onfig = 1;
%     
%     figure; % open new figure window
%     
%     for eq = 1:size(evlist,1)
%         
%         evnum = strcat('ev',num2str(evlist(eq,1)));
%         
%         % Make sure event recorded on station
%         
%         stagood = 0; % reset temporary variable
%         
%         for sn = 1:size(data.(evnum).stalist,1)
%             
%             if strcmpi(station,data.(evnum).stalist(sn,:)) == 1
%                 
%                 stagood = 1;
%                 
%                 break;
%                 
%             end
%             
%         end
%         
%         if stagood == 1
%             
%             % Find freq vector cut-offs
%             
%             if endfreq > data.(evnum).(station).(channel).spec.f(length(data.(evnum).(station).(channel).spec.f),1)
%                 
%                 % fstop is last f value
%                 
%                 fstop = length(data.(evnum).(station).(channel).spec.f);
%                 
%             else
%                 
%                 % Loop through until you find closest f to fstop
%                 
%                 fstop = 1;
%                 
%                 while endfreq > data.(evnum).(station).(channel).spec.f(fstop,1)
%                     
%                     fstop = fstop + 1;
%                     
%                 end
%                 
%             end
%             
%             if stfreq < data.(evnum).(station).(channel).spec.f(1,1)
%                 
%                 fstart = 1;
%                 
%             else
%                 
%                 fstart = 1;
%                 
%                 while stfreq > data.(evnum).(station).(channel).spec.f(fstart,1)
%                     
%                     fstart = fstart + 1;
%                     
%                 end
%                 
%             end
%             
%             % Make sub-plot
%             
%             spnum = eq - (rowpg*col)*(onfig - 1); % sub-plot number for figure
%             
%             subplot(rowpg,col,spnum);
%             
%             plot(data.(evnum).(station).(channel).spec.f(fstart:fstop,1),data.(evnum).(station).(channel).spec.data(fstart:fstop,1));
%             
%             title(['Event: ' num2str(evlist(eq,1)) '    Station: ' station '    Channel: ' channel]);
%             xlabel('Frequency (Hz)');
%             ylabel('Log Amplitude');
%             axis tight;
%             grid on;
%             set(gca,'YMinorGrid','off','XScale','log');
%             xlim([0.1 25])
%             
%             % When figure filled, move to next one
%             
%             if rem(eq,(rowpg*col)) == 0 && onfig ~= fignum
%                 
%                 figure;
%                 
%                 onfig = onfig + 1;
%                 
%             end
%             
%         end
%         
%     end
%     
%     disp(' ')
%     specplot = input('Make another spectral plot? (Y or N): ','s') ; % default N
%     disp('--------------------')
%     
% end
%         
% 
% % %% Plot Waveforms
% % 
% % disp(' ')
% % repeat = input('Plot waveforms? (N or Y): ','s');
% % 
% % while strcmpi(repeat,'N') == 0
% % 
% % evnum = input('event: ','s');
% % station = input('station: ','s');
% % 
% % time = (0:1:length(data.(evnum).(station).BHE.wf))/data.(evnum).(station).sfreq;
% % 
% % figure;
% % 
% % plot(time,data.(evnum).(station).BHE.wf)
% % 
% % title(['Event: ' evnum '    Station: ' station]);
% % 
% % repeat = input('Plot another waveform? (N or Y):  ','s');
% % 
% % end


%% End of program message

disp('--------------------')
disp(' ')
disp('End of Program :)')
disp(' ')
disp('--------------------')
disp(' ')